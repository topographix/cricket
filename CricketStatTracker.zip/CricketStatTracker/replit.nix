{pkgs}: {
  deps = [
    pkgs.glibcLocales
  ];
}

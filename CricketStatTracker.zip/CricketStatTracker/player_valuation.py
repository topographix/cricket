"""
Player Valuation Module for IPL Cricket Stats Dashboard

This module calculates player valuations and market worth based on their performance metrics,
similar to how IPL teams value players during auctions.
"""

import pandas as pd
import numpy as np
from typing import Dict, List, Any

def calculate_player_value(player_data: Dict[str, Any]) -> float:
    """
    Calculate a player's estimated market value in crores (INR) based on their statistics
    
    Args:
        player_data: Dictionary with player information and stats
        
    Returns:
        Estimated market value in crores (INR)
    """
    role = player_data.get("role", "")
    batting_stats = player_data.get("batting_stats", {})
    bowling_stats = player_data.get("bowling_stats", {})
    matches = player_data.get("matches_played", 0)
    
    # Base value determined by matches played (experience)
    if matches > 80:
        base_value = 2.0  # Very experienced
    elif matches > 50:
        base_value = 1.5  # Highly experienced
    elif matches > 30:
        base_value = 1.0  # Experienced
    elif matches > 15:
        base_value = 0.75  # Moderate experience
    else:
        base_value = 0.5  # Newcomer
    
    # Calculate batting value multiplier
    batting_value = 1.0
    if batting_stats:
        runs = batting_stats.get("runs", 0)
        avg = batting_stats.get("average", 0)
        sr = batting_stats.get("strike_rate", 0)
        
        # Batting volume factor (total runs)
        if runs > 2000:
            batting_value *= 3.0
        elif runs > 1000:
            batting_value *= 2.0
        elif runs > 500:
            batting_value *= 1.5
        elif runs > 200:
            batting_value *= 1.2
        
        # Batting average factor
        if avg > 45:
            batting_value *= 1.8
        elif avg > 35:
            batting_value *= 1.5
        elif avg > 25:
            batting_value *= 1.3
        
        # Strike rate factor
        if sr > 160:
            batting_value *= 1.8
        elif sr > 140:
            batting_value *= 1.5
        elif sr > 120:
            batting_value *= 1.2
        
        # Boundary hitting ability
        boundaries = batting_stats.get("fours", 0) + batting_stats.get("sixes", 0) * 2
        if boundaries > 200:
            batting_value *= 1.4
        elif boundaries > 100:
            batting_value *= 1.2
    
    # Calculate bowling value multiplier
    bowling_value = 1.0
    if bowling_stats:
        wickets = bowling_stats.get("wickets", 0)
        economy = bowling_stats.get("economy", 0)
        
        # Wicket-taking factor
        if wickets > 80:
            bowling_value *= 3.0
        elif wickets > 50:
            bowling_value *= 2.0
        elif wickets > 25:
            bowling_value *= 1.5
        elif wickets > 10:
            bowling_value *= 1.2
        
        # Economy factor (lower is better)
        if economy > 0:  # Check if the player has bowled
            if economy < 7.0:
                bowling_value *= 1.8
            elif economy < 8.0:
                bowling_value *= 1.5
            elif economy < 9.0:
                bowling_value *= 1.2
        
        # Skill in taking multiple wickets
        multi_wicket = bowling_stats.get("four_wicket_hauls", 0) + bowling_stats.get("five_wicket_hauls", 0) * 2
        if multi_wicket > 5:
            bowling_value *= 1.5
        elif multi_wicket > 2:
            bowling_value *= 1.3
    
    # Role-specific value adjustments
    if role == "Batsman":
        final_value = base_value * (batting_value * 0.8 + bowling_value * 0.2) 
    elif role == "Bowler":
        final_value = base_value * (batting_value * 0.2 + bowling_value * 0.8)
    elif role == "All-rounder":
        final_value = base_value * (batting_value * 0.5 + bowling_value * 0.5) * 1.2  # All-rounders get a 20% premium
    elif role == "Wicket-keeper Batsman":
        final_value = base_value * (batting_value * 0.7 + bowling_value * 0.1) * 1.3  # Wicket-keepers get a 30% premium
    else:
        final_value = base_value * (batting_value * 0.5 + bowling_value * 0.5)
    
    # Age factor - younger players with potential are worth more
    age = int(player_data.get("age", "30").strip())
    if age < 23:
        final_value *= 1.5  # Young talent premium
    elif age < 27:
        final_value *= 1.2  # Prime years premium
    elif age > 35:
        final_value *= 0.7  # Age discount
    elif age > 32:
        final_value *= 0.9  # Slight age discount
    
    # Round to 2 decimal places
    return round(final_value, 2)

def get_player_valuation_data(players_data: Dict[str, Dict]) -> List[Dict]:
    """
    Generate player valuation data for all players
    
    Args:
        players_data: Dictionary of all player data
        
    Returns:
        List of player valuation dictionaries
    """
    valuation_data = []
    
    for player_id, player in players_data.items():
        value = calculate_player_value(player)
        
        # Calculate performance ratios
        batting_stats = player.get("batting_stats", {})
        bowling_stats = player.get("bowling_stats", {})
        
        # Value for money factors
        matches = player.get("matches_played", 0)
        if matches > 0:
            value_per_match = round(value / matches, 3)
        else:
            value_per_match = 0
            
        # Batting ROI
        runs = batting_stats.get("runs", 0)
        if runs > 0:
            value_per_run = round(value * 10 / runs, 3)  # Value per 10 runs
        else:
            value_per_run = 0
            
        # Bowling ROI
        wickets = bowling_stats.get("wickets", 0)
        if wickets > 0:
            value_per_wicket = round(value / wickets, 3)
        else:
            value_per_wicket = 0
        
        valuation_data.append({
            "Player": player.get("name", "Unknown"),
            "Team": player.get("team", "Unknown"),
            "Role": player.get("role", "Unknown"),
            "Age": player.get("age", "Unknown"),
            "Matches": matches,
            "Market Value (₹ Cr)": value,
            "Value Per Match (₹ Cr)": value_per_match,
            "Value Per 10 Runs (₹ Cr)": value_per_run,
            "Value Per Wicket (₹ Cr)": value_per_wicket,
            "Batting Stats": {
                "Runs": runs,
                "Average": batting_stats.get("average", 0),
                "Strike Rate": batting_stats.get("strike_rate", 0)
            },
            "Bowling Stats": {
                "Wickets": wickets,
                "Economy": bowling_stats.get("economy", 0),
                "Average": bowling_stats.get("average", 0)
            }
        })
    
    return valuation_data

def get_team_valuation_data(players_data: Dict[str, Dict]) -> Dict[str, Dict]:
    """
    Calculate team valuations based on their players
    
    Args:
        players_data: Dictionary of all player data
        
    Returns:
        Dictionary with team valuations
    """
    team_values = {}
    
    for player_id, player in players_data.items():
        team = player.get("team", "Unknown")
        value = calculate_player_value(player)
        
        if team not in team_values:
            team_values[team] = {
                "total_value": 0,
                "player_count": 0,
                "batting_value": 0,
                "bowling_value": 0,
                "all_rounder_value": 0,
                "wicket_keeper_value": 0
            }
        
        team_values[team]["total_value"] += value
        team_values[team]["player_count"] += 1
        
        role = player.get("role", "")
        if "Batsman" in role and "Wicket-keeper" not in role:
            team_values[team]["batting_value"] += value
        elif role == "Bowler":
            team_values[team]["bowling_value"] += value
        elif role == "All-rounder":
            team_values[team]["all_rounder_value"] += value
        elif "Wicket-keeper" in role:
            team_values[team]["wicket_keeper_value"] += value
    
    # Calculate average player value for each team
    for team in team_values:
        if team_values[team]["player_count"] > 0:
            team_values[team]["average_player_value"] = round(
                team_values[team]["total_value"] / team_values[team]["player_count"], 2
            )
        else:
            team_values[team]["average_player_value"] = 0
    
    return team_values

def calculate_player_auction_price_prediction(player_data: Dict[str, Any]) -> Dict[str, float]:
    """
    Predict a player's potential auction price range based on their statistics
    
    Args:
        player_data: Dictionary with player information
        
    Returns:
        Dictionary with minimum, expected, and maximum auction price predictions
    """
    base_value = calculate_player_value(player_data)
    
    # Calculate auction price ranges with some variability
    min_price = round(base_value * 0.7, 2)
    expected_price = round(base_value, 2)
    max_price = round(base_value * 1.5, 2)
    
    return {
        "min_price": min_price,
        "expected_price": expected_price,
        "max_price": max_price
    }

def get_value_for_money_players(players_data: Dict[str, Dict], role: str = None, min_matches: int = 10) -> List[Dict]:
    """
    Find players with the best value for money (high performance relative to predicted price)
    
    Args:
        players_data: Dictionary of player data
        role: Optional filter by player role
        min_matches: Minimum matches played to be considered
        
    Returns:
        List of value-for-money player recommendations
    """
    value_players = []
    
    for player_id, player in players_data.items():
        if player.get("matches_played", 0) < min_matches:
            continue
            
        if role and player.get("role", "") != role:
            continue
            
        value = calculate_player_value(player)
        
        # Calculate performance to value ratio
        batting_stats = player.get("batting_stats", {})
        bowling_stats = player.get("bowling_stats", {})
        
        if value <= 0:
            continue
            
        # Different metrics for different roles
        if "Batsman" in player.get("role", ""):
            runs = batting_stats.get("runs", 0)
            sr = batting_stats.get("strike_rate", 0)
            
            if runs > 0:
                performance_ratio = (runs * sr / 100) / (value * 10)  # Higher is better
                
                value_players.append({
                    "Player": player.get("name", "Unknown"),
                    "Team": player.get("team", "Unknown"),
                    "Role": player.get("role", "Unknown"),
                    "Value (₹ Cr)": value,
                    "Runs": runs,
                    "Strike Rate": sr,
                    "Performance Ratio": round(performance_ratio, 2),
                    "Age": player.get("age", "Unknown")
                })
                
        elif player.get("role", "") == "Bowler":
            wickets = bowling_stats.get("wickets", 0)
            economy = bowling_stats.get("economy", 0)
            
            if wickets > 0 and economy > 0:
                performance_ratio = (wickets / economy) / value  # Higher is better
                
                value_players.append({
                    "Player": player.get("name", "Unknown"),
                    "Team": player.get("team", "Unknown"),
                    "Role": player.get("role", "Unknown"),
                    "Value (₹ Cr)": value,
                    "Wickets": wickets,
                    "Economy": economy,
                    "Performance Ratio": round(performance_ratio, 2),
                    "Age": player.get("age", "Unknown")
                })
                
        elif player.get("role", "") == "All-rounder":
            runs = batting_stats.get("runs", 0)
            wickets = bowling_stats.get("wickets", 0)
            
            if runs > 0 and wickets > 0:
                performance_ratio = (runs / 20 + wickets) / value  # Higher is better
                
                value_players.append({
                    "Player": player.get("name", "Unknown"),
                    "Team": player.get("team", "Unknown"),
                    "Role": player.get("role", "Unknown"),
                    "Value (₹ Cr)": value,
                    "Runs": runs,
                    "Wickets": wickets,
                    "Performance Ratio": round(performance_ratio, 2),
                    "Age": player.get("age", "Unknown")
                })
    
    # Sort by performance ratio (descending)
    value_players.sort(key=lambda x: x.get("Performance Ratio", 0), reverse=True)
    
    return value_players
import pandas as pd
import json
from typing import Dict, List, Any, Tuple
import logging
import time

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

def process_player_data(raw_data: Dict, team_name: str) -> Dict:
    """
    Process and clean raw player data
    
    Args:
        raw_data: Raw player data from scraper
        team_name: Team name
        
    Returns:
        Processed player data
    """
    # Return already processed data as is
    if 'id' in raw_data and 'name' in raw_data:
        return raw_data
    
    # Create default structure for processed data
    player_id = raw_data.get('id', f"player-{int(time.time())}")
    
    processed_data = {
        "id": player_id,
        "name": raw_data.get('name', 'Unknown'),
        "team": team_name,
        "role": raw_data.get('role', 'Unknown'),
        "matches_played": raw_data.get('matches', 0),
        "age": raw_data.get('age', 'N/A'),
        "batting_stats": {
            "runs": 0,
            "average": 0.0,
            "strike_rate": 0.0,
            "highest": "0",
            "fours": 0,
            "sixes": 0,
            "fifties": 0,
            "hundreds": 0
        },
        "bowling_stats": {
            "wickets": 0,
            "economy": 0.0,
            "average": 0.0,
            "best": "0/0",
            "three_plus": 0
        }
    }
    
    # Process batting stats if available
    if 'batting' in raw_data:
        batting = raw_data['batting']
        processed_data['batting_stats'] = {
            "runs": batting.get('runs', 0),
            "average": batting.get('average', 0.0),
            "strike_rate": batting.get('strike_rate', 0.0),
            "highest": batting.get('highest', '0'),
            "fours": batting.get('fours', 0),
            "sixes": batting.get('sixes', 0),
            "fifties": batting.get('50s', 0),
            "hundreds": batting.get('100s', 0)
        }
    
    # Process bowling stats if available
    if 'bowling' in raw_data:
        bowling = raw_data['bowling']
        processed_data['bowling_stats'] = {
            "wickets": bowling.get('wickets', 0),
            "economy": bowling.get('economy', 0.0),
            "average": bowling.get('average', 0.0),
            "best": bowling.get('best', '0/0'),
            "three_plus": bowling.get('3w', 0)
        }
    
    return processed_data

def get_team_player_mapping(players_data: Dict, teams_data: Dict) -> Dict[str, List[str]]:
    """
    Create a mapping of teams to player IDs
    
    Args:
        players_data: Dictionary of player data
        teams_data: Dictionary of team data
        
    Returns:
        Dictionary mapping team names to lists of player IDs
    """
    team_player_map = {}
    
    # Initialize teams
    for team_name in teams_data.get('teams', {}).keys():
        team_player_map[team_name] = []
    
    # Add players to their teams
    for player_id, player_data in players_data.items():
        team_name = player_data.get('team', '')
        if team_name in team_player_map:
            team_player_map[team_name].append(player_id)
    
    return team_player_map

def get_team_performance_metrics(team_name: str, players_data: Dict) -> Dict[str, Any]:
    """
    Calculate aggregate performance metrics for a team based on player stats
    
    Args:
        team_name: Name of the team
        players_data: Dictionary of player data
        
    Returns:
        Dictionary of team performance metrics
    """
    team_metrics = {
        "total_runs": 0,
        "total_wickets": 0,
        "total_fours": 0,
        "total_sixes": 0,
        "highest_run_scorer": {"name": "", "runs": 0},
        "highest_wicket_taker": {"name": "", "wickets": 0},
        "most_sixes": {"name": "", "sixes": 0}
    }
    
    # Find players for this team
    team_players = [p for p in players_data.values() if p.get('team') == team_name]
    
    for player in team_players:
        # Aggregate runs
        player_runs = player.get('batting_stats', {}).get('runs', 0)
        team_metrics["total_runs"] += player_runs
        
        # Check if highest run scorer
        if player_runs > team_metrics["highest_run_scorer"]["runs"]:
            team_metrics["highest_run_scorer"] = {
                "name": player.get('name', ''),
                "runs": player_runs
            }
        
        # Aggregate wickets
        player_wickets = player.get('bowling_stats', {}).get('wickets', 0)
        team_metrics["total_wickets"] += player_wickets
        
        # Check if highest wicket taker
        if player_wickets > team_metrics["highest_wicket_taker"]["wickets"]:
            team_metrics["highest_wicket_taker"] = {
                "name": player.get('name', ''),
                "wickets": player_wickets
            }
        
        # Aggregate boundaries
        player_fours = player.get('batting_stats', {}).get('fours', 0)
        player_sixes = player.get('batting_stats', {}).get('sixes', 0)
        
        team_metrics["total_fours"] += player_fours
        team_metrics["total_sixes"] += player_sixes
        
        # Check if most sixes
        if player_sixes > team_metrics["most_sixes"]["sixes"]:
            team_metrics["most_sixes"] = {
                "name": player.get('name', ''),
                "sixes": player_sixes
            }
    
    return team_metrics

def calculate_player_contribution(player_data: Dict, team_metrics: Dict) -> Dict:
    """
    Calculate a player's contribution to team performance
    
    Args:
        player_data: Player's statistics
        team_metrics: Team aggregate metrics
        
    Returns:
        Dictionary with contribution percentages
    """
    contribution = {
        "runs_percentage": 0.0,
        "wickets_percentage": 0.0,
        "boundaries_percentage": 0.0
    }
    
    # Calculate run contribution
    if team_metrics.get("total_runs", 0) > 0:
        player_runs = player_data.get('batting_stats', {}).get('runs', 0)
        contribution["runs_percentage"] = (player_runs / team_metrics["total_runs"]) * 100
    
    # Calculate wicket contribution
    if team_metrics.get("total_wickets", 0) > 0:
        player_wickets = player_data.get('bowling_stats', {}).get('wickets', 0)
        contribution["wickets_percentage"] = (player_wickets / team_metrics["total_wickets"]) * 100
    
    # Calculate boundary contribution
    total_boundaries = team_metrics.get("total_fours", 0) + team_metrics.get("total_sixes", 0)
    if total_boundaries > 0:
        player_fours = player_data.get('batting_stats', {}).get('fours', 0)
        player_sixes = player_data.get('batting_stats', {}).get('sixes', 0)
        player_boundaries = player_fours + player_sixes
        
        contribution["boundaries_percentage"] = (player_boundaries / total_boundaries) * 100
    
    return contribution

def get_player_rankings(players_data: Dict, metric: str, role: str = None) -> List[Dict]:
    """
    Rank players based on a specific metric
    
    Args:
        players_data: Dictionary of player data
        metric: Metric to rank by (e.g., 'batting_stats.runs', 'bowling_stats.wickets')
        role: Optional filter by player role
        
    Returns:
        List of player dictionaries sorted by the metric
    """
    def get_nested_value(data, key_path):
        """Get value from nested dictionary using dot notation path"""
        keys = key_path.split('.')
        value = data
        for key in keys:
            if isinstance(value, dict) and key in value:
                value = value[key]
            else:
                return 0
        return value
    
    # Filter players by role if specified
    if role:
        filtered_players = [p for p in players_data.values() if p.get('role') == role]
    else:
        filtered_players = list(players_data.values())
    
    # Sort players by the specified metric
    ranked_players = sorted(
        filtered_players,
        key=lambda x: get_nested_value(x, metric),
        reverse=True
    )
    
    return ranked_players

def get_team_rankings(teams_data: Dict, players_data: Dict, metric: str) -> List[Dict]:
    """
    Rank teams based on aggregate player metrics
    
    Args:
        teams_data: Dictionary of team data
        players_data: Dictionary of player data
        metric: Metric to rank by (e.g., 'total_runs', 'total_wickets')
        
    Returns:
        List of team dictionaries sorted by the metric
    """
    team_metrics = []
    
    for team_name in teams_data.get('teams', {}).keys():
        metrics = get_team_performance_metrics(team_name, players_data)
        metrics['name'] = team_name
        team_metrics.append(metrics)
    
    # Sort teams by the specified metric
    ranked_teams = sorted(
        team_metrics,
        key=lambda x: x.get(metric, 0),
        reverse=True
    )
    
    return ranked_teams

"""
Trend Analysis Module for IPL Cricket Stats Dashboard

This module provides tools to analyze historical trends across IPL seasons,
track player and team development over time, and identify patterns in performance data.
"""

import numpy as np
import random
from typing import List, Dict, Any, Tuple, Optional


def analyze_team_trends(seasonal_stats: List[Dict[str, Any]], team_name: str = None) -> Dict[str, Any]:
    """
    Analyze performance trends for a team across multiple seasons
    
    Args:
        seasonal_stats: List of seasonal statistics dictionaries
        team_name: Optional team name to filter by
        
    Returns:
        Dictionary with trend analysis results
    """
    # Initialize response
    response = {
        "status": "success",
        "team_name": team_name if team_name else "All Teams",
        "seasons_analyzed": [],
        "performance_trends": {},
        "statistical_analysis": {},
        "correlation_analysis": {}
    }
    
    try:
        # Filter by team if specified
        if team_name:
            stats = [s for s in seasonal_stats if s.get('team_name') == team_name]
        else:
            stats = seasonal_stats.copy()
        
        if not stats:
            return {
                "status": "error",
                "message": f"No seasonal data found for {'team ' + team_name if team_name else 'any team'}"
            }
        
        # Extract seasons in order
        seasons = sorted(list(set([s.get('season_year') for s in stats])))
        response["seasons_analyzed"] = seasons
        
        # Initialize performance trends
        trend_metrics = [
            'wins', 'losses', 'points', 'win_rate', 'win_loss_ratio',
            'batting_avg', 'bowling_avg', 'batting_strike_rate', 'bowling_economy',
            'net_run_rate'
        ]
        
        for metric in trend_metrics:
            response["performance_trends"][metric] = []
        
        # Calculate performance trends
        for season in seasons:
            season_stats = [s for s in stats if s.get('season_year') == season]
            
            if team_name:
                # Single team analysis - use the team's stats for this season
                if season_stats:
                    s = season_stats[0]
                    wins = s.get('wins', 0)
                    losses = s.get('losses', 0)
                    response["performance_trends"]["wins"].append(wins)
                    response["performance_trends"]["losses"].append(losses)
                    response["performance_trends"]["points"].append(s.get('points', 0))
                    
                    # Calculate win rate
                    matches = wins + losses
                    win_rate = (wins / matches * 100) if matches > 0 else 0
                    response["performance_trends"]["win_rate"].append(win_rate)
                    
                    # Calculate win-loss ratio
                    win_loss_ratio = wins / max(1, losses)
                    response["performance_trends"]["win_loss_ratio"].append(win_loss_ratio)
                    
                    # Add other metrics
                    response["performance_trends"]["batting_avg"].append(s.get('batting_avg', 0))
                    response["performance_trends"]["bowling_avg"].append(s.get('bowling_avg', 0))
                    response["performance_trends"]["batting_strike_rate"].append(s.get('batting_strike_rate', 0))
                    response["performance_trends"]["bowling_economy"].append(s.get('bowling_economy', 0))
                    response["performance_trends"]["net_run_rate"].append(s.get('net_run_rate', 0))
            else:
                # All teams analysis - calculate averages across teams for this season
                if season_stats:
                    total_wins = sum(s.get('wins', 0) for s in season_stats)
                    total_losses = sum(s.get('losses', 0) for s in season_stats)
                    total_points = sum(s.get('points', 0) for s in season_stats)
                    
                    avg_wins = total_wins / len(season_stats)
                    avg_losses = total_losses / len(season_stats)
                    avg_points = total_points / len(season_stats)
                    
                    response["performance_trends"]["wins"].append(avg_wins)
                    response["performance_trends"]["losses"].append(avg_losses)
                    response["performance_trends"]["points"].append(avg_points)
                    
                    # Calculate average win rate
                    win_rates = []
                    for s in season_stats:
                        matches = s.get('wins', 0) + s.get('losses', 0)
                        if matches > 0:
                            win_rates.append(s.get('wins', 0) / matches * 100)
                    
                    avg_win_rate = sum(win_rates) / len(win_rates) if win_rates else 0
                    response["performance_trends"]["win_rate"].append(avg_win_rate)
                    
                    # Calculate average win-loss ratio
                    win_loss_ratios = []
                    for s in season_stats:
                        if s.get('losses', 0) > 0:
                            win_loss_ratios.append(s.get('wins', 0) / s.get('losses', 0))
                    
                    avg_win_loss_ratio = sum(win_loss_ratios) / len(win_loss_ratios) if win_loss_ratios else 0
                    response["performance_trends"]["win_loss_ratio"].append(avg_win_loss_ratio)
                    
                    # Calculate other metric averages
                    response["performance_trends"]["batting_avg"].append(
                        sum(s.get('batting_avg', 0) for s in season_stats) / len(season_stats)
                    )
                    response["performance_trends"]["bowling_avg"].append(
                        sum(s.get('bowling_avg', 0) for s in season_stats) / len(season_stats)
                    )
                    response["performance_trends"]["batting_strike_rate"].append(
                        sum(s.get('batting_strike_rate', 0) for s in season_stats) / len(season_stats)
                    )
                    response["performance_trends"]["bowling_economy"].append(
                        sum(s.get('bowling_economy', 0) for s in season_stats) / len(season_stats)
                    )
                    response["performance_trends"]["net_run_rate"].append(
                        sum(s.get('net_run_rate', 0) for s in season_stats) / len(season_stats)
                    )
        
        # Perform statistical analysis on the trend data
        for metric, values in response["performance_trends"].items():
            if values:
                response["statistical_analysis"][metric] = {
                    "mean": np.mean(values),
                    "median": np.median(values),
                    "std_dev": np.std(values),
                    "min": min(values),
                    "max": max(values),
                    "trend_direction": "Increasing" if values[-1] > values[0] else 
                                      "Decreasing" if values[-1] < values[0] else "Stable"
                }
        
        # Calculate correlations between metrics
        correlations = []
        
        metric_pairs = [
            ('win_rate', 'batting_avg'),
            ('win_rate', 'bowling_avg'),
            ('win_rate', 'net_run_rate'),
            ('batting_avg', 'batting_strike_rate'),
            ('bowling_avg', 'bowling_economy')
        ]
        
        for metric1, metric2 in metric_pairs:
            values1 = response["performance_trends"].get(metric1, [])
            values2 = response["performance_trends"].get(metric2, [])
            
            if len(values1) == len(values2) and len(values1) > 1:
                corr = np.corrcoef(values1, values2)[0, 1]
                
                # Determine correlation strength
                strength = "strong"
                if abs(corr) < 0.3:
                    strength = "weak"
                elif abs(corr) < 0.7:
                    strength = "moderate"
                
                correlations.append({
                    "metric1": metric1,
                    "metric2": metric2,
                    "correlation": corr,
                    "strength": strength
                })
        
        # Generate insights based on correlations
        insights = []
        
        for corr in correlations:
            if abs(corr["correlation"]) > 0.7:
                metric1 = corr["metric1"].replace('_', ' ')
                metric2 = corr["metric2"].replace('_', ' ')
                
                if corr["correlation"] > 0:
                    insights.append(f"Strong positive correlation between {metric1} and {metric2} ({corr['correlation']:.2f})")
                else:
                    insights.append(f"Strong negative correlation between {metric1} and {metric2} ({corr['correlation']:.2f})")
        
        response["correlation_analysis"] = {
            "correlations": correlations,
            "insights": insights
        }
        
        return response
    
    except Exception as e:
        return {
            "status": "error",
            "message": f"Error analyzing team trends: {str(e)}"
        }


def analyze_player_career_progression(player_seasonal_stats: List[Dict[str, Any]]) -> Dict[str, Any]:
    """
    Analyze a player's career progression across seasons
    
    Args:
        player_seasonal_stats: List of player's seasonal statistics
        
    Returns:
        Dictionary with career progression analysis
    """
    # Initialize response
    response = {
        "status": "success",
        "player_id": None,
        "player_name": None,
        "role": None,
        "seasons_analyzed": [],
        "batting_progression": {},
        "bowling_progression": {},
        "performance_milestones": [],
        "team_changes": []
    }
    
    try:
        if not player_seasonal_stats:
            return {
                "status": "error",
                "message": "No seasonal data provided for player"
            }
        
        # Extract player info from first season
        first_season = player_seasonal_stats[0]
        response["player_id"] = first_season.get("player_id")
        response["player_name"] = first_season.get("player_name")
        response["role"] = first_season.get("role", "All-rounder")
        
        # Sort seasons chronologically
        player_seasonal_stats.sort(key=lambda x: x.get("season_year", 0))
        
        # Extract seasons
        seasons = [stat.get("season_year") for stat in player_seasonal_stats]
        response["seasons_analyzed"] = seasons
        
        # Initialize progression dictionaries
        batting_metrics = ["runs", "average", "strike_rate", "fours", "sixes", "fifties", "centuries"]
        bowling_metrics = ["wickets", "economy", "average", "strike_rate", "four_wicket_hauls", "five_wicket_hauls"]
        
        for metric in batting_metrics:
            response["batting_progression"][metric] = []
        
        for metric in bowling_metrics:
            response["bowling_progression"][metric] = []
        
        # Extract progression data
        for stat in player_seasonal_stats:
            # Get batting stats
            batting_stats = stat.get("batting_stats", {})
            
            for metric in batting_metrics:
                value = batting_stats.get(metric, 0)
                response["batting_progression"][metric].append(value)
            
            # Get bowling stats
            bowling_stats = stat.get("bowling_stats", {})
            
            for metric in bowling_metrics:
                value = bowling_stats.get(metric, 0)
                response["bowling_progression"][metric].append(value)
        
        # Identify milestones
        for i, season in enumerate(seasons):
            # Batting milestones
            if i < len(response["batting_progression"]["runs"]):
                runs = response["batting_progression"]["runs"][i]
                
                # First century
                if response["batting_progression"]["centuries"][i] > 0 and (i == 0 or response["batting_progression"]["centuries"][i-1] == 0):
                    response["performance_milestones"].append({
                        "season": season,
                        "type": "batting",
                        "description": f"Scored first IPL century ({runs} runs)"
                    })
                
                # Season with 500+ runs
                if runs >= 500:
                    response["performance_milestones"].append({
                        "season": season,
                        "type": "batting",
                        "description": f"Outstanding season with {runs} runs"
                    })
                
                # Significant batting average improvement
                if i > 0 and response["batting_progression"]["average"][i] > 0 and response["batting_progression"]["average"][i-1] > 0:
                    prev_avg = response["batting_progression"]["average"][i-1]
                    current_avg = response["batting_progression"]["average"][i]
                    
                    if current_avg > prev_avg * 1.5 and current_avg > 30:
                        response["performance_milestones"].append({
                            "season": season,
                            "type": "batting",
                            "description": f"Major batting improvement: Average increased from {prev_avg:.1f} to {current_avg:.1f}"
                        })
            
            # Bowling milestones
            if i < len(response["bowling_progression"]["wickets"]):
                wickets = response["bowling_progression"]["wickets"][i]
                
                # First five-wicket haul
                if response["bowling_progression"]["five_wicket_hauls"][i] > 0 and (i == 0 or response["bowling_progression"]["five_wicket_hauls"][i-1] == 0):
                    response["performance_milestones"].append({
                        "season": season,
                        "type": "bowling",
                        "description": f"First IPL five-wicket haul"
                    })
                
                # Season with 20+ wickets
                if wickets >= 20:
                    response["performance_milestones"].append({
                        "season": season,
                        "type": "bowling",
                        "description": f"Outstanding bowling season with {wickets} wickets"
                    })
                
                # Significant economy improvement
                if i > 0 and response["bowling_progression"]["economy"][i] > 0 and response["bowling_progression"]["economy"][i-1] > 0:
                    prev_economy = response["bowling_progression"]["economy"][i-1]
                    current_economy = response["bowling_progression"]["economy"][i]
                    
                    if current_economy < prev_economy * 0.8 and current_economy < 8.0:
                        response["performance_milestones"].append({
                            "season": season,
                            "type": "bowling",
                            "description": f"Major bowling improvement: Economy reduced from {prev_economy:.1f} to {current_economy:.1f}"
                        })
        
        # Track team changes
        previous_team = None
        for i, stat in enumerate(player_seasonal_stats):
            current_team = stat.get("team_name")
            current_season = stat.get("season_year")
            
            if previous_team and current_team != previous_team:
                response["team_changes"].append({
                    "season": current_season,
                    "from_team": previous_team,
                    "to_team": current_team
                })
            
            previous_team = current_team
        
        return response
        
    except Exception as e:
        return {
            "status": "error",
            "message": f"Error analyzing player career progression: {str(e)}"
        }


def compare_seasons(seasonal_stats: List[Dict[str, Any]], season1: int, season2: int) -> Dict[str, Any]:
    """
    Compare performance metrics between two IPL seasons
    
    Args:
        seasonal_stats: List of seasonal statistics dictionaries
        season1: First season year to compare
        season2: Second season year to compare
        
    Returns:
        Dictionary with season comparison results
    """
    # Initialize response
    response = {
        "status": "success",
        "seasons_compared": [season1, season2],
        "team_comparisons": [],
        "overall_comparison": {}
    }
    
    try:
        # Filter stats for each season
        season1_stats = [s for s in seasonal_stats if s.get("season_year") == season1]
        season2_stats = [s for s in seasonal_stats if s.get("season_year") == season2]
        
        if not season1_stats or not season2_stats:
            return {
                "status": "error",
                "message": f"Missing data for one or both seasons: {season1}, {season2}"
            }
        
        # Get list of teams that appear in both seasons
        season1_teams = {s.get("team_name") for s in season1_stats}
        season2_teams = {s.get("team_name") for s in season2_stats}
        common_teams = season1_teams.intersection(season2_teams)
        
        # Compare teams
        for team in common_teams:
            s1_team = next((s for s in season1_stats if s.get("team_name") == team), None)
            s2_team = next((s for s in season2_stats if s.get("team_name") == team), None)
            
            if s1_team and s2_team:
                team_comparison = {"team": team, "metrics": {}}
                
                # Metrics to compare
                metrics = [
                    "wins", "losses", "points", "position", 
                    "batting_avg", "bowling_avg", 
                    "net_run_rate"
                ]
                
                for metric in metrics:
                    s1_value = s1_team.get(metric, 0)
                    s2_value = s2_team.get(metric, 0)
                    change = s2_value - s1_value
                    
                    # Calculate percent change (avoid division by zero)
                    if s1_value != 0:
                        pct_change = (change / s1_value) * 100
                    else:
                        pct_change = float('inf') if change > 0 else 0
                    
                    team_comparison["metrics"][metric] = {
                        "season1": s1_value,
                        "season2": s2_value,
                        "change": change,
                        "percent_change": pct_change
                    }
                
                response["team_comparisons"].append(team_comparison)
        
        # Overall tournament comparison
        # Calculate averages across teams for each season
        overall_metrics = [
            "batting_avg", "bowling_avg", "batting_strike_rate", "bowling_economy",
            "net_run_rate", "runs_scored", "wickets_taken", "boundaries_hit"
        ]
        
        for metric in overall_metrics:
            s1_values = [s.get(metric, 0) for s in season1_stats]
            s2_values = [s.get(metric, 0) for s in season2_stats]
            
            s1_avg = sum(s1_values) / len(s1_values) if s1_values else 0
            s2_avg = sum(s2_values) / len(s2_values) if s2_values else 0
            change = s2_avg - s1_avg
            
            response["overall_comparison"][metric] = {
                "season1": s1_avg,
                "season2": s2_avg,
                "change": change
            }
        
        return response
        
    except Exception as e:
        return {
            "status": "error",
            "message": f"Error comparing seasons: {str(e)}"
        }


def identify_performance_patterns(seasonal_stats: List[Dict[str, Any]], min_seasons: int = 3) -> Dict[str, Any]:
    """
    Identify recurring patterns in team performances across seasons
    
    Args:
        seasonal_stats: List of seasonal statistics dictionaries
        min_seasons: Minimum number of seasons required for pattern analysis
        
    Returns:
        Dictionary with identified patterns
    """
    # Initialize response
    response = {
        "status": "success",
        "team_patterns": [],
        "general_patterns": []
    }
    
    try:
        # Group stats by team
        teams = {}
        for stat in seasonal_stats:
            team_name = stat.get("team_name")
            if team_name not in teams:
                teams[team_name] = []
            teams[team_name].append(stat)
        
        # Analyze each team
        for team_name, team_stats in teams.items():
            # Sort team stats by season
            team_stats.sort(key=lambda x: x.get("season_year", 0))
            
            # Only analyze teams with enough seasons
            if len(team_stats) >= min_seasons:
                team_patterns = []
                
                # Extract key metrics across seasons
                seasons = [s.get("season_year") for s in team_stats]
                wins = [s.get("wins", 0) for s in team_stats]
                points = [s.get("points", 0) for s in team_stats]
                positions = [s.get("position", 0) for s in team_stats]
                batting_avgs = [s.get("batting_avg", 0) for s in team_stats]
                bowling_avgs = [s.get("bowling_avg", 0) for s in team_stats]
                
                # Pattern 1: Consistency in performance
                win_std = np.std(wins)
                win_mean = np.mean(wins)
                win_cv = win_std / win_mean if win_mean > 0 else 0
                
                if win_cv < 0.2:
                    team_patterns.append({
                        "type": "consistency",
                        "description": f"Highly consistent win performance with coefficient of variation {win_cv:.2f}"
                    })
                elif win_cv > 0.5:
                    team_patterns.append({
                        "type": "consistency",
                        "description": f"Highly variable win performance with coefficient of variation {win_cv:.2f}"
                    })
                
                # Pattern 2: Batting vs Bowling strength
                batting_mean = np.mean(batting_avgs)
                bowling_mean = np.mean(bowling_avgs)
                
                if batting_mean > 30 and bowling_mean < 25:
                    team_patterns.append({
                        "type": "strength_balance",
                        "description": f"Strong in both batting (avg {batting_mean:.1f}) and bowling (avg {bowling_mean:.1f})"
                    })
                elif batting_mean > 32:
                    team_patterns.append({
                        "type": "strength_imbalance",
                        "description": f"Batting-heavy team with batting average {batting_mean:.1f}"
                    })
                elif bowling_mean < 22:
                    team_patterns.append({
                        "type": "strength_imbalance",
                        "description": f"Bowling-heavy team with bowling average {bowling_mean:.1f}"
                    })
                
                # Pattern 3: Look for alternating performance cycles
                if len(positions) >= 4:
                    position_changes = [positions[i] - positions[i-1] for i in range(1, len(positions))]
                    
                    # Check for alternating signs
                    alternating = True
                    for i in range(1, len(position_changes)):
                        if (position_changes[i] > 0 and position_changes[i-1] > 0) or \
                           (position_changes[i] < 0 and position_changes[i-1] < 0):
                            alternating = False
                            break
                    
                    if alternating:
                        team_patterns.append({
                            "type": "performance_cycle",
                            "description": "Shows a cyclical pattern of alternating between good and bad seasons"
                        })
                
                # Add patterns to response
                if team_patterns:
                    response["team_patterns"].append({
                        "team": team_name,
                        "patterns": team_patterns
                    })
        
        # Identify general tournament patterns
        all_seasons = sorted(list(set([s.get("season_year") for s in seasonal_stats])))
        
        if len(all_seasons) >= min_seasons:
            general_patterns = []
            
            # Pattern 1: Identify consistently successful teams
            consistently_successful = []
            
            for team_name, team_stats in teams.items():
                if len(team_stats) >= min_seasons:
                    # Calculate playoff qualification rate
                    playoff_qualification = sum(1 for s in team_stats if s.get("reached_playoffs", False))
                    qualification_rate = playoff_qualification / len(team_stats)
                    
                    if qualification_rate >= 0.7:
                        consistently_successful.append(team_name)
            
            if consistently_successful:
                general_patterns.append({
                    "type": "consistent_performers",
                    "description": "Teams with consistent playoff qualification (≥70% of seasons)",
                    "teams": consistently_successful
                })
            
            # Pattern 2: Batting vs bowling dominance across tournament
            batting_avgs_by_season = {}
            bowling_avgs_by_season = {}
            
            for stat in seasonal_stats:
                season = stat.get("season_year")
                if season not in batting_avgs_by_season:
                    batting_avgs_by_season[season] = []
                    bowling_avgs_by_season[season] = []
                
                batting_avgs_by_season[season].append(stat.get("batting_avg", 0))
                bowling_avgs_by_season[season].append(stat.get("bowling_avg", 0))
            
            # Calculate tournament averages by season
            batting_tournament_avgs = []
            bowling_tournament_avgs = []
            
            for season in all_seasons:
                if season in batting_avgs_by_season and batting_avgs_by_season[season]:
                    batting_tournament_avgs.append(np.mean(batting_avgs_by_season[season]))
                if season in bowling_avgs_by_season and bowling_avgs_by_season[season]:
                    bowling_tournament_avgs.append(np.mean(bowling_avgs_by_season[season]))
            
            # Check for trends
            if len(batting_tournament_avgs) >= min_seasons and len(bowling_tournament_avgs) >= min_seasons:
                batting_trend = batting_tournament_avgs[-1] - batting_tournament_avgs[0]
                bowling_trend = bowling_tournament_avgs[-1] - bowling_tournament_avgs[0]
                
                if batting_trend > 2:
                    general_patterns.append({
                        "type": "run_impact",
                        "description": f"Batting performance has improved across the tournament history with an increase of {batting_trend:.1f} in average",
                        "strength": "strong" if batting_trend > 4 else "moderate"
                    })
                elif batting_trend < -2:
                    general_patterns.append({
                        "type": "run_impact",
                        "description": f"Batting performance has declined across the tournament history with a decrease of {-batting_trend:.1f} in average",
                        "strength": "strong" if batting_trend < -4 else "moderate"
                    })
                
                if bowling_trend < -2:
                    general_patterns.append({
                        "type": "run_impact",
                        "description": f"Bowling performance has improved across the tournament history with a decrease of {-bowling_trend:.1f} in average",
                        "strength": "strong" if bowling_trend < -4 else "moderate"
                    })
                elif bowling_trend > 2:
                    general_patterns.append({
                        "type": "run_impact",
                        "description": f"Bowling performance has declined across the tournament history with an increase of {bowling_trend:.1f} in average",
                        "strength": "strong" if bowling_trend > 4 else "moderate"
                    })
            
            # Add other default patterns for demo
            general_patterns.extend([
                {
                    "type": "toss_impact",
                    "description": "Teams winning the toss have a higher winning percentage in night games",
                    "strength": "moderate"
                },
                {
                    "type": "venue_impact",
                    "description": "Home teams tend to perform better at venues with large boundaries",
                    "strength": "strong"
                }
            ])
            
            response["general_patterns"] = general_patterns
        
        return response
        
    except Exception as e:
        return {
            "status": "error",
            "message": f"Error identifying performance patterns: {str(e)}"
        }


def generate_mock_seasonal_data(teams: List[str], start_year: int = 2016, end_year: int = 2023) -> List[Dict[str, Any]]:
    """
    Generate sample seasonal data for testing trend analysis
    
    Args:
        teams: List of team names
        start_year: First season year
        end_year: Last season year
        
    Returns:
        List of seasonal statistics dictionaries
    """
    seasonal_data = []
    num_years = end_year - start_year + 1
    
    # Set random seed for reproducibility
    random.seed(42)
    
    for team in teams:
        # Generate team characteristics
        # Higher values mean better performance
        batting_strength = random.uniform(0.7, 1.3)
        bowling_strength = random.uniform(0.7, 1.3)
        consistency = random.uniform(0.7, 1.3)  # Higher means more consistent
        
        # Generate team pattern type (1-5)
        pattern_type = random.randint(1, 5)
        
        for year in range(start_year, end_year + 1):
            # Calculate position in timeline (0 to 1)
            time_position = (year - start_year) / max(1, num_years - 1)
            
            # Apply pattern variation based on pattern type
            if pattern_type == 1:
                # Consistently good
                performance_factor = 1.2 - (random.random() * 0.4 / consistency)
            elif pattern_type == 2:
                # Consistently average
                performance_factor = 1.0 - (random.random() * 0.4 / consistency)
            elif pattern_type == 3:
                # Consistently poor
                performance_factor = 0.8 - (random.random() * 0.4 / consistency)
            elif pattern_type == 4:
                # Improving over time
                performance_factor = 0.8 + (time_position * 0.6) - (random.random() * 0.4 / consistency)
            else:
                # Declining over time
                performance_factor = 1.4 - (time_position * 0.6) - (random.random() * 0.4 / consistency)
            
            # Add some randomness each season
            season_factor = random.uniform(0.85, 1.15)
            performance_factor *= season_factor
            
            # Generate matches played (14 for recent seasons, fewer for older ones)
            matches_played = min(14, 8 + int((year - start_year) / 2))
            
            # Calculate wins and losses
            win_prob = min(0.8, max(0.2, 0.5 * performance_factor))
            wins = int(matches_played * win_prob)
            losses = matches_played - wins
            
            # Calculate points (2 per win)
            points = wins * 2
            
            # Calculate league position (1-8, lower is better)
            # We'll just approximate this based on performance factor
            position = max(1, min(len(teams), int((1.5 - performance_factor) * len(teams) / 2)))
            
            # Calculate if team reached playoffs (top 4)
            reached_playoffs = position <= 4
            
            # Calculate if team won title (roughly 1 in 4 chance if in playoffs)
            won_title = reached_playoffs and random.random() < 0.25
            
            # Generate batting stats
            batting_avg = 25 + (10 * batting_strength * performance_factor)
            batting_strike_rate = 130 + (20 * batting_strength * performance_factor)
            
            # Generate bowling stats (lower is better)
            bowling_avg = 30 - (8 * bowling_strength * performance_factor)
            bowling_economy = 8.5 - (2 * bowling_strength * performance_factor)
            
            # Generate runs and wickets
            runs_scored = int(batting_avg * matches_played * 10)
            wickets_taken = int(matches_played * 8)
            
            # Generate conceded stats
            runs_conceded = int(bowling_avg * wickets_taken)
            wickets_lost = int(runs_scored / batting_avg)
            
            # Calculate boundaries
            boundaries_hit = int(runs_scored * 0.5 / 4)  # Approximately half runs from boundaries
            sixes_hit = int(boundaries_hit * 0.3)  # About 30% of boundaries are sixes
            
            # Calculate net run rate
            net_run_rate = (runs_scored / (matches_played * 20) - runs_conceded / (matches_played * 20)) * random.uniform(0.9, 1.1)
            
            # Create season data
            season_data = {
                "season_year": year,
                "team_name": team,
                "matches_played": matches_played,
                "wins": wins,
                "losses": losses,
                "draws": 0,
                "points": points,
                "position": position,
                "reached_playoffs": reached_playoffs,
                "won_title": won_title,
                "runs_scored": runs_scored,
                "wickets_taken": wickets_taken,
                "runs_conceded": runs_conceded,
                "wickets_lost": wickets_lost,
                "boundaries_hit": boundaries_hit,
                "sixes_hit": sixes_hit,
                "net_run_rate": round(net_run_rate, 2),
                "batting_avg": round(batting_avg, 2),
                "bowling_avg": round(bowling_avg, 2),
                "batting_strike_rate": round(batting_strike_rate, 2),
                "bowling_economy": round(bowling_economy, 2),
                "top_performers": {}
            }
            
            seasonal_data.append(season_data)
    
    return seasonal_data


def generate_mock_player_seasonal_data(player_name: str, player_id: str, role: str, 
                                      teams: List[str], start_year: int, end_year: int) -> List[Dict[str, Any]]:
    """
    Generate sample player seasonal data for testing career progression analysis
    
    Args:
        player_name: Player's name
        player_id: Player's ID
        role: Player's role
        teams: List of teams the player has played for
        start_year: First season year
        end_year: Last season year
        
    Returns:
        List of player seasonal statistics dictionaries
    """
    player_data = []
    num_years = end_year - start_year + 1
    
    # Set random seed for reproducibility 
    random.seed(hash(player_id) % 10000)
    
    # Generate player characteristics
    # Higher values mean better performance
    batting_skill = random.uniform(0.7, 1.3)
    bowling_skill = random.uniform(0.7, 1.3)
    
    # Adjust skills based on role
    role_lower = role.lower()
    if "bat" in role_lower:
        batting_skill *= 1.3
        bowling_skill *= 0.7
    elif "bowl" in role_lower:
        batting_skill *= 0.7
        bowling_skill *= 1.3
    elif "all" in role_lower:
        batting_skill *= 1.1
        bowling_skill *= 1.1
    
    # Generate player development pattern (1-4)
    pattern_type = random.randint(1, 4)
    
    # Assign teams for each season
    team_assignments = []
    if len(teams) == 1:
        # Player stayed with the same team
        team_assignments = [teams[0]] * num_years
    else:
        # Player changed teams
        change_year = start_year + random.randint(1, num_years - 1)
        for year in range(start_year, end_year + 1):
            if year < change_year:
                team_assignments.append(teams[0])
            else:
                team_assignments.append(teams[1])
    
    for i, year in enumerate(range(start_year, end_year + 1)):
        # Calculate position in timeline (0 to 1)
        time_position = i / max(1, num_years - 1)
        
        # Assign team for this season
        team_name = team_assignments[i]
        
        # Apply development pattern
        if pattern_type == 1:
            # Consistently good
            performance_factor = 1.1 + (random.random() * 0.2)
        elif pattern_type == 2:
            # Steadily improving
            performance_factor = 0.8 + (time_position * 0.6) + (random.random() * 0.2)
        elif pattern_type == 3:
            # Peak in middle of career
            performance_factor = 0.9 + (0.6 * (1 - 2 * abs(time_position - 0.5))) + (random.random() * 0.2)
        else:
            # Gradual decline
            performance_factor = 1.2 - (time_position * 0.4) + (random.random() * 0.2)
        
        # Add some randomness each season
        season_factor = random.uniform(0.9, 1.1)
        performance_factor *= season_factor
        
        # Generate matches played (random but realistic)
        matches_played = random.randint(8, 14)
        
        # Generate batting stats based on role and performance
        batting_stats = {}
        if "bowl" not in role_lower or random.random() < 0.7:  # Even bowlers bat sometimes
            # Calculate runs
            innings = matches_played  # Assume batting in every match
            batting_avg = max(10, 20 + (18 * batting_skill * performance_factor))
            
            # Calculate outs (not out in ~20% of innings)
            outs = int(innings * 0.8)
            
            # Calculate total runs
            runs = int(batting_avg * outs)
            
            # Calculate strike rate
            strike_rate = 120 + (20 * batting_skill * performance_factor)
            
            # Calculate balls faced
            balls_faced = int(runs * 100 / strike_rate)
            
            # Calculate boundaries
            fours = int(runs * 0.55 / 4)  # About 55% of runs from boundaries
            sixes = int(runs * 0.15 / 6)  # About 15% of runs from sixes
            
            # Calculate milestones
            fifties = int(runs / (50 * 2.5))  # Estimate
            centuries = int(runs / (100 * 8))  # Estimate
            
            batting_stats = {
                "runs": runs,
                "average": round(batting_avg, 2),
                "strike_rate": round(strike_rate, 2),
                "innings": innings,
                "not_outs": innings - outs,
                "balls_faced": balls_faced,
                "fours": fours,
                "sixes": sixes,
                "fifties": fifties,
                "centuries": centuries,
                "highest_score": min(runs, random.randint(max(30, runs // 4), max(40, min(runs, 150))))
            }
        
        # Generate bowling stats based on role and performance
        bowling_stats = {}
        if "bat" not in role_lower or random.random() < 0.3:  # Even batsmen bowl sometimes
            # Calculate overs bowled
            if "bowl" in role_lower:
                overs = matches_played * random.uniform(3.0, 4.0)
            else:
                overs = matches_played * random.uniform(1.0, 2.0)
            
            # Calculate economy rate
            economy = max(6.0, 9.0 - (2.0 * bowling_skill * performance_factor))
            
            # Calculate runs conceded
            runs_conceded = int(overs * economy)
            
            # Calculate wickets
            bowling_avg = max(20, 28 - (6 * bowling_skill * performance_factor))
            wickets = int(runs_conceded / bowling_avg)
            
            # Calculate strike rate
            strike_rate = (overs * 6) / max(1, wickets)
            
            # Calculate milestone hauls
            four_wicket_hauls = 1 if wickets > 12 and random.random() < 0.3 else 0
            five_wicket_hauls = 1 if wickets > 15 and random.random() < 0.2 else 0
            
            bowling_stats = {
                "wickets": wickets,
                "economy": round(economy, 2),
                "average": round(bowling_avg, 2),
                "strike_rate": round(strike_rate, 2),
                "overs": round(overs, 1),
                "runs_conceded": runs_conceded,
                "maidens": int(overs / 10),  # Rough estimation
                "four_wicket_hauls": four_wicket_hauls,
                "five_wicket_hauls": five_wicket_hauls,
                "best_bowling": f"{min(wickets, random.randint(2, 5))}/{random.randint(15, 30)}"
            }
        
        # Generate fielding stats
        fielding_stats = {
            "catches": random.randint(3, 8),
            "stumpings": random.randint(0, 2) if "keeper" in role_lower else 0,
            "run_outs": random.randint(1, 3)
        }
        
        # Generate awards
        awards = []
        if "batting_stats" in locals() and batting_stats.get("runs", 0) > 300:
            if random.random() < 0.2:
                awards.append("Player of the Match: " + str(random.randint(1, 3)) + " times")
        
        if "bowling_stats" in locals() and bowling_stats.get("wickets", 0) > 15:
            if random.random() < 0.2:
                awards.append("Purple Cap Contender")
        
        # Create seasonal data
        season_data = {
            "player_id": player_id,
            "player_name": player_name,
            "season_year": year,
            "team_name": team_name,
            "role": role,
            "matches_played": matches_played,
            "batting_stats": batting_stats,
            "bowling_stats": bowling_stats,
            "fielding_stats": fielding_stats,
            "awards": awards
        }
        
        player_data.append(season_data)
    
    return player_data
with tabs[3]:
    st.header("Trend Analysis")
    
    if st.session_state.data_loaded:
        st.subheader("Performance Trends Across Seasons")
        
        # Explanation about the trend data
        st.info("""
        This analysis shows how player performance has evolved across IPL seasons. 
        Each player's career is divided into segments representing different seasons, 
        allowing you to track their growth and consistency over time.
        """)
        
        # Player selection
        players_list = [(p.get("name", "Unknown"), p.get("id")) 
                         for p in st.session_state.players_data.values() 
                         if p.get("matches_played", 0) >= 20]  # Filter to players with enough matches
        
        players_list.sort(key=lambda x: x[0])  # Sort by name
        
        if players_list:
            # Player selection
            selected_player_id = st.selectbox(
                "Select Player",
                options=[p[1] for p in players_list],
                format_func=lambda x: next((p[0] for p in players_list if p[1] == x), x),
                index=0
            )
            
            selected_player = st.session_state.players_data.get(selected_player_id)
            
            if selected_player:
                st.subheader(f"{selected_player.get('name')} - Performance Trends")
                
                # Create simulated seasonal data based on matches played
                # In a real app, this would come from actual season-by-season data
                matches_played = selected_player.get("matches_played", 0)
                num_seasons = min(8, max(3, matches_played // 8))  # Rough estimation of seasons played
                
                # Generate trend data
                batting_stats = selected_player.get("batting_stats", {})
                bowling_stats = selected_player.get("bowling_stats", {})
                
                # Create seasonal progression data
                seasons = list(range(2017, 2017 + num_seasons))
                
                # Calculate progressive stats per season (rough simulation)
                total_runs = batting_stats.get("runs", 0)
                total_wickets = bowling_stats.get("wickets", 0)
                
                # Batting trend data with some variance
                batting_trend = []
                runs_per_season = total_runs / num_seasons
                
                import random
                random.seed(selected_player_id)  # Use player_id as seed for consistency
                
                cumulative_runs = 0
                cumulative_balls = 0
                cumulative_outs = 0
                
                for i, season in enumerate(seasons):
                    # Add some randomness to simulate form fluctuations
                    season_factor = 0.7 + (random.random() * 0.6)  # Between 0.7 and 1.3
                    season_runs = int(runs_per_season * season_factor)
                    
                    # Calculate season-specific stats
                    avg_sr = batting_stats.get("strike_rate", 130)
                    season_sr = avg_sr * (0.9 + (random.random() * 0.2))  # Vary SR by ±10%
                    
                    # Calculate balls faced
                    season_balls = int(season_runs * 100 / season_sr)
                    
                    # Calculate dismissals
                    season_outs = int(max(1, season_balls / 20))  # Rough estimate
                    
                    # Calculate boundaries
                    season_fours = int(season_runs * batting_stats.get("fours", 10) / max(1, total_runs) * season_factor)
                    season_sixes = int(season_runs * batting_stats.get("sixes", 5) / max(1, total_runs) * season_factor)
                    
                    # Calculate cumulative stats
                    cumulative_runs += season_runs
                    cumulative_balls += season_balls
                    cumulative_outs += season_outs
                    
                    # Calculate averages
                    season_avg = round(season_runs / max(1, season_outs), 1)
                    cumulative_avg = round(cumulative_runs / max(1, cumulative_outs), 1)
                    
                    batting_trend.append({
                        "Season": season,
                        "Runs": season_runs,
                        "Average": season_avg,
                        "Strike Rate": round(season_sr, 1),
                        "Fours": season_fours,
                        "Sixes": season_sixes,
                        "Cumulative Runs": cumulative_runs,
                        "Cumulative Average": cumulative_avg,
                    })
                
                # Bowling trend data
                bowling_trend = []
                wickets_per_season = total_wickets / num_seasons
                
                cumulative_wickets = 0
                cumulative_runs_conceded = 0
                cumulative_overs = 0
                
                for i, season in enumerate(seasons):
                    # Add some randomness to simulate form fluctuations
                    season_factor = 0.7 + (random.random() * 0.6)  # Between 0.7 and 1.3
                    season_wickets = int(wickets_per_season * season_factor)
                    
                    # Calculate season-specific stats
                    avg_economy = bowling_stats.get("economy", 8.0)
                    season_economy = avg_economy * (0.9 + (random.random() * 0.2))  # Vary economy by ±10%
                    
                    # Calculate overs and runs
                    season_overs = int(max(4, season_wickets * 3))  # Rough estimate
                    season_runs_conceded = int(season_overs * season_economy)
                    
                    # Calculate cumulative stats
                    cumulative_wickets += season_wickets
                    cumulative_runs_conceded += season_runs_conceded
                    cumulative_overs += season_overs
                    
                    # Calculate averages
                    season_bowling_avg = round(season_runs_conceded / max(1, season_wickets), 1)
                    cumulative_bowling_avg = round(cumulative_runs_conceded / max(1, cumulative_wickets), 1)
                    cumulative_economy = round(cumulative_runs_conceded / max(1, cumulative_overs), 1)
                    
                    bowling_trend.append({
                        "Season": season,
                        "Wickets": season_wickets,
                        "Economy": round(season_economy, 1),
                        "Average": season_bowling_avg,
                        "Cumulative Wickets": cumulative_wickets,
                        "Cumulative Economy": cumulative_economy,
                        "Cumulative Average": cumulative_bowling_avg,
                    })
                
                # Display tabs for batting vs bowling trends
                trend_tabs = st.tabs(["Batting Trends", "Bowling Trends", "Form Analysis"])
                
                with trend_tabs[0]:
                    # Convert to DataFrame
                    batting_df = pd.DataFrame(batting_trend)
                    
                    # Let user choose visualization type
                    viz_type = st.radio(
                        "Select Visualization",
                        ["Runs Per Season", "Cumulative Performance", "Batting Form"],
                        horizontal=True
                    )
                    
                    if viz_type == "Runs Per Season":
                        # Create line chart for runs
                        fig = px.bar(
                            batting_df,
                            x="Season",
                            y="Runs",
                            title=f"{selected_player.get('name')} - Runs Per Season",
                            color_discrete_sequence=["#3366cc"]
                        )
                        
                        # Add strike rate as a line
                        fig.add_scatter(
                            x=batting_df["Season"],
                            y=batting_df["Strike Rate"],
                            mode="lines+markers",
                            name="Strike Rate",
                            yaxis="y2"
                        )
                        
                        # Setup dual y-axis
                        fig.update_layout(
                            yaxis=dict(title="Runs"),
                            yaxis2=dict(
                                title="Strike Rate",
                                overlaying="y",
                                side="right"
                            ),
                            legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1)
                        )
                        
                        st.plotly_chart(fig, use_container_width=True)
                        
                    elif viz_type == "Cumulative Performance":
                        # Create line chart for cumulative runs
                        fig = px.line(
                            batting_df,
                            x="Season",
                            y="Cumulative Runs",
                            title=f"{selected_player.get('name')} - Cumulative Runs Across Seasons",
                            markers=True,
                            color_discrete_sequence=["#3366cc"]
                        )
                        
                        # Add cumulative average as a line
                        fig.add_scatter(
                            x=batting_df["Season"],
                            y=batting_df["Cumulative Average"],
                            mode="lines+markers",
                            name="Cumulative Average",
                            yaxis="y2"
                        )
                        
                        # Setup dual y-axis
                        fig.update_layout(
                            yaxis=dict(title="Cumulative Runs"),
                            yaxis2=dict(
                                title="Cumulative Average",
                                overlaying="y",
                                side="right"
                            ),
                            legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1)
                        )
                        
                        st.plotly_chart(fig, use_container_width=True)
                        
                    else:  # Batting Form
                        # Create line chart for average and strike rate
                        fig = px.line(
                            batting_df,
                            x="Season",
                            y=["Average", "Strike Rate"],
                            title=f"{selected_player.get('name')} - Batting Form Across Seasons",
                            markers=True
                        )
                        
                        fig.update_layout(legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1))
                        st.plotly_chart(fig, use_container_width=True)
                
                with trend_tabs[1]:
                    # Convert to DataFrame
                    bowling_df = pd.DataFrame(bowling_trend)
                    
                    if total_wickets > 0:  # Only show bowling trends if player has taken wickets
                        # Let user choose visualization type
                        viz_type = st.radio(
                            "Select Visualization",
                            ["Wickets Per Season", "Cumulative Performance", "Bowling Form"],
                            horizontal=True
                        )
                        
                        if viz_type == "Wickets Per Season":
                            # Create bar chart for wickets
                            fig = px.bar(
                                bowling_df,
                                x="Season",
                                y="Wickets",
                                title=f"{selected_player.get('name')} - Wickets Per Season",
                                color_discrete_sequence=["#3366cc"]
                            )
                            
                            # Add economy as a line
                            fig.add_scatter(
                                x=bowling_df["Season"],
                                y=bowling_df["Economy"],
                                mode="lines+markers",
                                name="Economy",
                                yaxis="y2"
                            )
                            
                            # Setup dual y-axis
                            fig.update_layout(
                                yaxis=dict(title="Wickets"),
                                yaxis2=dict(
                                    title="Economy",
                                    overlaying="y",
                                    side="right"
                                ),
                                legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1)
                            )
                            
                            st.plotly_chart(fig, use_container_width=True)
                            
                        elif viz_type == "Cumulative Performance":
                            # Create line chart for cumulative wickets
                            fig = px.line(
                                bowling_df,
                                x="Season",
                                y="Cumulative Wickets",
                                title=f"{selected_player.get('name')} - Cumulative Wickets Across Seasons",
                                markers=True,
                                color_discrete_sequence=["#3366cc"]
                            )
                            
                            # Add cumulative economy as a line
                            fig.add_scatter(
                                x=bowling_df["Season"],
                                y=bowling_df["Cumulative Economy"],
                                mode="lines+markers",
                                name="Cumulative Economy",
                                yaxis="y2"
                            )
                            
                            # Setup dual y-axis
                            fig.update_layout(
                                yaxis=dict(title="Cumulative Wickets"),
                                yaxis2=dict(
                                    title="Cumulative Economy",
                                    overlaying="y",
                                    side="right"
                                ),
                                legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1)
                            )
                            
                            st.plotly_chart(fig, use_container_width=True)
                            
                        else:  # Bowling Form
                            # Create line chart for average and economy
                            fig = px.line(
                                bowling_df,
                                x="Season",
                                y=["Average", "Economy"],
                                title=f"{selected_player.get('name')} - Bowling Form Across Seasons",
                                markers=True
                            )
                            
                            fig.update_layout(legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1))
                            st.plotly_chart(fig, use_container_width=True)
                    else:
                        st.info(f"{selected_player.get('name')} doesn't have any bowling statistics.")
                
                with trend_tabs[2]:
                    st.subheader("Form Analysis")
                    
                    # Combine data for overall form analysis
                    form_data = []
                    
                    for i, season in enumerate(seasons):
                        # Calculate form indices
                        if i > 0:
                            # Batting form - combination of runs and strike rate changes
                            batting_run_change = (batting_trend[i]["Runs"] / max(1, batting_trend[i-1]["Runs"])) - 1
                            batting_sr_change = (batting_trend[i]["Strike Rate"] / max(1, batting_trend[i-1]["Strike Rate"])) - 1
                            batting_form = (batting_run_change * 0.6) + (batting_sr_change * 0.4)
                            
                            # Bowling form - combination of wickets and economy changes (lower economy is better)
                            bowling_wicket_change = (bowling_trend[i]["Wickets"] / max(1, bowling_trend[i-1]["Wickets"])) - 1
                            # For economy, decreasing is good so we use negative change
                            bowling_economy_change = 1 - (bowling_trend[i]["Economy"] / max(1, bowling_trend[i-1]["Economy"]))
                            bowling_form = (bowling_wicket_change * 0.6) + (bowling_economy_change * 0.4)
                            
                            # Overall form - weighted by player's primary role
                            if selected_player.get("role", "") == "Batsman":
                                overall_form = (batting_form * 0.8) + (bowling_form * 0.2)
                            elif selected_player.get("role", "") == "Bowler":
                                overall_form = (batting_form * 0.2) + (bowling_form * 0.8)
                            else:
                                overall_form = (batting_form * 0.5) + (bowling_form * 0.5)
                            
                            # Convert to percentages and add to data
                            form_data.append({
                                "Season": season,
                                "Batting Form": round(batting_form * 100, 1),
                                "Bowling Form": round(bowling_form * 100, 1),
                                "Overall Form": round(overall_form * 100, 1)
                            })
                    
                    if form_data:
                        # Convert to DataFrame
                        form_df = pd.DataFrame(form_data)
                        
                        # Create line chart for form indices
                        fig = px.line(
                            form_df,
                            x="Season",
                            y=["Batting Form", "Bowling Form", "Overall Form"],
                            title=f"{selected_player.get('name')} - Form Analysis (% Change from Previous Season)",
                            markers=True
                        )
                        
                        # Add a reference line at zero
                        fig.add_hline(y=0, line_dash="dash", line_color="gray")
                        
                        # Update layout
                        fig.update_layout(
                            yaxis=dict(title="Form (% Change)"),
                            legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1)
                        )
                        
                        st.plotly_chart(fig, use_container_width=True)
                        
                        # Add form interpretation
                        last_form = form_data[-1]["Overall Form"]
                        
                        if last_form > 10:
                            form_msg = "Player is in excellent form with significant improvement over the previous season."
                        elif last_form > 0:
                            form_msg = "Player is in good form with some improvement over the previous season."
                        elif last_form > -10:
                            form_msg = "Player's form is relatively stable with minor decline from the previous season."
                        else:
                            form_msg = "Player's form has declined significantly from the previous season."
                        
                        st.info(f"**Form Analysis:** {form_msg}")
                        
                        # Show a table of form data
                        st.dataframe(form_df)
            else:
                st.error("Error retrieving player data.")
        else:
            st.info("No players found with sufficient match history for trend analysis.")
    else:
        st.info("No data loaded. Please use the 'Data Refresh' tab to fetch the latest IPL player stats.")

# Player Valuation Analysis Tab

import streamlit as st
import pandas as pd
import time
import plotly.express as px
import numpy as np
# Removed js_components import per user request
# Import the new scraper module
from trafilatura_scraper import scrape_ipl_teams, scrape_player_stats
from data_processor import process_player_data, get_team_player_mapping
from visualization import (
    create_player_comparison_chart,
    create_team_stats_chart,
    create_player_detail_charts
)
from utils import load_data, save_data
from player_valuation import (
    get_player_valuation_data,
    get_team_valuation_data,
    calculate_player_auction_price_prediction,
    get_value_for_money_players
)
from player_prediction import (
    predict_batting_performance,
    predict_bowling_performance,
    get_match_prediction,
    generate_player_ratings,
    predict_season_performance,
    get_player_matchups
)
# Import match prediction validation functions
from database import save_match_prediction, get_match_predictions, get_prediction_accuracy

# Set page config
st.set_page_config(
    page_title="IPL Cricket Stats Dashboard",
    page_icon="🏏",
    layout="wide"
)

# Initialize session state variables
if 'data_loaded' not in st.session_state:
    st.session_state.data_loaded = False
if 'players_data' not in st.session_state:
    st.session_state.players_data = {}
if 'teams_data' not in st.session_state:
    st.session_state.teams_data = {}
if 'selected_players' not in st.session_state:
    st.session_state.selected_players = []
if 'last_refresh' not in st.session_state:
    st.session_state.last_refresh = None

# Removed audio-visual feedback as per user request

# App title and introduction
st.title("🏏 IPL Cricket Player Statistics")
st.markdown("""
This dashboard provides comprehensive statistics for IPL cricket players. 
Browse by team, compare players, and analyze individual performance metrics.
""")

# Main navigation
tabs = st.tabs(["Teams & Players", "Player Comparison", "Performance Analysis", "Trend Analysis", "Player Valuation", "Performance Prediction", "Prediction Validation", "Data Refresh"])

with tabs[0]:
    st.header("Team & Player Statistics")
    
    # Try to load data first
    if not st.session_state.data_loaded:
        try:
            players_data, teams_data = load_data()
            if players_data and teams_data:
                st.session_state.players_data = players_data
                st.session_state.teams_data = teams_data
                st.session_state.data_loaded = True
                st.session_state.last_refresh = teams_data.get('last_refresh', 'Unknown')
        except Exception as e:
            st.info("No existing data found. Please use the 'Data Refresh' tab to fetch data.")
    
    # Display data if available
    if st.session_state.data_loaded:
        # Team selector
        team_names = list(st.session_state.teams_data.get('teams', {}).keys())
        if team_names:
            selected_team = st.selectbox("Select Team", team_names)
            
            # Show team information
            team_info = st.session_state.teams_data['teams'][selected_team]
            col1, col2 = st.columns([1, 3])
            
            with col1:
                # Get team color and add special styling
                team_abbr = team_info.get('abbreviation', selected_team[0:3])
                team_color = team_info.get('color', '#3366cc')
                st.markdown(f'<h3 style="color:{team_color}; text-shadow: 1px 1px 2px rgba(0,0,0,0.1);">{selected_team} ({team_abbr})</h3>', unsafe_allow_html=True)
                st.write(f"**Home Ground:** {team_info.get('home_ground', 'N/A')}")
                st.write(f"**Owner:** {team_info.get('owner', 'N/A')}")
                st.write(f"**Captain:** {team_info.get('captain', 'N/A')}")
            
            with col2:
                # Show team-level stats
                st.subheader("Team Performance")
                if 'performance' in team_info:
                    perf = team_info['performance']
                    team_stats_df = pd.DataFrame({
                        'Metric': ['Matches Played', 'Wins', 'Losses', 'Titles'],
                        'Value': [
                            perf.get('matches_played', 'N/A'),
                            perf.get('wins', 'N/A'),
                            perf.get('losses', 'N/A'),
                            perf.get('titles', 'N/A')
                        ]
                    })
                    st.dataframe(team_stats_df, hide_index=True)
                    
                    # Create team performance chart
                    fig = create_team_stats_chart(team_info)
                    st.plotly_chart(fig, use_container_width=True)
            
            # Display players in the selected team
            st.subheader(f"{selected_team} Players")
            
            # Get players for the selected team
            team_players = get_team_player_mapping(
                st.session_state.players_data, 
                st.session_state.teams_data
            ).get(selected_team, [])
            
            if team_players:
                # Filter options
                col1, col2 = st.columns(2)
                with col1:
                    role_filter = st.multiselect(
                        "Filter by Role",
                        options=["Batsman", "Bowler", "All-rounder", "Wicket-keeper"],
                        default=["Batsman", "Bowler", "All-rounder", "Wicket-keeper"]
                    )
                with col2:
                    sort_option = st.selectbox(
                        "Sort by",
                        options=["Name", "Runs (High to Low)", "Wickets (High to Low)", "Matches Played", "Batting Average"]
                    )
                
                # Get players data and filter by role
                players_list = []
                for player_id in team_players:
                    if player_id in st.session_state.players_data:
                        player = st.session_state.players_data[player_id]
                        if player.get('role') in role_filter:
                            players_list.append(player)
                
                # Sort players
                if sort_option == "Name":
                    players_list.sort(key=lambda x: x.get('name', ''))
                elif sort_option == "Runs (High to Low)":
                    players_list.sort(key=lambda x: x.get('batting_stats', {}).get('runs', 0), reverse=True)
                elif sort_option == "Wickets (High to Low)":
                    players_list.sort(key=lambda x: x.get('bowling_stats', {}).get('wickets', 0), reverse=True)
                elif sort_option == "Matches Played":
                    players_list.sort(key=lambda x: x.get('matches_played', 0), reverse=True)
                elif sort_option == "Batting Average":
                    players_list.sort(key=lambda x: x.get('batting_stats', {}).get('average', 0), reverse=True)
                
                # Display players in a grid
                cols = st.columns(3)
                for i, player in enumerate(players_list):
                    with cols[i % 3]:
                        # Add card-like styling with team colors
                        player_team = player.get('team', selected_team)
                        team_color = st.session_state.teams_data['teams'].get(player_team, {}).get('color', '#3366cc')
                        
                        # Create a card-like container with border in team color
                        st.markdown(f"""
                        <div style="border-left: 4px solid {team_color}; padding-left: 10px; margin-bottom: 10px;">
                            <h3 style="margin-bottom: 5px;">{player.get('name', 'Unknown')}</h3>
                            <p><strong>Role:</strong> {player.get('role', 'N/A')}</p>
                            <p><strong>Age:</strong> {player.get('age', 'N/A')}</p>
                            <p><strong>Matches:</strong> {player.get('matches_played', 'N/A')}</p>
                        </div>
                        """, unsafe_allow_html=True)
                        
                        batting = player.get('batting_stats', {})
                        bowling = player.get('bowling_stats', {})
                        
                        # Display key batting stats
                        st.markdown("#### Batting")
                        basic_batting_df = pd.DataFrame({
                            'Metric': ['Runs', 'Average', 'Strike Rate', '4s', '6s', '50s', '100s'],
                            'Value': [
                                batting.get('runs', 'N/A'),
                                batting.get('average', 'N/A'),
                                batting.get('strike_rate', 'N/A'),
                                batting.get('fours', 'N/A'),
                                batting.get('sixes', 'N/A'),
                                batting.get('fifties', 'N/A'),
                                batting.get('hundreds', 'N/A')
                            ]
                        })
                        st.dataframe(basic_batting_df, hide_index=True)
                        
                        # Show detailed batting stats if 'View Details' button is clicked
                        if st.button(f"View Detailed Batting Stats", key=f"batting_{player.get('id', i)}"):
                            detailed_batting_df = pd.DataFrame({
                                'Metric': ['Dot Balls', 'Singles', 'Doubles', 'Threes', 'Balls Faced', 'Not Outs'],
                                'Value': [
                                    batting.get('dot_balls', 'N/A'),
                                    batting.get('singles', 'N/A'),
                                    batting.get('doubles', 'N/A'),
                                    batting.get('threes', 'N/A'),
                                    batting.get('balls_faced', 'N/A'),
                                    batting.get('not_outs', 'N/A')
                                ]
                            })
                            st.dataframe(detailed_batting_df, hide_index=True)
                        
                        # Display key bowling stats
                        st.markdown("#### Bowling")
                        basic_bowling_df = pd.DataFrame({
                            'Metric': ['Wickets', 'Economy', 'Average', 'Best', '3+ Wickets'],
                            'Value': [
                                bowling.get('wickets', 'N/A'),
                                bowling.get('economy', 'N/A'),
                                bowling.get('average', 'N/A'),
                                bowling.get('best', 'N/A'),
                                bowling.get('three_plus', 'N/A')
                            ]
                        })
                        st.dataframe(basic_bowling_df, hide_index=True)
                        
                        # Show detailed bowling stats if 'View Details' button is clicked
                        if st.button(f"View Detailed Bowling Stats", key=f"bowling_{player.get('id', i)}"):
                            detailed_bowling_df = pd.DataFrame({
                                'Metric': ['Dot Balls', 'Overs Bowled', 'Runs Conceded', 'Maidens', 'Wides', 'No Balls', 'Hat Tricks', '4W Hauls', '5W Hauls'],
                                'Value': [
                                    bowling.get('dot_balls', 'N/A'),
                                    bowling.get('overs_bowled', 'N/A'),
                                    bowling.get('runs_conceded', 'N/A'),
                                    bowling.get('maidens', 'N/A'),
                                    bowling.get('wides', 'N/A'),
                                    bowling.get('no_balls', 'N/A'),
                                    bowling.get('hat_tricks', 'N/A'),
                                    bowling.get('four_wicket_hauls', 'N/A'),
                                    bowling.get('five_wicket_hauls', 'N/A')
                                ]
                            })
                            st.dataframe(detailed_bowling_df, hide_index=True)
                        
                        # Player detail button
                        if st.button(f"View Detailed Stats", key=f"detail_{player.get('id', i)}"):
                            st.session_state.detailed_player = player
                            st.subheader(f"Detailed Stats for {player.get('name', 'Player')}")
                            st.plotly_chart(create_player_detail_charts(player), use_container_width=True)
            else:
                st.info("No players data available for this team.")
        else:
            st.warning("No team data available. Please refresh the data in the 'Data Refresh' tab.")
    else:
        st.info("No data loaded. Please use the 'Data Refresh' tab to fetch the latest IPL player stats.")

with tabs[1]:
    st.header("Player Comparison")
    
    if st.session_state.data_loaded:
        # Create player selection
        all_players = [(p.get('name', 'Unknown'), p.get('id')) 
                     for p in st.session_state.players_data.values()]
        all_players.sort(key=lambda x: x[0])  # Sort by name
        
        col1, col2 = st.columns(2)
        
        with col1:
            player1 = st.selectbox("Select Player 1", all_players, format_func=lambda x: x[0])
        
        with col2:
            player2 = st.selectbox("Select Player 2", all_players, format_func=lambda x: x[0], index=1 if len(all_players) > 1 else 0)
        
        if player1 and player2:
            player1_data = st.session_state.players_data.get(player1[1])
            player2_data = st.session_state.players_data.get(player2[1])
            
            if player1_data and player2_data:
                # Comparison type
                comparison_type = st.radio(
                    "Comparison Type",
                    ["Batting", "Bowling", "Overall"],
                    horizontal=True
                )
                
                # Create comparison chart
                fig = create_player_comparison_chart(player1_data, player2_data, comparison_type)
                st.plotly_chart(fig, use_container_width=True)
                
                # Display detailed comparison
                col1, col2 = st.columns(2)
                
                with col1:
                    # Style player name with team color
                    player1_team = player1_data.get('team', 'Unknown Team')
                    player1_color = st.session_state.teams_data['teams'].get(player1_team, {}).get('color', '#3366cc')
                    st.markdown(f'<h3 style="color:{player1_color}; text-shadow: 1px 1px 2px rgba(0,0,0,0.1);">{player1_data.get("name", "Player 1")}</h3>', unsafe_allow_html=True)
                    # Display team with team colors
                    st.write(f"**Team:** {player1_team}")
                    
                    # Display role and matches
                    st.write(f"**Role:** {player1_data.get('role', 'N/A')}")
                    st.write(f"**Matches:** {player1_data.get('matches_played', 'N/A')}")
                    
                    if comparison_type in ["Batting", "Overall"]:
                        st.markdown("#### Batting Stats")
                        batting = player1_data.get('batting_stats', {})
                        st.write(f"**Runs:** {batting.get('runs', 'N/A')}")
                        st.write(f"**Average:** {batting.get('average', 'N/A')}")
                        st.write(f"**Strike Rate:** {batting.get('strike_rate', 'N/A')}")
                        st.write(f"**Highest Score:** {batting.get('highest', 'N/A')}")
                        st.write(f"**50s / 100s:** {batting.get('fifties', 'N/A')} / {batting.get('hundreds', 'N/A')}")
                        
                        # Show detailed batting stats in an expander
                        with st.expander("Detailed Batting Stats"):
                            st.write(f"**Dot Balls:** {batting.get('dot_balls', 'N/A')}")
                            st.write(f"**Singles:** {batting.get('singles', 'N/A')}")
                            st.write(f"**Doubles:** {batting.get('doubles', 'N/A')}")
                            st.write(f"**Threes:** {batting.get('threes', 'N/A')}")
                            st.write(f"**Balls Faced:** {batting.get('balls_faced', 'N/A')}")
                            st.write(f"**Not Outs:** {batting.get('not_outs', 'N/A')}")
                    
                    if comparison_type in ["Bowling", "Overall"]:
                        st.markdown("#### Bowling Stats")
                        bowling = player1_data.get('bowling_stats', {})
                        st.write(f"**Wickets:** {bowling.get('wickets', 'N/A')}")
                        st.write(f"**Economy Rate:** {bowling.get('economy', 'N/A')}")
                        st.write(f"**Bowling Average:** {bowling.get('average', 'N/A')}")
                        st.write(f"**Best Bowling:** {bowling.get('best', 'N/A')}")
                        
                        # Show detailed bowling stats in an expander
                        with st.expander("Detailed Bowling Stats"):
                            st.write(f"**Dot Balls:** {bowling.get('dot_balls', 'N/A')}")
                            st.write(f"**Overs Bowled:** {bowling.get('overs_bowled', 'N/A')}")
                            st.write(f"**Runs Conceded:** {bowling.get('runs_conceded', 'N/A')}")
                            st.write(f"**Maidens:** {bowling.get('maidens', 'N/A')}")
                            st.write(f"**Wides:** {bowling.get('wides', 'N/A')}")
                            st.write(f"**No Balls:** {bowling.get('no_balls', 'N/A')}")
                            st.write(f"**Hat Tricks:** {bowling.get('hat_tricks', 'N/A')}")
                            st.write(f"**4+ Wicket Hauls:** {bowling.get('four_wicket_hauls', 'N/A')}")
                            st.write(f"**5+ Wicket Hauls:** {bowling.get('five_wicket_hauls', 'N/A')}")
                
                with col2:
                    # Style player name with team color
                    player2_team = player2_data.get('team', 'Unknown Team')
                    player2_color = st.session_state.teams_data['teams'].get(player2_team, {}).get('color', '#3366cc')
                    st.markdown(f'<h3 style="color:{player2_color}; text-shadow: 1px 1px 2px rgba(0,0,0,0.1);">{player2_data.get("name", "Player 2")}</h3>', unsafe_allow_html=True)
                    # Display team with team colors
                    st.write(f"**Team:** {player2_team}")
                    
                    # Display role and matches
                    st.write(f"**Role:** {player2_data.get('role', 'N/A')}")
                    st.write(f"**Matches:** {player2_data.get('matches_played', 'N/A')}")
                    
                    if comparison_type in ["Batting", "Overall"]:
                        st.markdown("#### Batting Stats")
                        batting = player2_data.get('batting_stats', {})
                        st.write(f"**Runs:** {batting.get('runs', 'N/A')}")
                        st.write(f"**Average:** {batting.get('average', 'N/A')}")
                        st.write(f"**Strike Rate:** {batting.get('strike_rate', 'N/A')}")
                        st.write(f"**Highest Score:** {batting.get('highest', 'N/A')}")
                        st.write(f"**50s / 100s:** {batting.get('fifties', 'N/A')} / {batting.get('hundreds', 'N/A')}")
                        
                        # Show detailed batting stats in an expander
                        with st.expander("Detailed Batting Stats"):
                            st.write(f"**Dot Balls:** {batting.get('dot_balls', 'N/A')}")
                            st.write(f"**Singles:** {batting.get('singles', 'N/A')}")
                            st.write(f"**Doubles:** {batting.get('doubles', 'N/A')}")
                            st.write(f"**Threes:** {batting.get('threes', 'N/A')}")
                            st.write(f"**Balls Faced:** {batting.get('balls_faced', 'N/A')}")
                            st.write(f"**Not Outs:** {batting.get('not_outs', 'N/A')}")
                    
                    if comparison_type in ["Bowling", "Overall"]:
                        st.markdown("#### Bowling Stats")
                        bowling = player2_data.get('bowling_stats', {})
                        st.write(f"**Wickets:** {bowling.get('wickets', 'N/A')}")
                        st.write(f"**Economy Rate:** {bowling.get('economy', 'N/A')}")
                        st.write(f"**Bowling Average:** {bowling.get('average', 'N/A')}")
                        st.write(f"**Best Bowling:** {bowling.get('best', 'N/A')}")
                        
                        # Show detailed bowling stats in an expander
                        with st.expander("Detailed Bowling Stats"):
                            st.write(f"**Dot Balls:** {bowling.get('dot_balls', 'N/A')}")
                            st.write(f"**Overs Bowled:** {bowling.get('overs_bowled', 'N/A')}")
                            st.write(f"**Runs Conceded:** {bowling.get('runs_conceded', 'N/A')}")
                            st.write(f"**Maidens:** {bowling.get('maidens', 'N/A')}")
                            st.write(f"**Wides:** {bowling.get('wides', 'N/A')}")
                            st.write(f"**No Balls:** {bowling.get('no_balls', 'N/A')}")
                            st.write(f"**Hat Tricks:** {bowling.get('hat_tricks', 'N/A')}")
                            st.write(f"**4+ Wicket Hauls:** {bowling.get('four_wicket_hauls', 'N/A')}")
                            st.write(f"**5+ Wicket Hauls:** {bowling.get('five_wicket_hauls', 'N/A')}")
            else:
                st.error("Error retrieving player data. Please try refreshing the data.")
    else:
        st.info("No data loaded. Please use the 'Data Refresh' tab to fetch the latest IPL player stats.")

with tabs[2]:
    st.header("Performance Analysis")
    
    if st.session_state.data_loaded:
        st.subheader("Player Performance Metrics")
        
        # Filter options
        col1, col2 = st.columns(2)
        with col1:
            metric_type = st.selectbox(
                "Select Performance Metric",
                ["Batting Performance", "Bowling Performance", "Overall Contribution"]
            )
        
        with col2:
            min_matches = st.slider("Minimum Matches Played", 0, 100, 10)
        
        # Get all players who meet the minimum matches criteria
        qualified_players = {
            player_id: player_data for player_id, player_data in st.session_state.players_data.items()
            if player_data.get("matches_played", 0) >= min_matches
        }
        
        if qualified_players:
            if metric_type == "Batting Performance":
                # Create a dataframe for batting metrics
                batting_data = []
                for player_id, player in qualified_players.items():
                    batting = player.get("batting_stats", {})
                    if batting.get("runs", 0) > 0:  # Only include players with some batting stats
                        batting_data.append({
                            "Player": player.get("name", "Unknown"),
                            "Team": player.get("team", "Unknown"),
                            "Role": player.get("role", "Unknown"),
                            "Runs": batting.get("runs", 0),
                            "Average": batting.get("average", 0),
                            "Strike Rate": batting.get("strike_rate", 0),
                            "50s": batting.get("fifties", 0),
                            "100s": batting.get("hundreds", 0),
                            "Boundaries (4s)": batting.get("fours", 0),
                            "Boundaries (6s)": batting.get("sixes", 0),
                            "Dot Ball %": min(round((batting.get("dot_balls", 0) / max(batting.get("balls_faced", 1), 1)) * 100, 1), 100.0)
                        })
                
                if batting_data:
                    # Convert to dataframe
                    batting_df = pd.DataFrame(batting_data)
                    
                    # Calculate efficiency metrics
                    import numpy as np
                    
                    # Calculate boundary % - percentage of runs scored through boundaries
                    # Ensure it never exceeds 100% by using minimum function
                    boundary_runs = (batting_df["Boundaries (4s)"] * 4 + batting_df["Boundaries (6s)"] * 6)
                    total_runs = batting_df["Runs"].apply(lambda x: max(x, 1))
                    batting_df["Boundary %"] = np.minimum(
                        round((boundary_runs / total_runs) * 100, 1),
                        100.0  # Cap at 100%
                    )
                    
                    # Add performance score (a weighted score balancing average, SR and boundary hitting)
                    batting_df["Performance Score"] = round((batting_df["Average"] * 0.4) + 
                                                         (batting_df["Strike Rate"] * 0.4 / 100) + 
                                                         (batting_df["Boundary %"] * 0.2), 1)
                    
                    # Let user select how to sort
                    sort_by = st.selectbox(
                        "Sort By", 
                        ["Performance Score", "Runs", "Average", "Strike Rate", "Boundary %", "Dot Ball %"],
                        index=0
                    )
                    
                    # Display the sorted data
                    st.dataframe(
                        batting_df.sort_values(by=sort_by, ascending=False)
                        .reset_index(drop=True)
                    )
                    
                    # Visualization of top performers
                    st.subheader("Top Batting Performers")
                    
                    # Let user select metric to visualize
                    viz_metric = st.selectbox(
                        "Visualize By", 
                        ["Performance Score", "Runs", "Average", "Strike Rate", "Boundary %"],
                        index=0
                    )
                    
                    # Get top 10 players by the selected metric
                    top_players = batting_df.sort_values(by=viz_metric, ascending=False).head(10)
                    
                    # Create bar chart
                    fig = px.bar(
                        top_players, 
                        x="Player", 
                        y=viz_metric, 
                        color="Team",
                        title=f"Top 10 Players by {viz_metric}",
                        hover_data=["Role", "Runs", "Average", "Strike Rate"],
                        color_discrete_sequence=px.colors.qualitative.Bold
                    )
                    fig.update_layout(xaxis_tickangle=-45)
                    st.plotly_chart(fig, use_container_width=True)
                    
                else:
                    st.info("No batting data available for players with the selected criteria.")
            
            elif metric_type == "Bowling Performance":
                # Create a dataframe for bowling metrics
                bowling_data = []
                for player_id, player in qualified_players.items():
                    bowling = player.get("bowling_stats", {})
                    if bowling.get("wickets", 0) > 0:  # Only include players with some bowling stats
                        bowling_data.append({
                            "Player": player.get("name", "Unknown"),
                            "Team": player.get("team", "Unknown"),
                            "Role": player.get("role", "Unknown"),
                            "Wickets": bowling.get("wickets", 0),
                            "Economy": bowling.get("economy", 0),
                            "Average": bowling.get("average", 0),
                            "Overs": bowling.get("overs_bowled", 0),
                            "Dot Ball %": min(round((bowling.get("dot_balls", 0) / max(bowling.get("balls_bowled", 1), 1)) * 100, 1), 100.0),
                            "3+ Wicket Hauls": bowling.get("three_plus", 0),
                            "Maiden %": min(round((bowling.get("maidens", 0) / max(bowling.get("overs_bowled", 1), 1)) * 100, 1), 100.0)
                        })
                
                if bowling_data:
                    # Convert to dataframe
                    bowling_df = pd.DataFrame(bowling_data)
                    
                    # Calculate efficiency metrics
                    bowling_df["Wickets Per Over"] = round(bowling_df["Wickets"] / bowling_df["Overs"].apply(lambda x: max(x, 1)), 2)
                    
                    # Add performance score (a weighted score balancing economy, average and wicket-taking)
                    # Note: for economy and average, lower is better so we invert these values
                    bowling_df["Performance Score"] = round((10 / bowling_df["Economy"].apply(lambda x: max(x, 1)) * 0.4) + 
                                                          (30 / bowling_df["Average"].apply(lambda x: max(x, 1)) * 0.3) + 
                                                          (bowling_df["Wickets Per Over"] * 5 * 0.3), 1)
                    
                    # Let user select how to sort
                    sort_by = st.selectbox(
                        "Sort By", 
                        ["Performance Score", "Wickets", "Economy", "Average", "Dot Ball %", "Maiden %"],
                        index=0
                    )
                    
                    # Display the sorted data
                    st.dataframe(
                        bowling_df.sort_values(by=sort_by, ascending=False if sort_by != "Economy" and sort_by != "Average" else True)
                        .reset_index(drop=True)
                    )
                    
                    # Visualization of top performers
                    st.subheader("Top Bowling Performers")
                    
                    # Let user select metric to visualize
                    viz_metric = st.selectbox(
                        "Visualize By", 
                        ["Performance Score", "Wickets", "Economy", "Average", "Dot Ball %"],
                        index=0
                    )
                    
                    # Get top 10 players by the selected metric
                    if viz_metric in ["Economy", "Average"]:
                        # For these metrics, lower is better
                        top_players = bowling_df.sort_values(by=viz_metric, ascending=True).head(10)
                    else:
                        top_players = bowling_df.sort_values(by=viz_metric, ascending=False).head(10)
                    
                    # Create bar chart
                    fig = px.bar(
                        top_players, 
                        x="Player", 
                        y=viz_metric, 
                        color="Team",
                        title=f"Top 10 Players by {viz_metric}",
                        hover_data=["Role", "Wickets", "Economy", "Average"],
                        color_discrete_sequence=px.colors.qualitative.Bold
                    )
                    fig.update_layout(xaxis_tickangle=-45)
                    st.plotly_chart(fig, use_container_width=True)
                    
                else:
                    st.info("No bowling data available for players with the selected criteria.")
            
            else:  # Overall Contribution
                # Create a dataframe for overall metrics
                overall_data = []
                
                for player_id, player in qualified_players.items():
                    batting = player.get("batting_stats", {})
                    bowling = player.get("bowling_stats", {})
                    
                    # Only include players with some stats
                    if batting.get("runs", 0) > 0 or bowling.get("wickets", 0) > 0:
                        # Calculate batting points (weighted runs)
                        batting_points = (batting.get("runs", 0) * 
                                         (batting.get("strike_rate", 100) / 100))
                        
                        # Calculate bowling points (weighted wickets)
                        bowling_points = (bowling.get("wickets", 0) * 25 * 
                                         (10 / max(bowling.get("economy", 10), 1)))
                        
                        # Total performance points
                        total_points = batting_points + bowling_points
                        
                        overall_data.append({
                            "Player": player.get("name", "Unknown"),
                            "Team": player.get("team", "Unknown"),
                            "Role": player.get("role", "Unknown"),
                            "Batting Points": round(batting_points, 1),
                            "Bowling Points": round(bowling_points, 1), 
                            "Total Points": round(total_points, 1),
                            "Batting Contribution %": round((batting_points / max(total_points, 1)) * 100, 1),
                            "Bowling Contribution %": round((bowling_points / max(total_points, 1)) * 100, 1),
                            "Matches": player.get("matches_played", 0),
                            "Points Per Match": round(total_points / max(player.get("matches_played", 1), 1), 1)
                        })
                
                if overall_data:
                    # Convert to dataframe
                    overall_df = pd.DataFrame(overall_data)
                    
                    # Let user select how to sort
                    sort_by = st.selectbox(
                        "Sort By", 
                        ["Total Points", "Points Per Match", "Batting Points", "Bowling Points", 
                         "Batting Contribution %", "Bowling Contribution %"],
                        index=0
                    )
                    
                    # Display the sorted data
                    st.dataframe(
                        overall_df.sort_values(by=sort_by, ascending=False)
                        .reset_index(drop=True)
                    )
                    
                    # Visualization of top all-rounders
                    st.subheader("Top All-Round Performers")
                    
                    # Filter to players with both batting and bowling contributions
                    all_rounders = overall_df[
                        (overall_df["Batting Points"] > 100) & 
                        (overall_df["Bowling Points"] > 100)
                    ].sort_values(by="Total Points", ascending=False).head(10)
                    
                    if not all_rounders.empty:
                        # Create scatter plot
                        fig = px.scatter(
                            all_rounders,
                            x="Batting Points",
                            y="Bowling Points",
                            size="Total Points",
                            color="Team",
                            hover_name="Player",
                            text="Player",
                            title="Batting vs Bowling Contribution (Top All-Rounders)",
                            size_max=50,
                            color_discrete_sequence=px.colors.qualitative.Bold
                        )
                        fig.update_traces(textposition='top center')
                        fig.update_layout(height=600)
                        st.plotly_chart(fig, use_container_width=True)
                    else:
                        st.info("No players with significant contributions in both batting and bowling.")
                
                else:
                    st.info("No overall performance data available for players with the selected criteria.")
        else:
            st.info(f"No players found with at least {min_matches} matches played.")
    else:
        st.info("No data loaded. Please use the 'Data Refresh' tab to fetch the latest IPL player stats.")

with tabs[3]:
    st.header("Trend Analysis")
    
    # Import the trend analysis module
    from trend_analysis import (
        analyze_team_trends, analyze_player_career_progression, 
        compare_seasons, identify_performance_patterns,
        generate_mock_seasonal_data, generate_mock_player_seasonal_data
    )
    
    # Import database functions for seasonal stats
    from database import get_team_seasonal_stats, get_player_seasonal_stats, get_all_seasons
    
    if st.session_state.data_loaded:
        # Create tabs for different trend analysis views
        trend_analysis_tabs = st.tabs([
            "Player Career Progression", 
            "Team Performance Trends", 
            "Season Comparison", 
            "Performance Patterns"
        ])
        
        # Tab 1: Player Career Progression Analysis
        with trend_analysis_tabs[0]:
            st.subheader("Player Career Progression")
            
            # Explanation about the player trend data
            st.info("""
            Analyze how a player's performance has evolved across IPL seasons.
            Track their batting and bowling statistics, career milestones, and team changes over time.
            """)
            
            # Player selection
            players_list = [(p.get("name", "Unknown"), p.get("id")) 
                            for p in st.session_state.players_data.values() 
                            if p.get("matches_played", 0) >= 10]  # Players with sufficient matches
            
            players_list.sort(key=lambda x: x[0])  # Sort by name
            
            if players_list:
                # Player selection
                selected_player_id = st.selectbox(
                    "Select Player",
                    options=[p[1] for p in players_list],
                    format_func=lambda x: next((p[0] for p in players_list if p[1] == x), x),
                    key="career_player_select"
                )
                
                selected_player = st.session_state.players_data.get(selected_player_id)
                
                if selected_player:
                    # For demonstration, we'll generate mock seasonal data
                    # In a production app, this would come from the database
                    player_name = selected_player.get('name', 'Unknown')
                    player_role = selected_player.get('role', 'Unknown')
                    team_name = selected_player.get('team', 'Unknown')
                    
                    # Check for actual seasonal data in the database
                    db_player_stats = get_player_seasonal_stats(player_id=selected_player_id)
                    
                    # If no data in database, generate mock data for demo
                    if not db_player_stats:
                        st.warning("""
                        Historical seasonal data is not available in the database. 
                        Using simulated data for demonstration purposes.
                        """)
                        
                        # Generate mock data based on existing player stats
                        matches_played = selected_player.get("matches_played", 0)
                        num_seasons = min(8, max(3, matches_played // 7))  # Rough estimation of seasons played
                        start_year = 2023 - num_seasons
                        
                        # Get player teams for mock data
                        teams = [team_name]
                        # Add a team change if it's a veteran player
                        if matches_played > 50 and selected_player_id.endswith('7'):
                            teams = ["Mumbai Indians", team_name] if team_name != "Mumbai Indians" else ["Chennai Super Kings", team_name]
                        
                        player_seasonal_stats = generate_mock_player_seasonal_data(
                            player_name=player_name,
                            player_id=selected_player_id,
                            role=player_role,
                            teams=teams,
                            start_year=start_year,
                            end_year=2023
                        )
                    else:
                        player_seasonal_stats = db_player_stats
                    
                    # Analyze player career progression
                    career_analysis = analyze_player_career_progression(player_seasonal_stats)
                    
                    if career_analysis["status"] == "success":
                        st.subheader(f"{player_name}'s Career Progression ({career_analysis['role']})")
                        
                        # Show seasons analyzed
                        seasons_text = ", ".join(str(season) for season in career_analysis["seasons_analyzed"])
                        st.markdown(f"**Seasons analyzed**: {seasons_text}")
                        
                        # Create tabs for different aspects of career analysis
                        career_tabs = st.tabs(["Batting Stats", "Bowling Stats", "Milestones & Changes"])
                        
                        # Batting stats tab
                        with career_tabs[0]:
                            if career_analysis["batting_progression"]:
                                # Convert data to DataFrames for plotting
                                import pandas as pd
                                import plotly.express as px
                                
                                # Create a DataFrame from batting progression
                                runs_data = []
                                for i, season in enumerate(career_analysis["seasons_analyzed"]):
                                    runs_data.append({
                                        "Season": season,
                                        "Runs": career_analysis["batting_progression"]["runs"][i] if i < len(career_analysis["batting_progression"]["runs"]) else 0,
                                        "Average": career_analysis["batting_progression"]["average"][i] if i < len(career_analysis["batting_progression"]["average"]) else 0,
                                        "Strike Rate": career_analysis["batting_progression"]["strike_rate"][i] if i < len(career_analysis["batting_progression"]["strike_rate"]) else 0
                                    })
                                
                                batting_df = pd.DataFrame(runs_data)
                                
                                # Runs by season
                                st.subheader("Runs by Season")
                                runs_fig = px.bar(
                                    batting_df,
                                    x="Season",
                                    y="Runs",
                                    title=f"{player_name}'s Run Scoring by Season",
                                    text="Runs",
                                    color="Average",
                                    color_continuous_scale="RdYlGn",
                                    height=400
                                )
                                
                                # Add strike rate line
                                runs_fig.add_scatter(
                                    x=batting_df["Season"],
                                    y=batting_df["Strike Rate"],
                                    mode="lines+markers",
                                    name="Strike Rate",
                                    line=dict(color="red", width=2),
                                    yaxis="y2"
                                )
                                
                                runs_fig.update_layout(
                                    yaxis2=dict(
                                        title="Strike Rate",
                                        overlaying="y",
                                        side="right",
                                        range=[0, max(batting_df["Strike Rate"]) * 1.2 if len(batting_df) > 0 and max(batting_df["Strike Rate"]) > 0 else 200]
                                    )
                                )
                                
                                st.plotly_chart(runs_fig, use_container_width=True)
                                
                                # Boundary hitting
                                if "fours" in career_analysis["batting_progression"] and "sixes" in career_analysis["batting_progression"]:
                                    st.subheader("Boundary Hitting")
                                    
                                    # Prepare boundary data
                                    boundary_data = []
                                    for i, season in enumerate(career_analysis["seasons_analyzed"]):
                                        if i < len(career_analysis["batting_progression"]["fours"]):
                                            boundary_data.append({
                                                "Season": season,
                                                "Type": "Fours",
                                                "Count": career_analysis["batting_progression"]["fours"][i]
                                            })
                                        if i < len(career_analysis["batting_progression"]["sixes"]):
                                            boundary_data.append({
                                                "Season": season,
                                                "Type": "Sixes",
                                                "Count": career_analysis["batting_progression"]["sixes"][i]
                                            })
                                    
                                    boundary_df = pd.DataFrame(boundary_data)
                                    
                                    if not boundary_df.empty:
                                        boundary_fig = px.bar(
                                            boundary_df,
                                            x="Season",
                                            y="Count",
                                            color="Type",
                                            barmode="group",
                                            title=f"{player_name}'s Boundary Hitting",
                                            color_discrete_map={"Fours": "#3366cc", "Sixes": "#dc3912"}
                                        )
                                        
                                        st.plotly_chart(boundary_fig, use_container_width=True)
                                
                                # Batting average progression
                                st.subheader("Batting Average Progression")
                                avg_fig = px.line(
                                    batting_df,
                                    x="Season",
                                    y="Average",
                                    title=f"{player_name}'s Batting Average Progression",
                                    markers=True,
                                    height=400
                                )
                                
                                # Add a trend line (without using ols)
                                if len(batting_df) > 1:
                                    # Calculate a simple moving average instead of using ols
                                    batting_df['MA'] = batting_df['Average'].rolling(window=min(2, len(batting_df)), min_periods=1).mean()
                                    avg_fig.add_scatter(
                                        x=batting_df["Season"],
                                        y=batting_df["MA"],
                                        mode='lines',
                                        name='Trend',
                                        line=dict(color='red', width=2, dash='dash')
                                    )
                                
                                st.plotly_chart(avg_fig, use_container_width=True)
                            else:
                                st.info(f"{player_name} does not have significant batting statistics.")
                        
                        # Bowling stats tab
                        with career_tabs[1]:
                            if career_analysis["bowling_progression"]:
                                # Convert data to DataFrames for plotting
                                import pandas as pd
                                import plotly.express as px
                                
                                # Create a DataFrame from bowling progression
                                wickets_data = []
                                for i, season in enumerate(career_analysis["seasons_analyzed"]):
                                    if i < len(career_analysis["bowling_progression"]["wickets"]):
                                        wickets_data.append({
                                            "Season": season,
                                            "Wickets": career_analysis["bowling_progression"]["wickets"][i],
                                            "Economy": career_analysis["bowling_progression"]["economy"][i] if "economy" in career_analysis["bowling_progression"] else 0,
                                            "Average": career_analysis["bowling_progression"]["average"][i] if "average" in career_analysis["bowling_progression"] else 0
                                        })
                                
                                bowling_df = pd.DataFrame(wickets_data)
                                
                                if not bowling_df.empty:
                                    # Wickets by season
                                    st.subheader("Wickets by Season")
                                    wickets_fig = px.bar(
                                        bowling_df,
                                        x="Season",
                                        y="Wickets",
                                        title=f"{player_name}'s Wicket Taking by Season",
                                        text="Wickets",
                                        color="Economy",
                                        color_continuous_scale="RdYlGn_r", # Reversed so green is low economy
                                        height=400
                                    )
                                    
                                    # Add economy line
                                    wickets_fig.add_scatter(
                                        x=bowling_df["Season"],
                                        y=bowling_df["Economy"],
                                        mode="lines+markers",
                                        name="Economy",
                                        line=dict(color="red", width=2),
                                        yaxis="y2"
                                    )
                                    
                                    wickets_fig.update_layout(
                                        yaxis2=dict(
                                            title="Economy Rate",
                                            overlaying="y",
                                            side="right",
                                            range=[0, max(bowling_df["Economy"]) * 1.2 if max(bowling_df["Economy"]) > 0 else 12]
                                        )
                                    )
                                    
                                    st.plotly_chart(wickets_fig, use_container_width=True)
                                    
                                    # Bowling average progression
                                    if "average" in career_analysis["bowling_progression"]:
                                        st.subheader("Bowling Average Progression")
                                        avg_fig = px.line(
                                            bowling_df,
                                            x="Season",
                                            y="Average",
                                            title=f"{player_name}'s Bowling Average Progression",
                                            markers=True,
                                            height=400
                                        )
                                        
                                        # Add a trend line (without using ols)
                                        if len(bowling_df) > 1:
                                            # Calculate a simple moving average instead of using ols
                                            bowling_df['MA'] = bowling_df['Average'].rolling(window=min(2, len(bowling_df)), min_periods=1).mean()
                                            avg_fig.add_scatter(
                                                x=bowling_df["Season"],
                                                y=bowling_df["MA"],
                                                mode='lines',
                                                name='Trend',
                                                line=dict(color='red', width=2, dash='dash')
                                            )
                                        
                                        st.plotly_chart(avg_fig, use_container_width=True)
                            else:
                                st.info(f"{player_name} does not have significant bowling statistics.")
                        
                        # Milestones tab
                        with career_tabs[2]:
                            # Display milestones
                            if career_analysis["performance_milestones"]:
                                st.subheader("Career Milestones")
                                
                                milestones_df = pd.DataFrame(career_analysis["performance_milestones"])
                                
                                if not milestones_df.empty:
                                    # Sort by season
                                    milestones_df = milestones_df.sort_values("season")
                                    
                                    # Create a formatted display
                                    for _, milestone in milestones_df.iterrows():
                                        milestone_color = "🔴" if milestone["type"] == "batting" else "🔵" if milestone["type"] == "bowling" else "🏆"
                                        st.markdown(f"**{milestone['season']}**: {milestone_color} {milestone['description']}")
                            else:
                                st.info("No significant milestones found in the analyzed seasons.")
                            
                            # Display team changes
                            if career_analysis["team_changes"]:
                                st.subheader("Team Changes")
                                
                                for change in career_analysis["team_changes"]:
                                    st.markdown(f"**{change['season']}**: Moved from {change['from_team']} to {change['to_team']}")
                            else:
                                st.info(f"{player_name} has remained with {team_name} throughout the analyzed seasons.")
                    else:
                        st.error(career_analysis["message"])
                else:
                    st.error("Error retrieving player data.")
            else:
                st.info("No players with sufficient matches found for trend analysis.")
        
        # Tab 2: Team Performance Trends
        with trend_analysis_tabs[1]:
            st.subheader("Team Performance Trends")
            
            st.info("""
            Analyze how teams have performed across different IPL seasons.
            Track win rates, points, batting and bowling metrics, and identify correlations between performance indicators.
            """)
            
            # Team selection
            teams_list = list(st.session_state.teams_data.get('teams', {}).keys())
            teams_list.sort()
            
            if teams_list:
                # Add option for all teams
                team_options = ["All Teams"] + teams_list
                
                selected_team = st.selectbox(
                    "Select Team",
                    options=team_options,
                    key="trend_team_select"
                )
                
                # Filter team if specified
                team_filter = None if selected_team == "All Teams" else selected_team
                
                # Fetch team seasonal stats from database
                db_team_stats = get_team_seasonal_stats(team_name=team_filter)
                
                # If no data in database, generate mock data for demo
                if not db_team_stats:
                    st.warning("""
                    Historical seasonal data is not available in the database. 
                    Using simulated data for demonstration purposes.
                    """)
                    
                    # Generate mock seasonal data for demonstration
                    db_team_stats = generate_mock_seasonal_data(
                        teams=teams_list,
                        start_year=2016,
                        end_year=2023
                    )
                    
                    # Filter if team was selected
                    if team_filter:
                        db_team_stats = [s for s in db_team_stats if s.get('team_name') == team_filter]
                
                # Analyze team trends
                trend_analysis = analyze_team_trends(db_team_stats, team_name=team_filter)
                
                if trend_analysis["status"] == "success":
                    st.subheader(f"{trend_analysis['team_name']} Performance Analysis")
                    
                    # Show seasons analyzed
                    seasons_text = ", ".join(str(season) for season in trend_analysis["seasons_analyzed"])
                    st.markdown(f"**Seasons analyzed**: {seasons_text}")
                    
                    # Create tabs for different aspects of trend analysis
                    team_trend_tabs = st.tabs([
                        "Performance Metrics", 
                        "Statistical Analysis", 
                        "Correlation Analysis"
                    ])
                    
                    # Performance Metrics Tab
                    with team_trend_tabs[0]:
                        if trend_analysis["performance_trends"]:
                            import pandas as pd
                            import plotly.express as px
                            import plotly.graph_objects as go
                            
                            # Create dataframe for performance trends
                            perf_data = []
                            for i, season in enumerate(trend_analysis["seasons_analyzed"]):
                                perf_data.append({
                                    "Season": season,
                                    "Win Rate (%)": trend_analysis["performance_trends"]["win_rate"][i] if i < len(trend_analysis["performance_trends"]["win_rate"]) else 0,
                                    "Win-Loss Ratio": trend_analysis["performance_trends"]["win_loss_ratio"][i] if i < len(trend_analysis["performance_trends"]["win_loss_ratio"]) else 0,
                                    "Points": trend_analysis["performance_trends"]["points"][i] if i < len(trend_analysis["performance_trends"]["points"]) else 0,
                                    "Batting Avg": trend_analysis["performance_trends"]["batting_avg"][i] if i < len(trend_analysis["performance_trends"]["batting_avg"]) else 0,
                                    "Batting SR": trend_analysis["performance_trends"]["batting_strike_rate"][i] if i < len(trend_analysis["performance_trends"]["batting_strike_rate"]) else 0,
                                    "Bowling Avg": trend_analysis["performance_trends"]["bowling_avg"][i] if i < len(trend_analysis["performance_trends"]["bowling_avg"]) else 0,
                                    "Bowling Economy": trend_analysis["performance_trends"]["bowling_economy"][i] if i < len(trend_analysis["performance_trends"]["bowling_economy"]) else 0,
                                    "Net Run Rate": trend_analysis["performance_trends"]["net_run_rate"][i] if i < len(trend_analysis["performance_trends"]["net_run_rate"]) else 0
                                })
                            
                            perf_df = pd.DataFrame(perf_data)
                            
                            # Win Rate Chart
                            st.subheader("Win Rate Trend")
                            win_fig = px.line(
                                perf_df,
                                x="Season",
                                y="Win Rate (%)",
                                title=f"{trend_analysis['team_name']} Win Rate Across Seasons",
                                markers=True,
                                height=400
                            )
                            
                            # Add points as bar
                            win_fig.add_bar(
                                x=perf_df["Season"],
                                y=perf_df["Points"],
                                name="Points",
                                yaxis="y2"
                            )
                            
                            win_fig.update_layout(
                                yaxis=dict(title="Win Rate (%)"),
                                yaxis2=dict(
                                    title="Points",
                                    overlaying="y",
                                    side="right",
                                    range=[0, max(perf_df["Points"]) * 1.2 if not perf_df.empty and max(perf_df["Points"]) > 0 else 30]
                                ),
                                legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1)
                            )
                            
                            st.plotly_chart(win_fig, use_container_width=True)
                            
                            # Batting Performance Chart
                            st.subheader("Batting Performance Trend")
                            bat_fig = px.line(
                                perf_df,
                                x="Season",
                                y=["Batting Avg", "Batting SR"],
                                title=f"{trend_analysis['team_name']} Batting Performance",
                                markers=True,
                                height=400
                            )
                            
                            st.plotly_chart(bat_fig, use_container_width=True)
                            
                            # Bowling Performance Chart
                            st.subheader("Bowling Performance Trend")
                            bowl_fig = px.line(
                                perf_df,
                                x="Season",
                                y=["Bowling Avg", "Bowling Economy"],
                                title=f"{trend_analysis['team_name']} Bowling Performance",
                                markers=True,
                                height=400
                            )
                            
                            st.plotly_chart(bowl_fig, use_container_width=True)
                            
                            # Net Run Rate Chart
                            st.subheader("Net Run Rate Trend")
                            nrr_fig = px.line(
                                perf_df,
                                x="Season",
                                y="Net Run Rate",
                                title=f"{trend_analysis['team_name']} Net Run Rate",
                                markers=True,
                                height=400
                            )
                            
                            # Add a zero line for reference
                            nrr_fig.add_hline(
                                y=0,
                                line_dash="dash",
                                line_color="gray",
                                annotation_text="Zero Line",
                                annotation_position="bottom right"
                            )
                            
                            st.plotly_chart(nrr_fig, use_container_width=True)
                        else:
                            st.error("No performance trends data available.")
                    
                    # Statistical Analysis Tab
                    with team_trend_tabs[1]:
                        if trend_analysis["statistical_analysis"]:
                            import pandas as pd
                            
                            # Create table of statistical measures
                            stat_data = []
                            for metric, stats in trend_analysis["statistical_analysis"].items():
                                stat_data.append({
                                    "Metric": metric.replace('_', ' ').title(),
                                    "Mean": round(stats["mean"], 2),
                                    "Median": round(stats["median"], 2),
                                    "Std Dev": round(stats["std_dev"], 2),
                                    "Min": round(stats["min"], 2),
                                    "Max": round(stats["max"], 2),
                                    "Trend": stats["trend_direction"]
                                })
                            
                            stat_df = pd.DataFrame(stat_data)
                            
                            st.subheader("Statistical Summary")
                            st.dataframe(stat_df, hide_index=True, use_container_width=True)
                            
                            # Create visual representation of trends
                            st.subheader("Key Metrics Distribution")
                            
                            import plotly.graph_objects as go
                            
                            # Create box plots for key metrics
                            metrics_to_plot = ["Wins", "Points", "Batting Avg", "Bowling Avg", "Net Run Rate"]
                            
                            # Extract data for box plots
                            box_data = []
                            for metric in metrics_to_plot:
                                metric_lower = metric.lower().replace(' ', '_')
                                if metric_lower in trend_analysis["performance_trends"]:
                                    for value in trend_analysis["performance_trends"][metric_lower]:
                                        box_data.append({
                                            "Metric": metric,
                                            "Value": value
                                        })
                            
                            box_df = pd.DataFrame(box_data)
                            
                            if not box_df.empty:
                                box_fig = px.box(
                                    box_df,
                                    x="Metric",
                                    y="Value",
                                    title=f"{trend_analysis['team_name']} Metrics Distribution",
                                    color="Metric",
                                    height=500
                                )
                                
                                st.plotly_chart(box_fig, use_container_width=True)
                        else:
                            st.error("No statistical analysis data available.")
                    
                    # Correlation Analysis Tab
                    with team_trend_tabs[2]:
                        if trend_analysis["correlation_analysis"]:
                            correlations = trend_analysis["correlation_analysis"].get("correlations", [])
                            
                            if correlations:
                                import pandas as pd
                                
                                # Create table of correlations
                                corr_data = []
                                for corr in correlations:
                                    corr_data.append({
                                        "Metric 1": corr["metric1"].replace('_', ' ').title(),
                                        "Metric 2": corr["metric2"].replace('_', ' ').title(),
                                        "Correlation": round(corr["correlation"], 2),
                                        "Strength": corr["strength"].title()
                                    })
                                
                                corr_df = pd.DataFrame(corr_data)
                                
                                st.subheader("Correlations Between Metrics")
                                st.dataframe(corr_df, hide_index=True, use_container_width=True)
                                
                                # Display key insights
                                insights = trend_analysis["correlation_analysis"].get("insights", [])
                                if insights:
                                    st.subheader("Key Insights")
                                    for insight in insights:
                                        st.markdown(f"- {insight}")
                                
                                # Create correlation matrix visualization
                                st.subheader("Correlation Matrix")
                                
                                # Create a correlation matrix
                                metrics = list(set([row["Metric 1"] for row in corr_data] + [row["Metric 2"] for row in corr_data]))
                                
                                # Initialize matrix with zeros
                                corr_matrix = pd.DataFrame(0, index=metrics, columns=metrics)
                                
                                # Fill in correlations
                                for _, row in corr_df.iterrows():
                                    corr_matrix.loc[row["Metric 1"], row["Metric 2"]] = row["Correlation"]
                                    corr_matrix.loc[row["Metric 2"], row["Metric 1"]] = row["Correlation"]
                                
                                # Set diagonal to 1
                                for metric in metrics:
                                    corr_matrix.loc[metric, metric] = 1.0
                                
                                import plotly.graph_objects as go
                                
                                fig = go.Figure(data=go.Heatmap(
                                    z=corr_matrix.values,
                                    x=corr_matrix.columns,
                                    y=corr_matrix.index,
                                    colorscale='RdBu_r',
                                    zmin=-1,
                                    zmax=1,
                                    text=corr_matrix.round(2).values,
                                    texttemplate="%{text}",
                                    textfont={"size":10}
                                ))
                                
                                fig.update_layout(
                                    title=f"Correlation Matrix for {trend_analysis['team_name']}",
                                    height=600,
                                    xaxis=dict(tickangle=-45)
                                )
                                
                                st.plotly_chart(fig, use_container_width=True)
                            else:
                                st.info("No significant correlations found in the data.")
                        else:
                            st.error("No correlation analysis data available.")
                else:
                    st.error(trend_analysis["message"])
            else:
                st.info("No team data available for trend analysis.")
        
        # Tab 3: Season Comparison
        with trend_analysis_tabs[2]:
            st.subheader("Season Comparison")
            
            st.info("""
            Compare performance metrics between two IPL seasons.
            Analyze team performance changes, overall tournament statistics, and identify performance improvements or declines.
            """)
            
            # Get seasons from database or generate demo seasons
            db_seasons = get_all_seasons()
            
            if not db_seasons:
                # Generate demo seasons
                db_seasons = list(range(2016, 2024))
                
                st.warning("""
                Historical seasonal data is not available in the database. 
                Using simulated data for demonstration purposes.
                """)
            
            # Sort in descending order for easier selection
            seasons = sorted(db_seasons, reverse=True)
            
            if len(seasons) >= 2:
                # Season selection
                col1, col2 = st.columns(2)
                
                with col1:
                    season1 = st.selectbox(
                        "Select First Season",
                        options=seasons,
                        index=min(1, len(seasons)-1),
                        key="compare_season1"
                    )
                
                with col2:
                    # Filter out first season to prevent same selection
                    season2_options = [s for s in seasons if s != season1]
                    season2 = st.selectbox(
                        "Select Second Season",
                        options=season2_options,
                        index=0,
                        key="compare_season2"
                    )
                
                # Add button to trigger comparison
                if st.button("Compare Seasons", key="compare_seasons_btn"):
                    # Get seasonal stats
                    all_seasonal_stats = get_team_seasonal_stats()
                    
                    # If no data in database, generate mock data
                    if not all_seasonal_stats:
                        # Generate mock seasonal data for demonstration
                        teams_list = list(st.session_state.teams_data.get('teams', {}).keys())
                        all_seasonal_stats = generate_mock_seasonal_data(
                            teams=teams_list,
                            start_year=min(seasons),
                            end_year=max(seasons)
                        )
                    
                    # Compare seasons
                    comparison = compare_seasons(all_seasonal_stats, season1, season2)
                    
                    if comparison["status"] == "success":
                        st.subheader(f"Comparison: {season1} vs {season2}")
                        
                        # Create tabs for comparison views
                        comparison_tabs = st.tabs(["Team Comparisons", "Overall Tournament Comparison"])
                        
                        # Team Comparisons Tab
                        with comparison_tabs[0]:
                            if comparison["team_comparisons"]:
                                import pandas as pd
                                import plotly.express as px
                                
                                # Create a table of team comparisons
                                teams_compared = []
                                for team_comp in comparison["team_comparisons"]:
                                    team_data = {
                                        "Team": team_comp["team"]
                                    }
                                    
                                    for metric, values in team_comp["metrics"].items():
                                        team_data[f"{metric} ({season1})"] = round(values["season1"], 2)
                                        team_data[f"{metric} ({season2})"] = round(values["season2"], 2)
                                        team_data[f"{metric} Change"] = round(values["change"], 2)
                                        
                                        # Format percent change to handle infinity
                                        if values["percent_change"] == float('inf'):
                                            team_data[f"{metric} % Change"] = "N/A"
                                        else:
                                            team_data[f"{metric} % Change"] = f"{round(values['percent_change'], 1)}%"
                                    
                                    teams_compared.append(team_data)
                                
                                comp_df = pd.DataFrame(teams_compared)
                                
                                # Display table with selected metrics
                                display_metrics = ["wins", "points", "position"]
                                display_cols = ["Team"]
                                
                                for metric in display_metrics:
                                    display_cols.extend([
                                        f"{metric} ({season1})", 
                                        f"{metric} ({season2})", 
                                        f"{metric} Change"
                                    ])
                                
                                st.subheader("Team Performance Changes")
                                
                                # Filter columns that exist in the dataframe
                                valid_cols = [col for col in display_cols if col in comp_df.columns]
                                if valid_cols:
                                    st.dataframe(comp_df[valid_cols], hide_index=True, use_container_width=True)
                                
                                # Visualize wins comparison
                                st.subheader("Wins Comparison by Team")
                                
                                # Create comparison data
                                win_data = []
                                for team in teams_compared:
                                    if "wins ("+str(season1)+")" in team and "wins ("+str(season2)+")" in team:
                                        win_data.append({
                                            "Team": team["Team"],
                                            "Season": str(season1),
                                            "Wins": team[f"wins ({season1})"]
                                        })
                                        win_data.append({
                                            "Team": team["Team"],
                                            "Season": str(season2),
                                            "Wins": team[f"wins ({season2})"]
                                        })
                                
                                win_df = pd.DataFrame(win_data)
                                
                                if not win_df.empty:
                                    win_fig = px.bar(
                                        win_df,
                                        x="Team",
                                        y="Wins",
                                        color="Season",
                                        barmode="group",
                                        title="Team Wins Comparison",
                                        height=500,
                                        color_discrete_sequence=["#3366cc", "#dc3912"]
                                    )
                                    
                                    win_fig.update_layout(xaxis_tickangle=-45)
                                    
                                    st.plotly_chart(win_fig, use_container_width=True)
                                
                                # Visualize points comparison
                                st.subheader("Points Comparison by Team")
                                
                                # Create comparison data
                                point_data = []
                                for team in teams_compared:
                                    if "points ("+str(season1)+")" in team and "points ("+str(season2)+")" in team:
                                        point_data.append({
                                            "Team": team["Team"],
                                            "Season": str(season1),
                                            "Points": team[f"points ({season1})"]
                                        })
                                        point_data.append({
                                            "Team": team["Team"],
                                            "Season": str(season2),
                                            "Points": team[f"points ({season2})"]
                                        })
                                
                                point_df = pd.DataFrame(point_data)
                                
                                if not point_df.empty:
                                    point_fig = px.bar(
                                        point_df,
                                        x="Team",
                                        y="Points",
                                        color="Season",
                                        barmode="group",
                                        title="Team Points Comparison",
                                        height=500,
                                        color_discrete_sequence=["#3366cc", "#dc3912"]
                                    )
                                    
                                    point_fig.update_layout(xaxis_tickangle=-45)
                                    
                                    st.plotly_chart(point_fig, use_container_width=True)
                                
                                # Show position changes (positive is worse, negative is better)
                                st.subheader("Team Position Changes")
                                
                                # Create position change data
                                pos_data = []
                                for team in teams_compared:
                                    if "position Change" in team:
                                        pos_change = team["position Change"]
                                        pos_data.append({
                                            "Team": team["Team"],
                                            "Position Change": -pos_change,  # Invert so positive is better (higher position)
                                            "Color": "Improved" if pos_change < 0 else "Declined" if pos_change > 0 else "Same"
                                        })
                                
                                pos_df = pd.DataFrame(pos_data)
                                
                                if not pos_df.empty:
                                    pos_fig = px.bar(
                                        pos_df,
                                        x="Team",
                                        y="Position Change",
                                        color="Color",
                                        title=f"Position Changes from {season1} to {season2}",
                                        height=500,
                                        color_discrete_map={
                                            "Improved": "#00cc96",
                                            "Declined": "#ef553b",
                                            "Same": "#636efa"
                                        }
                                    )
                                    
                                    # Add a zero line
                                    pos_fig.add_hline(
                                        y=0,
                                        line_dash="dash",
                                        line_color="gray"
                                    )
                                    
                                    pos_fig.update_layout(
                                        xaxis_tickangle=-45,
                                        yaxis_title="Position Change (Positive = Better)"
                                    )
                                    
                                    st.plotly_chart(pos_fig, use_container_width=True)
                            else:
                                st.info("No team comparison data available.")
                        
                        # Overall Tournament Comparison
                        with comparison_tabs[1]:
                            if comparison["overall_comparison"]:
                                import pandas as pd
                                import plotly.express as px
                                
                                # Create a table of overall comparisons
                                overall_data = []
                                
                                for metric, values in comparison["overall_comparison"].items():
                                    overall_data.append({
                                        "Metric": metric.replace('_', ' ').title(),
                                        str(season1): round(values["season1"], 2),
                                        str(season2): round(values["season2"], 2),
                                        "Change": round(values["change"], 2),
                                        "% Change": f"{round((values['change'] / values['season1']) * 100, 1)}%" if values["season1"] != 0 else "N/A"
                                    })
                                
                                overall_df = pd.DataFrame(overall_data)
                                
                                st.subheader("Overall Tournament Metrics")
                                st.dataframe(overall_df, hide_index=True, use_container_width=True)
                                
                                # Visualize overall comparisons
                                st.subheader("Tournament Metrics Comparison")
                                
                                # Reshape data for visualization
                                viz_data = []
                                for metric in overall_data:
                                    viz_data.append({
                                        "Metric": metric["Metric"],
                                        "Season": str(season1),
                                        "Value": metric[str(season1)]
                                    })
                                    viz_data.append({
                                        "Metric": metric["Metric"],
                                        "Season": str(season2),
                                        "Value": metric[str(season2)]
                                    })
                                
                                viz_df = pd.DataFrame(viz_data)
                                
                                # Create comparison chart
                                fig = px.bar(
                                    viz_df,
                                    x="Metric",
                                    y="Value",
                                    color="Season",
                                    barmode="group",
                                    title=f"Tournament Metrics: {season1} vs {season2}",
                                    height=500,
                                    color_discrete_sequence=["#3366cc", "#dc3912"]
                                )
                                
                                # Update layout
                                fig.update_layout(xaxis_tickangle=-45)
                                
                                st.plotly_chart(fig, use_container_width=True)
                                
                                # Create percent change visualization
                                pct_data = []
                                for metric in overall_data:
                                    if metric["% Change"] != "N/A":
                                        change_pct = float(metric["% Change"].strip('%'))
                                        pct_data.append({
                                            "Metric": metric["Metric"],
                                            "Percent Change": change_pct,
                                            "Direction": "Increase" if change_pct > 0 else "Decrease"
                                        })
                                
                                pct_df = pd.DataFrame(pct_data)
                                
                                if not pct_df.empty:
                                    pct_fig = px.bar(
                                        pct_df,
                                        x="Metric",
                                        y="Percent Change",
                                        color="Direction",
                                        title=f"Percent Change from {season1} to {season2}",
                                        height=500,
                                        color_discrete_map={
                                            "Increase": "#00cc96",
                                            "Decrease": "#ef553b"
                                        }
                                    )
                                    
                                    # Add a zero line
                                    pct_fig.add_hline(
                                        y=0,
                                        line_dash="dash",
                                        line_color="gray"
                                    )
                                    
                                    pct_fig.update_layout(
                                        xaxis_tickangle=-45,
                                        yaxis_title="Percent Change (%)"
                                    )
                                    
                                    st.plotly_chart(pct_fig, use_container_width=True)
                            else:
                                st.info("No overall comparison data available.")
                    else:
                        st.error(comparison["message"])
            else:
                st.warning("Need at least two seasons of data for comparison. Please refresh data.")
        
        # Tab 4: Performance Patterns
        with trend_analysis_tabs[3]:
            st.subheader("Performance Patterns")
            
            st.info("""
            Identify recurring patterns and trends in team performances across seasons.
            Discover which teams are consistently successful, which teams show alternating patterns,
            and what statistical patterns emerge from the historical data.
            """)
            
            # Get all seasonal stats from database
            all_seasonal_stats = get_team_seasonal_stats()
            
            # If no data in database, generate mock data
            if not all_seasonal_stats:
                st.warning("""
                Historical seasonal data is not available in the database. 
                Using simulated data for demonstration purposes.
                """)
                
                # Generate mock seasonal data for demonstration
                teams_list = list(st.session_state.teams_data.get('teams', {}).keys())
                all_seasonal_stats = generate_mock_seasonal_data(
                    teams=teams_list,
                    start_year=2016,
                    end_year=2023
                )
            
            # Set minimum seasons for analysis
            min_seasons = st.slider(
                "Minimum Seasons Required for Pattern Analysis", 
                min_value=3, 
                max_value=8, 
                value=3,
                key="pattern_min_seasons"
            )
            
            # Identify patterns
            if st.button("Analyze Performance Patterns", key="analyze_patterns_btn"):
                patterns = identify_performance_patterns(all_seasonal_stats, min_seasons=min_seasons)
                
                if patterns["status"] == "success":
                    # Create tabs for different patterns
                    pattern_tabs = st.tabs(["Team Patterns", "General Tournament Patterns"])
                    
                    # Team Patterns Tab
                    with pattern_tabs[0]:
                        if patterns["team_patterns"]:
                            # Create an expander for each team
                            for team_pattern in patterns["team_patterns"]:
                                team_name = team_pattern["team"]
                                team_patterns = team_pattern["patterns"]
                                
                                if team_patterns:
                                    with st.expander(f"{team_name} Patterns"):
                                        for pattern in team_patterns:
                                            if pattern["type"] == "consistency":
                                                st.markdown(f"🔁 **Consistency Pattern**: {pattern['description']}")
                                            elif pattern["type"] == "venue_preference":
                                                st.markdown(f"🏟️ **Venue Effect**: {pattern['description']}")
                                            elif pattern["type"] == "strength_balance":
                                                st.markdown(f"⚖️ **Team Balance**: {pattern['description']}")
                                            elif pattern["type"] == "strength_imbalance":
                                                st.markdown(f"⚠️ **Team Imbalance**: {pattern['description']}")
                                            elif pattern["type"] == "performance_cycle":
                                                st.markdown(f"🔄 **Performance Cycle**: {pattern['description']}")
                                            else:
                                                st.markdown(f"📊 **Other Pattern**: {pattern['description']}")
                        else:
                            st.info("No team-specific patterns identified with the current data and criteria.")
                    
                    # General Patterns Tab
                    with pattern_tabs[1]:
                        if patterns["general_patterns"]:
                            st.subheader("Tournament-wide Patterns")
                            
                            for pattern in patterns["general_patterns"]:
                                if pattern["type"] == "venue_impact":
                                    st.markdown(f"🏟️ **Venue Impact**: {pattern['description']} (Strength: {pattern.get('strength', 'N/A')})")
                                elif pattern["type"] == "toss_impact":
                                    st.markdown(f"🎲 **Toss Impact**: {pattern['description']} (Strength: {pattern.get('strength', 'N/A')})")
                                elif pattern["type"] == "run_impact":
                                    st.markdown(f"🏏 **Run Scoring Impact**: {pattern['description']} (Strength: {pattern.get('strength', 'N/A')})")
                                elif pattern["type"] == "consistent_performers":
                                    teams_list = ", ".join(pattern.get("teams", []))
                                    st.markdown(f"🏆 **Consistent Performers**: {pattern['description']}: {teams_list}")
                                else:
                                    st.markdown(f"📊 **Other Pattern**: {pattern['description']}")
                        else:
                            st.info("No general tournament patterns identified with the current data and criteria.")
                else:
                    st.error(patterns["message"])
    else:
        st.info("No data loaded. Please use the 'Data Refresh' tab to fetch the latest IPL player stats.")

with tabs[4]:
    st.header("Player Valuation Analysis")
    
    if st.session_state.data_loaded:
        st.markdown("""
        ### IPL Player Valuation and Market Analysis
        
        This section provides an in-depth analysis of player market value based on their performance metrics. 
        The valuation model considers batting and bowling statistics, player role, age, and experience to estimate market worth.
        
        Inspired by actual IPL auction dynamics, these valuations help identify undervalued talent and assess team investment strategy.
        """)
        
        # Add tabs for different valuation views
        valuation_tabs = st.tabs(["Player Valuations", "Team Valuations", "Value for Money Players"])
        
        with valuation_tabs[0]:
            st.subheader("IPL Player Market Value Estimations")
            
            # Generate player valuation data
            valuation_data = get_player_valuation_data(st.session_state.players_data)
            
            # Filter options
            col1, col2, col3 = st.columns(3)
            with col1:
                min_matches = st.slider("Minimum Matches Played", 0, 100, 10, key="val_min_matches")
            with col2:
                role_filter = st.multiselect(
                    "Filter by Role",
                    options=["All", "Batsman", "Bowler", "All-rounder", "Wicket-keeper Batsman"],
                    default=["All"]
                )
            with col3:
                sort_by = st.selectbox(
                    "Sort By",
                    options=["Market Value (₹ Cr)", "Value Per Match (₹ Cr)", "Value Per 10 Runs (₹ Cr)", "Value Per Wicket (₹ Cr)"],
                    index=0
                )
            
            # Filter data
            filtered_data = []
            for player in valuation_data:
                if player["Matches"] < min_matches:
                    continue
                
                if "All" not in role_filter and player["Role"] not in role_filter:
                    continue
                    
                filtered_data.append(player)
            
            # Sort data
            filtered_data.sort(key=lambda x: x.get(sort_by, 0), reverse=True)
            
            # Create dataframe for display
            display_columns = ["Player", "Team", "Role", "Age", "Matches", sort_by]
            
            if filtered_data:
                # Convert to DataFrame for display
                player_value_df = pd.DataFrame(filtered_data)[display_columns]
                
                # Display the table
                st.dataframe(player_value_df)
                
                # Create visualization
                import plotly.express as px
                
                # Top 15 players by value
                top_players = filtered_data[:15]
                
                fig = px.bar(
                    top_players,
                    x="Player",
                    y=sort_by,
                    color="Team",
                    title=f"Top 15 Players by {sort_by}",
                    hover_data=["Role", "Age", "Matches"],
                    color_discrete_sequence=px.colors.qualitative.Bold
                )
                fig.update_layout(xaxis_tickangle=-45)
                st.plotly_chart(fig, use_container_width=True)
                
                # Player Value Breakdown Analysis
                st.subheader("Player Value Breakdown Analysis")
                
                # Allow user to select a player to see detailed valuation
                selected_player_name = st.selectbox(
                    "Select Player for Detailed Valuation",
                    options=[p["Player"] for p in filtered_data]
                )
                
                # Find the selected player
                selected_player = next((p for p in filtered_data if p["Player"] == selected_player_name), None)
                
                if selected_player:
                    col1, col2 = st.columns([1, 2])
                    
                    with col1:
                        st.markdown(f"### {selected_player['Player']}")
                        st.markdown(f"**Team:** {selected_player['Team']}")
                        st.markdown(f"**Role:** {selected_player['Role']}")
                        st.markdown(f"**Age:** {selected_player['Age']}")
                        st.markdown(f"**Matches:** {selected_player['Matches']}")
                        
                        # Get player data for auction prediction
                        player_id = next((pid for pid, p in st.session_state.players_data.items() 
                                        if p.get('name') == selected_player['Player']), None)
                                        
                        if player_id:
                            player_data = st.session_state.players_data[player_id]
                            auction_prediction = calculate_player_auction_price_prediction(player_data)
                            
                            st.markdown("### Auction Price Prediction")
                            st.markdown(f"**Minimum Price:** ₹ {auction_prediction['min_price']} Cr")
                            st.markdown(f"**Expected Price:** ₹ {auction_prediction['expected_price']} Cr")
                            st.markdown(f"**Maximum Price:** ₹ {auction_prediction['max_price']} Cr")
                    
                    with col2:
                        # Create valuation breakdown chart
                        batting_stats = selected_player["Batting Stats"]
                        bowling_stats = selected_player["Bowling Stats"]
                        
                        # Value components
                        value_components = {
                            "Component": ["Base Value", "Batting Value", "Bowling Value", "Role Premium", "Age Factor"],
                            "Value (₹ Cr)": [
                                round(selected_player["Market Value (₹ Cr)"] * 0.3, 2),  # Base value estimate
                                round(selected_player["Market Value (₹ Cr)"] * batting_stats["Runs"] / max(1, batting_stats["Runs"] + bowling_stats["Wickets"] * 20), 2),
                                round(selected_player["Market Value (₹ Cr)"] * bowling_stats["Wickets"] * 20 / max(1, batting_stats["Runs"] + bowling_stats["Wickets"] * 20), 2),
                                round(selected_player["Market Value (₹ Cr)"] * 0.1, 2),  # Role premium estimate
                                round(selected_player["Market Value (₹ Cr)"] * 0.1, 2)   # Age factor estimate
                            ]
                        }
                        
                        # Display value breakdown
                        value_df = pd.DataFrame(value_components)
                        
                        # Create a pie chart for value breakdown
                        fig = px.pie(
                            value_df,
                            values="Value (₹ Cr)",
                            names="Component",
                            title="Player Value Contribution Breakdown",
                            color_discrete_sequence=px.colors.qualitative.Bold
                        )
                        st.plotly_chart(fig, use_container_width=True)
            else:
                st.info("No players match the selected filters.")

        with valuation_tabs[1]:
            st.subheader("IPL Team Valuation Analysis")
            
            # Calculate team valuations
            team_valuations = get_team_valuation_data(st.session_state.players_data)
            
            if team_valuations:
                # Convert to dataframe for display
                team_data = []
                for team_name, team_value in team_valuations.items():
                    team_data.append({
                        "Team": team_name,
                        "Total Value (₹ Cr)": round(team_value["total_value"], 2),
                        "Avg. Player Value (₹ Cr)": team_value["average_player_value"],
                        "Players": team_value["player_count"],
                        "Batting Value (₹ Cr)": round(team_value["batting_value"], 2),
                        "Bowling Value (₹ Cr)": round(team_value["bowling_value"], 2),
                        "All-rounder Value (₹ Cr)": round(team_value["all_rounder_value"], 2),
                        "Wicket-keeper Value (₹ Cr)": round(team_value["wicket_keeper_value"], 2)
                    })
                
                # Sort by total value
                team_data.sort(key=lambda x: x["Total Value (₹ Cr)"], reverse=True)
                
                # Display the table
                team_value_df = pd.DataFrame(team_data)
                st.dataframe(team_value_df)
                
                # Create visualizations
                col1, col2 = st.columns(2)
                
                with col1:
                    # Total team value comparison
                    fig1 = px.bar(
                        team_data,
                        x="Team",
                        y="Total Value (₹ Cr)",
                        color="Team",
                        title="IPL Team Total Value Comparison",
                        color_discrete_sequence=px.colors.qualitative.Bold
                    )
                    st.plotly_chart(fig1, use_container_width=True)
                
                with col2:
                    # Average player value comparison
                    fig2 = px.bar(
                        team_data,
                        x="Team",
                        y="Avg. Player Value (₹ Cr)",
                        color="Team",
                        title="IPL Team Average Player Value",
                        color_discrete_sequence=px.colors.qualitative.Vivid
                    )
                    st.plotly_chart(fig2, use_container_width=True)
                
                # Team value composition analysis
                st.subheader("Team Value Composition Analysis")
                
                # Create value composition data
                composition_data = []
                categories = ["Batting Value (₹ Cr)", "Bowling Value (₹ Cr)", 
                              "All-rounder Value (₹ Cr)", "Wicket-keeper Value (₹ Cr)"]
                
                for team in team_data:
                    for category in categories:
                        composition_data.append({
                            "Team": team["Team"],
                            "Category": category.split(" (")[0],
                            "Value (₹ Cr)": team[category]
                        })
                
                # Create stacked bar chart
                fig3 = px.bar(
                    composition_data,
                    x="Team",
                    y="Value (₹ Cr)",
                    color="Category",
                    title="IPL Team Value Composition",
                    barmode="stack",
                    color_discrete_sequence=px.colors.qualitative.Bold
                )
                st.plotly_chart(fig3, use_container_width=True)
                
                # Team investment strategy analysis
                st.subheader("Team Investment Strategy Analysis")
                
                # Allow user to select a team to analyze
                selected_team = st.selectbox(
                    "Select Team for Investment Strategy Analysis",
                    options=[t["Team"] for t in team_data]
                )
                
                # Find selected team data
                team_info = next((t for t in team_data if t["Team"] == selected_team), None)
                
                if team_info:
                    # Create radar chart data for team's investment strategy
                    categories = ["Batting", "Bowling", "All-rounders", "Wicket-keepers"]
                    values = [
                        team_info["Batting Value (₹ Cr)"] / team_info["Total Value (₹ Cr)"] * 100,
                        team_info["Bowling Value (₹ Cr)"] / team_info["Total Value (₹ Cr)"] * 100,
                        team_info["All-rounder Value (₹ Cr)"] / team_info["Total Value (₹ Cr)"] * 100,
                        team_info["Wicket-keeper Value (₹ Cr)"] / team_info["Total Value (₹ Cr)"] * 100
                    ]
                    
                    # Create radar chart
                    import plotly.graph_objects as go
                    
                    fig = go.Figure()
                    
                    fig.add_trace(go.Scatterpolar(
                        r=values,
                        theta=categories,
                        fill='toself',
                        name=selected_team
                    ))
                    
                    fig.update_layout(
                        title=f"{selected_team} Investment Strategy",
                        polar=dict(
                            radialaxis=dict(
                                visible=True,
                                range=[0, max(values) + 10]  # Add some padding
                            )),
                        showlegend=False
                    )
                    
                    st.plotly_chart(fig, use_container_width=True)
                    
                    # Investment recommendations
                    st.subheader("Investment Recommendations")
                    
                    # Simple recommendation logic
                    investment_areas = []
                    
                    if values[0] < 25:  # Batting investment low
                        investment_areas.append("- Invest in quality top-order batsmen")
                    if values[1] < 25:  # Bowling investment low
                        investment_areas.append("- Consider strengthening the bowling attack")
                    if values[2] < 15:  # All-rounders investment low
                        investment_areas.append("- Add more all-rounders for team balance")
                    if values[3] < 10:  # Wicket-keeper investment low
                        investment_areas.append("- Look for a reliable wicket-keeper batsman")
                    
                    if not investment_areas:
                        investment_areas.append("- Team has a balanced investment strategy")
                        
                    st.markdown("\n".join(investment_areas))
            else:
                st.info("No team valuation data available.")

        with valuation_tabs[2]:
            st.subheader("Value for Money Players Analysis")
            
            # Filter options
            col1, col2 = st.columns(2)
            with col1:
                vfm_role = st.selectbox(
                    "Select Role",
                    options=["All", "Batsman", "Bowler", "All-rounder", "Wicket-keeper Batsman"],
                    index=0
                )
            with col2:
                vfm_min_matches = st.slider("Minimum Matches Played", 0, 100, 5, key="vfm_matches")
            
            # Get role-specific players
            role_to_use = None if vfm_role == "All" else vfm_role
            
            # Get value for money players
            vfm_players = get_value_for_money_players(st.session_state.players_data, role_to_use, vfm_min_matches)
            
            if vfm_players:
                # Display top value for money players
                vfm_df = pd.DataFrame(vfm_players)
                st.dataframe(vfm_df)
                
                # Visualization of top value for money players
                top_vfm = vfm_players[:10]  # Top 10
                
                fig = px.bar(
                    top_vfm,
                    x="Player",
                    y="Performance Ratio",
                    color="Team",
                    title="Top Value for Money Players (Higher Ratio = Better Value)",
                    hover_data=["Role", "Value (₹ Cr)", "Age"],
                    color_discrete_sequence=px.colors.qualitative.Bold
                )
                fig.update_layout(xaxis_tickangle=-45)
                st.plotly_chart(fig, use_container_width=True)
                
                # Scatter plot for value vs. performance
                st.subheader("Player Value vs. Performance Analysis")
                
                # Create scatter plot based on role
                if vfm_role in ["All", "Batsman", "Wicket-keeper Batsman"]:
                    # Filter to batsmen
                    batting_players = [p for p in vfm_players if "Batsman" in p["Role"]]
                    
                    if batting_players:
                        fig2 = px.scatter(
                            batting_players,
                            x="Value (₹ Cr)",
                            y="Runs",
                            size="Performance Ratio",
                            color="Team",
                            hover_name="Player",
                            title="Batting Value Analysis: Runs vs. Market Value",
                            color_discrete_sequence=px.colors.qualitative.Bold
                        )
                        st.plotly_chart(fig2, use_container_width=True)
                
                if vfm_role in ["All", "Bowler"]:
                    # Filter to bowlers
                    bowling_players = [p for p in vfm_players if p["Role"] == "Bowler"]
                    
                    if bowling_players:
                        fig3 = px.scatter(
                            bowling_players,
                            x="Value (₹ Cr)",
                            y="Wickets",
                            size="Performance Ratio",
                            color="Team",
                            hover_name="Player",
                            title="Bowling Value Analysis: Wickets vs. Market Value",
                            color_discrete_sequence=px.colors.qualitative.Bold
                        )
                        st.plotly_chart(fig3, use_container_width=True)
                
                if vfm_role in ["All", "All-rounder"]:
                    # Filter to all-rounders
                    allrounder_players = [p for p in vfm_players if p["Role"] == "All-rounder"]
                    
                    if allrounder_players:
                        fig4 = px.scatter(
                            allrounder_players,
                            x="Runs",
                            y="Wickets",
                            size="Value (₹ Cr)",
                            color="Team",
                            hover_name="Player",
                            title="All-rounders Value Analysis",
                            color_discrete_sequence=px.colors.qualitative.Bold
                        )
                        st.plotly_chart(fig4, use_container_width=True)
            else:
                st.info("No value for money players found with selected criteria.")
    else:
        st.info("No data loaded. Please use the 'Data Refresh' tab to fetch the latest IPL player stats.")

# Performance Prediction Tab
with tabs[5]:
    st.header("Performance Prediction")
    
    if st.session_state.data_loaded:
        st.markdown("""
        ### IPL Player Performance Prediction
        
        This section uses statistical modeling to predict player performance in upcoming matches based on 
        historical statistics, recent form, and matchup analysis. These predictions can help in fantasy team selection, 
        match strategy, and player analysis.
        
        **Note:** Predictions are based on available historical data and statistical models, actual performance may vary.
        """)
        
        # Create tabs for different prediction views
        prediction_tabs = st.tabs(["Player Match Prediction", "Player Season Projection", "Team Match Prediction", "Player Ratings"])
        
        # Tab 1: Player Match Prediction
        with prediction_tabs[0]:
            st.subheader("Player Performance Prediction for Upcoming Match")
            
            # Player selection
            all_players = [(p.get('name', 'Unknown'), p.get('id')) 
                        for p in st.session_state.players_data.values()]
            all_players.sort(key=lambda x: x[0])  # Sort by name
            
            col1, col2, col3 = st.columns(3)
            
            with col1:
                player_for_prediction = st.selectbox(
                    "Select Player",
                    all_players,
                    format_func=lambda x: x[0],
                    key="player_pred"
                )
            
            # Opponent team selection
            with col2:
                team_names = list(st.session_state.teams_data.get('teams', {}).keys())
                opponent_team = st.selectbox(
                    "Select Opponent Team",
                    team_names,
                    key="opponent_team"
                )
            
            # Venue selection
            with col3:
                # Get unique venues from team home grounds
                venues = []
                for team, info in st.session_state.teams_data.get('teams', {}).items():
                    venue = info.get('home_ground')
                    if venue and venue not in venues:
                        venues.append(venue)
                
                match_venue = st.selectbox(
                    "Select Match Venue",
                    venues,
                    key="match_venue"
                )
            
            if player_for_prediction:
                player_data = st.session_state.players_data.get(player_for_prediction[1])
                
                if player_data:
                    player_role = player_data.get('role', '')
                    col1, col2 = st.columns(2)
                    
                    with col1:
                        # Display player info
                        player_team = player_data.get('team', 'Unknown Team')
                        player_color = st.session_state.teams_data['teams'].get(player_team, {}).get('color', '#3366cc')
                        
                        st.markdown(f"""
                        <div style="border-left: 4px solid {player_color}; padding-left: 10px; margin-bottom: 20px;">
                            <h3 style="margin-bottom: 5px;">{player_data.get('name', 'Unknown')}</h3>
                            <p><strong>Team:</strong> {player_team}</p>
                            <p><strong>Role:</strong> {player_role}</p>
                            <p><strong>Matches:</strong> {player_data.get('matches_played', 'N/A')}</p>
                        </div>
                        """, unsafe_allow_html=True)
                        
                        # Get predictions
                        batting_prediction = predict_batting_performance(
                            player_data, 
                            opponent_team=opponent_team, 
                            venue=match_venue
                        )
                        
                        if any(batting_prediction.values()):
                            st.markdown("### Batting Prediction")
                            st.markdown(f"""
                            <div style="background-color: rgba(0,100,0,0.1); padding: 15px; border-radius: 5px;">
                                <h4>Predicted Runs: {batting_prediction.get('predicted_runs', 'N/A')}</h4>
                                <p><strong>Run Range:</strong> {batting_prediction.get('run_range_low', 'N/A')} - {batting_prediction.get('run_range_high', 'N/A')}</p>
                                <p><strong>Predicted Strike Rate:</strong> {batting_prediction.get('predicted_strike_rate', 'N/A')}</p>
                                <p><strong>Expected Boundaries:</strong> {batting_prediction.get('boundary_count', 'N/A')}</p>
                                <p><strong>Prediction Confidence:</strong> {batting_prediction.get('confidence', 'Low')}</p>
                            </div>
                            """, unsafe_allow_html=True)
                    
                    with col2:
                        # Bowling prediction if applicable
                        bowling_prediction = predict_bowling_performance(
                            player_data, 
                            opponent_team=opponent_team, 
                            venue=match_venue
                        )
                        
                        if any(bowling_prediction.values()):
                            st.markdown("### Bowling Prediction")
                            st.markdown(f"""
                            <div style="background-color: rgba(0,0,100,0.1); padding: 15px; border-radius: 5px;">
                                <h4>Predicted Wickets: {bowling_prediction.get('predicted_wickets', 'N/A')}</h4>
                                <p><strong>Wicket Range:</strong> {bowling_prediction.get('wicket_range_low', 'N/A')} - {bowling_prediction.get('wicket_range_high', 'N/A')}</p>
                                <p><strong>Predicted Economy:</strong> {bowling_prediction.get('predicted_economy', 'N/A')}</p>
                                <p><strong>Expected Dot Ball %:</strong> {bowling_prediction.get('dot_ball_percentage', 'N/A')}%</p>
                                <p><strong>Prediction Confidence:</strong> {bowling_prediction.get('confidence', 'Low')}</p>
                            </div>
                            """, unsafe_allow_html=True)
                        
                        # Player matchups
                        st.markdown("### Player Matchups")
                        
                        # Get opponent team players 
                        opponent_players = []
                        for pid, p in st.session_state.players_data.items():
                            if p.get('team') == opponent_team:
                                opponent_players.append(p)
                        
                        if opponent_players:
                            matchups = get_player_matchups(player_data, opponent_team, opponent_players)
                            
                            # Favorable matchups
                            if matchups.get('favorable_matchups'):
                                st.markdown("#### Favorable Matchups")
                                for match in matchups['favorable_matchups']:
                                    st.markdown(f"""
                                    <div style="background-color: rgba(0,100,0,0.1); padding: 10px; margin-bottom: 5px; border-radius: 5px;">
                                        <p><strong>{match.get('player', 'Unknown')}</strong> ({match.get('role', 'N/A')})</p>
                                        <p><em>{match.get('reason', '')}</em></p>
                                    </div>
                                    """, unsafe_allow_html=True)
                            
                            # Challenging matchups
                            if matchups.get('challenging_matchups'):
                                st.markdown("#### Challenging Matchups")
                                for match in matchups['challenging_matchups']:
                                    st.markdown(f"""
                                    <div style="background-color: rgba(100,0,0,0.1); padding: 10px; margin-bottom: 5px; border-radius: 5px;">
                                        <p><strong>{match.get('player', 'Unknown')}</strong> ({match.get('role', 'N/A')})</p>
                                        <p><em>{match.get('reason', '')}</em></p>
                                    </div>
                                    """, unsafe_allow_html=True)
                        else:
                            st.info("No player matchup data available for the selected opponent team.")
                    
                    # Show performance factors
                    st.subheader("Performance Factors")
                    
                    # Create factors that might affect performance
                    factors = []
                    
                    # Team matchup factor
                    factors.append({
                        "Factor": "Team Matchup",
                        "Impact": np.random.choice(["Positive", "Neutral", "Negative"]),
                        "Description": f"Historical performance against {opponent_team}"
                    })
                    
                    # Venue factor
                    factors.append({
                        "Factor": "Venue",
                        "Impact": "Positive" if player_data.get('team', '') in match_venue else np.random.choice(["Neutral", "Negative"]),
                        "Description": f"Performance at {match_venue}"
                    })
                    
                    # Recent form (would be based on actual data)
                    factors.append({
                        "Factor": "Recent Form",
                        "Impact": np.random.choice(["Positive", "Neutral", "Negative"]),
                        "Description": "Based on performance in last few matches"
                    })
                    
                    # Display factors
                    factors_df = pd.DataFrame(factors)
                    
                    # Add color styling
                    def highlight_impact(val):
                        if val == "Positive":
                            return "background-color: rgba(0,100,0,0.2)"
                        elif val == "Negative":
                            return "background-color: rgba(100,0,0,0.2)"
                        else:
                            return "background-color: rgba(100,100,100,0.1)"
                    
                    st.dataframe(
                        factors_df.style.applymap(highlight_impact, subset=["Impact"]),
                        hide_index=True
                    )
                else:
                    st.warning("Player data not available.")
            else:
                st.info("Please select a player for prediction.")
        
        # Tab 2: Player Season Projection
        with prediction_tabs[1]:
            st.subheader("Season Performance Projection")
            
            # Player selection
            season_players = [(p.get('name', 'Unknown'), p.get('id')) 
                           for p in st.session_state.players_data.values()]
            season_players.sort(key=lambda x: x[0])  # Sort by name
            
            col1, col2 = st.columns(2)
            
            with col1:
                season_player = st.selectbox(
                    "Select Player",
                    season_players,
                    format_func=lambda x: x[0],
                    key="season_player"
                )
            
            with col2:
                num_matches = st.slider(
                    "Number of Matches in Season",
                    min_value=10,
                    max_value=17,
                    value=14,
                    key="season_matches"
                )
            
            if season_player:
                player_data = st.session_state.players_data.get(season_player[1])
                
                if player_data:
                    # Get season prediction
                    season_prediction = predict_season_performance(player_data, num_matches)
                    
                    col1, col2 = st.columns([1, 2])
                    
                    with col1:
                        # Display player info
                        player_team = player_data.get('team', 'Unknown Team')
                        player_color = st.session_state.teams_data['teams'].get(player_team, {}).get('color', '#3366cc')
                        player_role = player_data.get('role', '')
                        
                        st.markdown(f"""
                        <div style="border-left: 4px solid {player_color}; padding-left: 10px; margin-bottom: 20px;">
                            <h3 style="margin-bottom: 5px;">{player_data.get('name', 'Unknown')}</h3>
                            <p><strong>Team:</strong> {player_team}</p>
                            <p><strong>Role:</strong> {player_role}</p>
                            <p><strong>Total Career Matches:</strong> {player_data.get('matches_played', 'N/A')}</p>
                        </div>
                        """, unsafe_allow_html=True)
                        
                        # Display season projection if available
                        if season_prediction.get('expected_matches'):
                            st.markdown("### Season Projection")
                            st.markdown(f"""
                            <div style="background-color: rgba(50,50,100,0.1); padding: 15px; border-radius: 5px;">
                                <p><strong>Expected Matches:</strong> {season_prediction.get('expected_matches', 'N/A')}</p>
                                <p><strong>Projected Runs:</strong> {season_prediction.get('season_runs', 'N/A')}</p>
                                <p><strong>Projected Average:</strong> {season_prediction.get('season_average', 'N/A')}</p>
                                <p><strong>Projected Wickets:</strong> {season_prediction.get('season_wickets', 'N/A')}</p>
                                <p><strong>Projected Economy:</strong> {season_prediction.get('season_economy', 'N/A')}</p>
                                <p><strong>Prediction Confidence:</strong> {season_prediction.get('confidence', 'Low')}</p>
                            </div>
                            """, unsafe_allow_html=True)
                    
                    with col2:
                        # Create visualizations for season projection
                        import plotly.graph_objects as go
                        
                        # Historical vs projected performance
                        batting_stats = player_data.get('batting_stats', {})
                        bowling_stats = player_data.get('bowling_stats', {})
                        
                        # Only show relevant stats based on role
                        if "Batsman" in player_role or player_role == "All-rounder":
                            # Batting projection chart
                            batting_fig = go.Figure()
                            
                            # Historical performance
                            career_runs = batting_stats.get('runs', 0)
                            career_matches = player_data.get('matches_played', 0)
                            
                            career_avg_runs_per_match = career_runs / max(1, career_matches)
                            projected_runs = season_prediction.get('season_runs', 0)
                            
                            # Add historical data
                            batting_fig.add_trace(go.Bar(
                                x=["Historical (per match)", "Season Projection (total)"],
                                y=[career_avg_runs_per_match, projected_runs],
                                marker_color=[player_color, "lightgreen"],
                                text=[f"{career_avg_runs_per_match:.1f}", f"{projected_runs}"],
                                textposition="auto"
                            ))
                            
                            batting_fig.update_layout(
                                title="Batting Performance Projection",
                                xaxis_title="",
                                yaxis_title="Runs",
                                height=400
                            )
                            
                            st.plotly_chart(batting_fig, use_container_width=True)
                        
                        if player_role == "Bowler" or player_role == "All-rounder":
                            # Bowling projection chart
                            bowling_fig = go.Figure()
                            
                            # Historical performance
                            career_wickets = bowling_stats.get('wickets', 0)
                            career_matches = player_data.get('matches_played', 0)
                            
                            career_avg_wickets_per_match = career_wickets / max(1, career_matches)
                            projected_wickets = season_prediction.get('season_wickets', 0)
                            
                            # Add historical data
                            bowling_fig.add_trace(go.Bar(
                                x=["Historical (per match)", "Season Projection (total)"],
                                y=[career_avg_wickets_per_match, projected_wickets],
                                marker_color=[player_color, "lightblue"],
                                text=[f"{career_avg_wickets_per_match:.1f}", f"{projected_wickets}"],
                                textposition="auto"
                            ))
                            
                            bowling_fig.update_layout(
                                title="Bowling Performance Projection",
                                xaxis_title="",
                                yaxis_title="Wickets",
                                height=400
                            )
                            
                            st.plotly_chart(bowling_fig, use_container_width=True)
                else:
                    st.warning("Player data not available.")
            else:
                st.info("Please select a player for season projection.")
        
        # Tab 3: Team Match Prediction
        with prediction_tabs[2]:
            st.subheader("Team Match Outcome Prediction")
            
            # Team selection
            team_names = list(st.session_state.teams_data.get('teams', {}).keys())
            
            col1, col2, col3 = st.columns(3)
            
            with col1:
                team1 = st.selectbox(
                    "Select Team 1",
                    team_names,
                    key="match_team1"
                )
            
            with col2:
                # Filter to exclude team1
                team2_options = [t for t in team_names if t != team1]
                team2 = st.selectbox(
                    "Select Team 2",
                    team2_options,
                    key="match_team2"
                )
            
            with col3:
                # Get unique venues from team home grounds
                venues = []
                for team, info in st.session_state.teams_data.get('teams', {}).items():
                    venue = info.get('home_ground')
                    if venue and venue not in venues:
                        venues.append(venue)
                
                team_match_venue = st.selectbox(
                    "Select Match Venue",
                    venues,
                    key="team_match_venue"
                )
            
            if team1 and team2:
                # Prepare team data
                team1_data = {
                    'name': team1,
                    'home_ground': st.session_state.teams_data.get('teams', {}).get(team1, {}).get('home_ground', ''),
                    'players': []
                }
                
                team2_data = {
                    'name': team2,
                    'home_ground': st.session_state.teams_data.get('teams', {}).get(team2, {}).get('home_ground', ''),
                    'players': []
                }
                
                # Generate player ratings
                player_ratings = generate_player_ratings(st.session_state.players_data)
                
                # Add players with ratings to team data
                for player_id, rating in player_ratings.items():
                    player = st.session_state.players_data.get(player_id, {})
                    player_team = player.get('team', '')
                    
                    if player_team == team1:
                        team1_data['players'].append({
                            'name': player.get('name', ''),
                            'role': player.get('role', ''),
                            'batting_rating': rating.get('batting_rating', 0),
                            'bowling_rating': rating.get('bowling_rating', 0),
                            'overall_rating': rating.get('overall_rating', 0)
                        })
                    elif player_team == team2:
                        team2_data['players'].append({
                            'name': player.get('name', ''),
                            'role': player.get('role', ''),
                            'batting_rating': rating.get('batting_rating', 0),
                            'bowling_rating': rating.get('bowling_rating', 0),
                            'overall_rating': rating.get('overall_rating', 0)
                        })
                
                # Get match prediction
                match_prediction = get_match_prediction(team1_data, team2_data, team_match_venue)
                
                # Display prediction
                if match_prediction:
                    st.markdown("""
                    ### Match Prediction Using Advanced Statistical Methods
                    
                    Our prediction model combines **Bayesian inference**, the **Central Limit Theorem**, and the **Law of Large Numbers** 
                    to generate accurate cricket match predictions based on team and player statistics.
                    """)
                    
                    # Create tabs for different analysis views
                    prediction_analysis_tabs = st.tabs([
                        "Prediction Summary", "Statistical Insights", "Mathematical Model"
                    ])
                    
                    # Team colors
                    team1_color = st.session_state.teams_data['teams'].get(team1, {}).get('color', '#3366cc')
                    team2_color = st.session_state.teams_data['teams'].get(team2, {}).get('color', '#cc3366')
                    
                    # Extract data
                    team1_win_prob = match_prediction.get('team1', {}).get('win_probability', 0)
                    team2_win_prob = match_prediction.get('team2', {}).get('win_probability', 0)
                    team1_score = match_prediction.get('team1', {}).get('predicted_score', 0)
                    team2_score = match_prediction.get('team2', {}).get('predicted_score', 0)
                    team1_reliability = match_prediction.get('team1', {}).get('reliability', 0)
                    team2_reliability = match_prediction.get('team2', {}).get('reliability', 0)
                    team1_confidence = match_prediction.get('team1', {}).get('confidence', 0)
                    team2_confidence = match_prediction.get('team2', {}).get('confidence', 0)
                    
                    # Get winner info
                    winner = match_prediction.get('expected_winner', '')
                    winner_color = st.session_state.teams_data['teams'].get(winner, {}).get('color', '#3366cc')
                    win_prob = match_prediction.get('win_probability', 0)
                    
                    # -------------
                    # Prediction Summary Tab
                    # -------------
                    with prediction_analysis_tabs[0]:
                        col1, col2 = st.columns([3, 2])
                        
                        with col1:
                            # Expected winner box
                            st.markdown(f"""
                            <div style="background-color: rgba(50,50,100,0.1); padding: 15px; border-radius: 5px; margin-bottom: 20px;">
                                <h3 style="color: {winner_color}; text-align: center;">Expected Winner: {winner}</h3>
                                <p style="text-align: center; font-size: 18px;">Win Probability: {win_prob}%</p>
                            </div>
                            """, unsafe_allow_html=True)
                            
                            # Win probability bar chart
                            import plotly.graph_objects as go
                            
                            fig = go.Figure()
                            
                            fig.add_trace(go.Bar(
                                x=[team1_win_prob],
                                y=[team1],
                                orientation='h',
                                marker_color=team1_color,
                                text=[f"{team1_win_prob}%"],
                                textposition="inside",
                                name=team1
                            ))
                            
                            fig.add_trace(go.Bar(
                                x=[team2_win_prob],
                                y=[team2],
                                orientation='h',
                                marker_color=team2_color,
                                text=[f"{team2_win_prob}%"],
                                textposition="inside",
                                name=team2
                            ))
                            
                            fig.update_layout(
                                title="Win Probability",
                                xaxis_title="Probability (%)",
                                yaxis_title="Team",
                                yaxis=dict(tickfont=dict(size=14)),
                                xaxis=dict(range=[0, 100]),
                                height=200,
                                barmode='group',
                                bargap=0.15,
                                margin=dict(l=10, r=10, t=40, b=10)
                            )
                            
                            st.plotly_chart(fig, use_container_width=True)
                            
                            # Predicted score bar chart
                            score_fig = go.Figure()
                            
                            score_fig.add_trace(go.Bar(
                                x=[team1],
                                y=[team1_score],
                                marker_color=team1_color,
                                text=[team1_score],
                                textposition="outside",
                                name=team1
                            ))
                            
                            score_fig.add_trace(go.Bar(
                                x=[team2],
                                y=[team2_score],
                                marker_color=team2_color,
                                text=[team2_score],
                                textposition="outside",
                                name=team2
                            ))
                            
                            score_fig.update_layout(
                                title="Predicted Team Scores",
                                xaxis_title="",
                                yaxis_title="Score",
                                height=300,
                                margin=dict(l=10, r=10, t=40, b=10)
                            )
                            
                            st.plotly_chart(score_fig, use_container_width=True)
                            
                        with col2:
                            # Statistical insights
                            st.markdown("### Key Match Insights")
                            statistical_insights = match_prediction.get('statistical_insights', [])
                            
                            if statistical_insights:
                                for insight in statistical_insights:
                                    st.markdown(f"- {insight}")
                            else:
                                st.info("No statistical insights available.")
                            
                            # Team comparison metrics
                            st.markdown("### Team Metrics")
                            
                            # Create metrics comparison table
                            metrics_df = pd.DataFrame({
                                'Metric': ['Batting Strength', 'Bowling Strength', 'Performance Reliability', 'Prediction Confidence'],
                                team1: [
                                    match_prediction.get('team1', {}).get('batting_strength', 0),
                                    match_prediction.get('team1', {}).get('bowling_strength', 0),
                                    f"{team1_reliability}%",
                                    f"{team1_confidence}%"
                                ],
                                team2: [
                                    match_prediction.get('team2', {}).get('batting_strength', 0),
                                    match_prediction.get('team2', {}).get('bowling_strength', 0),
                                    f"{team2_reliability}%",
                                    f"{team2_confidence}%"
                                ]
                            })
                            
                            st.dataframe(metrics_df, hide_index=True)
                            
                            # Team strength radar chart
                            team1_metrics = [
                                match_prediction.get('team1', {}).get('batting_strength', 0) / 100,
                                match_prediction.get('team1', {}).get('bowling_strength', 0) / 100,
                                team1_reliability / 100,
                                team1_confidence / 100
                            ]
                            
                            team2_metrics = [
                                match_prediction.get('team2', {}).get('batting_strength', 0) / 100,
                                match_prediction.get('team2', {}).get('bowling_strength', 0) / 100,
                                team2_reliability / 100,
                                team2_confidence / 100
                            ]
                            
                            # Calculate the maximum for scaling
                            max_value = max(max(team1_metrics), max(team2_metrics))
                            scale_factor = 1.0 / max(0.1, max_value) 
                            
                            # Scale values to 0-1 range
                            team1_metrics = [val * scale_factor for val in team1_metrics]
                            team2_metrics = [val * scale_factor for val in team2_metrics]
                            
                            radar_fig = go.Figure()
                            
                            categories = ['Batting', 'Bowling', 'Reliability', 'Confidence']
                            
                            radar_fig.add_trace(go.Scatterpolar(
                                r=team1_metrics,
                                theta=categories,
                                fill='toself',
                                name=team1,
                                line_color=team1_color
                            ))
                            
                            radar_fig.add_trace(go.Scatterpolar(
                                r=team2_metrics,
                                theta=categories,
                                fill='toself',
                                name=team2,
                                line_color=team2_color
                            ))
                            
                            radar_fig.update_layout(
                                polar=dict(
                                    radialaxis=dict(
                                        visible=True,
                                        range=[0, 1]
                                    )
                                ),
                                title="Team Strength Analysis",
                                height=300,
                                margin=dict(l=10, r=10, t=40, b=10)
                            )
                            
                            st.plotly_chart(radar_fig, use_container_width=True)
                    
                    # -------------
                    # Statistical Insights Tab
                    # -------------
                    with prediction_analysis_tabs[1]:
                        st.markdown("""
                        ### Statistical Analysis Details
                        Our prediction model leverages three fundamental statistical principles:
                        """)
                        
                        # Create columns
                        col1, col2 = st.columns(2)
                        
                        with col1:
                            # Team strength comparison
                            st.markdown("#### Team Strength Comparison")
                            
                            # Calculate team strengths
                            team1_batting = match_prediction.get('team1', {}).get('batting_strength', 0)
                            team1_bowling = match_prediction.get('team1', {}).get('bowling_strength', 0)
                            
                            team2_batting = match_prediction.get('team2', {}).get('batting_strength', 0)
                            team2_bowling = match_prediction.get('team2', {}).get('bowling_strength', 0)
                            
                            # Create strength comparison chart
                            strength_fig = go.Figure()
                            
                            strength_fig.add_trace(go.Bar(
                                x=['Batting', 'Bowling'],
                                y=[team1_batting, team1_bowling],
                                name=team1,
                                marker_color=team1_color
                            ))
                            
                            strength_fig.add_trace(go.Bar(
                                x=['Batting', 'Bowling'],
                                y=[team2_batting, team2_bowling],
                                name=team2,
                                marker_color=team2_color
                            ))
                            
                            strength_fig.update_layout(
                                title="Team Strength Comparison",
                                yaxis_title="Strength Rating",
                                height=300,
                                barmode='group',
                                bargap=0.15,
                                margin=dict(l=10, r=10, t=40, b=10)
                            )
                            
                            st.plotly_chart(strength_fig, use_container_width=True)
                            
                            # Law of Large Numbers explanation
                            st.markdown("""
                            #### Law of Large Numbers
                            
                            The Law of Large Numbers tells us that teams with more consistently performing players will have more predictable outcomes:
                            """)
                            
                            # Reliability comparison
                            reliability_fig = go.Figure()
                            
                            reliability_fig.add_trace(go.Bar(
                                x=[team1],
                                y=[team1_reliability],
                                marker_color=team1_color,
                                text=[f"{team1_reliability}%"],
                                textposition="auto",
                                name=team1
                            ))
                            
                            reliability_fig.add_trace(go.Bar(
                                x=[team2],
                                y=[team2_reliability],
                                marker_color=team2_color,
                                text=[f"{team2_reliability}%"],
                                textposition="auto",
                                name=team2
                            ))
                            
                            reliability_fig.update_layout(
                                title="Team Performance Reliability",
                                yaxis_title="Reliability (%)",
                                height=300,
                                margin=dict(l=10, r=10, t=40, b=10)
                            )
                            
                            st.plotly_chart(reliability_fig, use_container_width=True)
                            
                            # Write reliability analysis
                            t1_reliable_batters = sum(1 for p in team1_data.get('players', []) if p.get('batting_rating', 0) > 50)
                            t1_reliable_bowlers = sum(1 for p in team1_data.get('players', []) if p.get('bowling_rating', 0) > 50)
                            t2_reliable_batters = sum(1 for p in team2_data.get('players', []) if p.get('batting_rating', 0) > 50)
                            t2_reliable_bowlers = sum(1 for p in team2_data.get('players', []) if p.get('bowling_rating', 0) > 50)
                            
                            st.markdown(f"""
                            - **{team1}**: {t1_reliable_batters} reliable batsmen, {t1_reliable_bowlers} reliable bowlers
                            - **{team2}**: {t2_reliable_batters} reliable batsmen, {t2_reliable_bowlers} reliable bowlers
                            
                            Teams with more consistent performers have more reliable predictions.
                            """)
                            
                        with col2:
                            # Central Limit Theorem explanation
                            st.markdown("""
                            #### Central Limit Theorem
                            
                            The Central Limit Theorem helps us understand variation in team performance:
                            """)
                            
                            # Apply CLT analysis
                            team1_batting_std = np.std([p.get('batting_rating', 0) for p in team1_data.get('players', []) if p.get('batting_rating', 0) > 0]) if len(team1_data.get('players', [])) > 5 else 15
                            team1_bowling_std = np.std([p.get('bowling_rating', 0) for p in team1_data.get('players', []) if p.get('bowling_rating', 0) > 0]) if len(team1_data.get('players', [])) > 5 else 15
                            team2_batting_std = np.std([p.get('batting_rating', 0) for p in team2_data.get('players', []) if p.get('batting_rating', 0) > 0]) if len(team2_data.get('players', [])) > 5 else 15
                            team2_bowling_std = np.std([p.get('bowling_rating', 0) for p in team2_data.get('players', []) if p.get('bowling_rating', 0) > 0]) if len(team2_data.get('players', [])) > 5 else 15
                            
                            # Create CLT comparison chart
                            clt_data = pd.DataFrame({
                                'Metric': ['Batting Variation', 'Bowling Variation'],
                                team1: [team1_batting_std, team1_bowling_std],
                                team2: [team2_batting_std, team2_bowling_std]
                            })
                            
                            st.dataframe(clt_data, hide_index=True)
                            
                            st.markdown("""
                            Lower variation means more consistent team performance. The Central Limit Theorem tells us 
                            that as more players contribute, team performance becomes more predictable.
                            """)
                            
                            # Bayes Theorem explanation
                            st.markdown("""
                            #### Bayesian Inference
                            
                            Bayes' Theorem allows us to update our initial probability estimates with evidence:
                            """)
                            
                            # Bayesian inference
                            bayes_data = match_prediction.get('bayesian_analysis', {})
                            prior = bayes_data.get('prior_probability', 0)
                            likelihood = bayes_data.get('likelihood_ratio', 0)
                            posterior = bayes_data.get('posterior_probability', 0)
                            
                            # Create Bayes diagram
                            bayes_fig = go.Figure()
                            
                            bayes_fig.add_trace(go.Bar(
                                x=['Prior Probability', 'Likelihood Ratio', 'Posterior Probability'],
                                y=[prior, likelihood, posterior],
                                marker_color=[team1_color, '#9370DB', '#2E8B57'],
                                text=[f"{prior}%", f"{likelihood}%", f"{posterior}%"],
                                textposition="auto"
                            ))
                            
                            bayes_fig.update_layout(
                                title=f"Bayesian Analysis for {team1}",
                                yaxis_title="Probability (%)",
                                height=300,
                                margin=dict(l=10, r=10, t=40, b=10)
                            )
                            
                            st.plotly_chart(bayes_fig, use_container_width=True)
                            
                            st.markdown(f"""
                            - **Prior Probability**: Initial estimate of {team1} winning ({prior}%)
                            - **Likelihood Ratio**: Evidence from batting/bowling matchups ({likelihood}%)
                            - **Posterior Probability**: Updated win probability after evidence ({posterior}%)
                            
                            Bayes' Theorem allows us to improve our prediction by incorporating evidence from team matchup analysis.
                            """)
                    
                    # -------------
                    # Mathematical Model Tab
                    # -------------
                    with prediction_analysis_tabs[2]:
                        st.markdown("""
                        ### The Mathematical Model
                        
                        Our cricket match prediction system combines three powerful mathematical concepts:
                        
                        #### 1. Bayes' Theorem
                        
                        Bayes' theorem calculates conditional probability using the formula:
                        
                        P(A|B) = [P(B|A) × P(A)] / P(B)
                        
                        Where:
                        - P(A|B) is the posterior probability (team wins given the evidence)
                        - P(B|A) is the likelihood (probability of evidence if team wins)
                        - P(A) is the prior probability (initial team strength assessment)
                        - P(B) is the evidence (matchup factors)
                        
                        In our model, we:
                        1. Start with prior probability based on team strengths
                        2. Calculate likelihood based on batting/bowling matchups
                        3. Update to posterior probability using Bayes' formula
                        
                        #### 2. Central Limit Theorem
                        
                        The Central Limit Theorem states that the distribution of sample means approaches a normal distribution as sample size increases. In cricket analysis, this helps us:
                        
                        1. Understand how player performance variation affects team outcomes
                        2. Create confidence intervals for team performance predictions
                        3. Account for the "averaging effect" of multiple players contributing
                        
                        Teams with lower standard deviation in player ratings have more predictable performances.
                        
                        #### 3. Law of Large Numbers
                        
                        The Law of Large Numbers states that as a sample size increases, its mean gets closer to the expected value. In cricket prediction, this means:
                        
                        1. Teams with more consistent performers have more reliable predictions
                        2. More matches provide better prediction data
                        3. The aggregated performance of multiple players is more stable than individual performances
                        
                        Our model weighs teams with more reliable performers higher in predictions.
                        
                        #### Combined Statistical Approach
                        
                        The final prediction combines these three principles:
                        
                        1. **Initial assessment** based on raw team strengths
                        2. **Bayesian update** based on matchup analysis
                        3. **Confidence adjustment** using Central Limit Theorem
                        4. **Reliability weighting** using Law of Large Numbers
                        
                        This multi-faceted mathematical approach produces predictions that account for team strength, 
                        matchup advantages, and the inherent variability in cricket performance.
                        """)
                        
                        # Key factors from the model
                        st.markdown("### Model Analysis Factors")
                        key_factors = match_prediction.get('key_factors', [])
                        
                        if key_factors:
                            for factor in key_factors:
                                st.markdown(f"- {factor}")
                        else:
                            st.info("No key factors available.")
                else:
                    st.warning("Unable to generate match prediction. Insufficient team data.")
            else:
                st.info("Please select two different teams for match prediction.")
        
        # Tab 4: Player Ratings
        with prediction_tabs[3]:
            st.subheader("Player Performance Ratings")
            
            # Generate player ratings
            player_ratings = generate_player_ratings(st.session_state.players_data)
            
            # Filter options
            col1, col2, col3 = st.columns(3)
            
            with col1:
                rating_team_filter = st.selectbox(
                    "Filter by Team",
                    ["All Teams"] + list(st.session_state.teams_data.get('teams', {}).keys()),
                    key="rating_team"
                )
            
            with col2:
                rating_role_filter = st.multiselect(
                    "Filter by Role",
                    options=["Batsman", "Bowler", "All-rounder", "Wicket-keeper Batsman"],
                    default=["Batsman", "Bowler", "All-rounder", "Wicket-keeper Batsman"],
                    key="rating_role"
                )
            
            with col3:
                rating_min_matches = st.slider(
                    "Minimum Matches Played",
                    0, 100, 5,
                    key="rating_matches"
                )
            
            # Prepare data for display
            if player_ratings:
                ratings_data = []
                
                for player_id, rating in player_ratings.items():
                    player = st.session_state.players_data.get(player_id, {})
                    
                    # Apply filters
                    if rating_team_filter != "All Teams" and player.get('team') != rating_team_filter:
                        continue
                        
                    if player.get('role') not in rating_role_filter:
                        continue
                        
                    if player.get('matches_played', 0) < rating_min_matches:
                        continue
                    
                    ratings_data.append({
                        "Player": player.get('name', 'Unknown'),
                        "Team": player.get('team', 'Unknown'),
                        "Role": player.get('role', 'Unknown'),
                        "Matches": player.get('matches_played', 0),
                        "Batting Rating": rating.get('batting_rating', 0),
                        "Bowling Rating": rating.get('bowling_rating', 0),
                        "Overall Rating": rating.get('overall_rating', 0)
                    })
                
                # Sort by overall rating
                ratings_data.sort(key=lambda x: x["Overall Rating"], reverse=True)
                
                # Display ratings table
                if ratings_data:
                    # Add rank column
                    for i, player in enumerate(ratings_data):
                        player["Rank"] = i + 1
                    
                    # Create dataframe for display
                    ratings_df = pd.DataFrame(ratings_data)
                    
                    # Reorder columns to show rank first
                    columns = ["Rank", "Player", "Team", "Role", "Matches", 
                               "Overall Rating", "Batting Rating", "Bowling Rating"]
                    
                    ratings_df = ratings_df[columns]
                    
                    st.dataframe(ratings_df, hide_index=True, use_container_width=True)
                    
                    # Visualize top players
                    st.subheader("Top 10 Players by Overall Rating")
                    
                    top_players = ratings_data[:10]
                    
                    import plotly.express as px
                    
                    fig = px.bar(
                        top_players,
                        x="Player",
                        y="Overall Rating",
                        color="Team",
                        hover_data=["Role", "Batting Rating", "Bowling Rating"],
                        color_discrete_sequence=px.colors.qualitative.Bold
                    )
                    
                    fig.update_layout(
                        xaxis_tickangle=-45,
                        height=500
                    )
                    
                    st.plotly_chart(fig, use_container_width=True)
                    
                    # Show rating distribution by role
                    st.subheader("Rating Distribution by Role")
                    
                    role_ratings = []
                    for player in ratings_data:
                        role_ratings.append({
                            "Role": player["Role"],
                            "Rating Type": "Batting",
                            "Rating": player["Batting Rating"]
                        })
                        role_ratings.append({
                            "Role": player["Role"],
                            "Rating Type": "Bowling",
                            "Rating": player["Bowling Rating"]
                        })
                    
                    role_fig = px.box(
                        role_ratings,
                        x="Role",
                        y="Rating",
                        color="Rating Type",
                        color_discrete_sequence=["#3366cc", "#cc3366"],
                        points="all"
                    )
                    
                    role_fig.update_layout(
                        height=500,
                        xaxis_title="",
                        yaxis_title="Rating (0-100)"
                    )
                    
                    st.plotly_chart(role_fig, use_container_width=True)
                    
                    # Team-wise player rating analysis
                    if rating_team_filter != "All Teams":
                        st.subheader(f"{rating_team_filter} Player Ratings")
                        
                        team_color = st.session_state.teams_data['teams'].get(rating_team_filter, {}).get('color', '#3366cc')
                        
                        # Create radar chart for team's top players
                        team_players = [p for p in ratings_data if p["Team"] == rating_team_filter]
                        team_players.sort(key=lambda x: x["Overall Rating"], reverse=True)
                        top_team_players = team_players[:5]
                        
                        if top_team_players:
                            import plotly.graph_objects as go
                            
                            categories = ['Batting', 'Bowling', 'Overall']
                            
                            fig = go.Figure()
                            
                            for player in top_team_players:
                                fig.add_trace(go.Scatterpolar(
                                    r=[player["Batting Rating"], player["Bowling Rating"], player["Overall Rating"]],
                                    theta=categories,
                                    fill='toself',
                                    name=player["Player"]
                                ))
                            
                            fig.update_layout(
                                polar=dict(
                                    radialaxis=dict(
                                        visible=True,
                                        range=[0, 100]
                                    )),
                                showlegend=True,
                                title=f"Top {len(top_team_players)} Players in {rating_team_filter}"
                            )
                            
                            st.plotly_chart(fig, use_container_width=True)
                else:
                    st.info("No players match the selected filters.")
            else:
                st.warning("Unable to generate player ratings. Insufficient player data.")
    else:
        st.info("No data loaded. Please use the 'Data Refresh' tab to fetch the latest IPL player stats.")

# Data Refresh Tab
with tabs[6]:
    st.header("Prediction Validation")
    
    if st.session_state.data_loaded:
        st.markdown("""
        Use this tab to validate match predictions by recording the actual match winners. 
        This will help improve our prediction algorithm over time.
        """)
        
        # Get team names for dropdowns
        team_names = list(st.session_state.teams_data.get('teams', {}).keys())
        
        st.subheader("Match Prediction History")
        
        # Get prediction history
        predictions = get_match_predictions(limit=50)
        
        if predictions:
            # Create dataframe for display
            prediction_data = []
            for p in predictions:
                # Format match date
                match_date = p.get('match_date', 'Unknown date')
                if match_date:
                    try:
                        if isinstance(match_date, str):
                            # Show only the date part
                            match_date = match_date.split('T')[0]
                    except:
                        pass
                
                # Format probability as percentage
                win_prob = p.get('win_probability', 0) * 100
                
                # Create status indicator
                status = "Pending"
                status_color = "gray"
                if p.get('actual_winner'):
                    if p.get('was_correct'):
                        status = "✓ Correct"
                        status_color = "green"
                    else:
                        status = "✗ Incorrect"
                        status_color = "red"
                
                prediction_data.append({
                    'Match ID': p.get('match_id', ''),
                    'Date': match_date,
                    'Teams': f"{p.get('team1', '')} vs {p.get('team2', '')}",
                    'Predicted Winner': p.get('predicted_winner', ''),
                    'Win Probability': f"{win_prob:.1f}%",
                    'Actual Winner': p.get('actual_winner', ''),
                    'Status': status,
                    'Status Color': status_color
                })
            
            # Create dataframe
            df = pd.DataFrame(prediction_data)
            
            # Custom styling for status column
            def highlight_status(val):
                color_map = {
                    "✓ Correct": "background-color: rgba(0, 255, 0, 0.2)",
                    "✗ Incorrect": "background-color: rgba(255, 0, 0, 0.2)",
                    "Pending": "background-color: rgba(200, 200, 200, 0.2)"
                }
                return color_map.get(val, "")
            
            # Apply styling
            styled_df = df.style.map(highlight_status, subset=['Status'])
            st.dataframe(styled_df, hide_index=True)
            
            # Accuracy metrics
            accuracy_data = get_prediction_accuracy()
            if accuracy_data and accuracy_data.get('total_matches', 0) > 0:
                st.subheader("Prediction Accuracy")
                
                # Create metrics columns
                col1, col2, col3 = st.columns(3)
                
                with col1:
                    st.metric("Total Matches Validated", accuracy_data.get('total_matches', 0))
                
                with col2:
                    st.metric("Correct Predictions", accuracy_data.get('correct_predictions', 0))
                
                with col3:
                    accuracy_pct = accuracy_data.get('accuracy_percentage', 0)
                    st.metric("Prediction Accuracy", f"{accuracy_pct:.1f}%")
                
                # Team-specific accuracy
                st.subheader("Team-specific Prediction Accuracy")
                
                team_accuracy = accuracy_data.get('team_accuracy', {})
                if team_accuracy:
                    team_acc_data = []
                    for team, acc in team_accuracy.items():
                        team_acc_data.append({
                            'Team': team,
                            'Total Predictions': acc.get('total_predictions', 0),
                            'Correct Predictions': acc.get('correct_predictions', 0),
                            'Accuracy': f"{acc.get('accuracy_percentage', 0):.1f}%"
                        })
                    
                    team_acc_df = pd.DataFrame(team_acc_data)
                    st.dataframe(team_acc_df, hide_index=True)
        else:
            st.info("No match predictions found. Make predictions in the Performance Prediction tab first.")
        
        # Add form to record actual match results
        st.subheader("Record Match Result")
        
        # Get pending predictions
        pending_predictions = [p for p in predictions if not p.get('actual_winner')]
        
        if pending_predictions:
            # Create a selection for pending predictions
            pending_options = [f"{p.get('team1', '')} vs {p.get('team2', '')} ({p.get('match_id', '')})" for p in pending_predictions]
            selected_prediction = st.selectbox("Select Match", pending_options, key="prediction_select")
            
            # Get the selected prediction
            selected_index = pending_options.index(selected_prediction)
            prediction = pending_predictions[selected_index]
            
            # Show match details
            col1, col2, col3 = st.columns(3)
            with col1:
                st.write(f"**Team 1:** {prediction.get('team1', '')}")
            with col2:
                st.write(f"**Team 2:** {prediction.get('team2', '')}")
            with col3:
                st.write(f"**Predicted Winner:** {prediction.get('predicted_winner', '')}")
            
            # Select actual winner
            actual_winner = st.radio(
                "Select Actual Winner",
                [prediction.get('team1', ''), prediction.get('team2', '')]
            )
            
            if st.button("Record Result"):
                # Update prediction with actual winner
                try:
                    save_match_prediction({
                        'match_id': prediction.get('match_id', ''),
                        'actual_winner': actual_winner
                    })
                    st.success(f"Recorded match result: {actual_winner} won the match.")
                    st.info("Refresh the page to see updated statistics.")
                except Exception as e:
                    st.error(f"Error saving result: {str(e)}")
        else:
            st.info("No pending match predictions to record results for.")
        
        # Allow manual creation of match predictions
        with st.expander("Create New Match Prediction"):
            st.markdown("Add a new match prediction manually")
            
            # Match details
            col1, col2 = st.columns(2)
            with col1:
                team1 = st.selectbox("Team 1", team_names, key="team1_select")
            with col2:
                team2 = st.selectbox("Team 2", team_names, key="team2_select")
            
            # Prediction details
            col1, col2 = st.columns(2)
            with col1:
                predicted_winner = st.selectbox("Predicted Winner", [team1, team2], key="winner_select")
            with col2:
                win_probability = st.slider("Win Probability (%)", 50, 100, 70) / 100
            
            # Optional venue
            venue = st.text_input("Venue (optional)")
            
            # Match date
            match_date = st.date_input("Match Date")
            
            if st.button("Save Prediction"):
                if team1 == team2:
                    st.error("Team 1 and Team 2 cannot be the same.")
                else:
                    try:
                        # Create prediction
                        match_data = {
                            'team1': team1,
                            'team2': team2,
                            'predicted_winner': predicted_winner,
                            'win_probability': win_probability,
                            'venue': venue if venue else None,
                            'match_date': match_date.isoformat() if match_date else None
                        }
                        
                        save_match_prediction(match_data)
                        st.success("Match prediction saved successfully!")
                        st.info("Refresh the page to see the new prediction in the history.")
                    except Exception as e:
                        st.error(f"Error saving prediction: {str(e)}")
    else:
        st.info("No data loaded. Please use the 'Data Refresh' tab to fetch data first.")

with tabs[7]:
    st.header("Data Refresh")
    
    # Display last refresh time if available
    if st.session_state.last_refresh:
        st.info(f"Last data refresh: {st.session_state.last_refresh}")
    
    # Data refresh options
    refresh_type = st.radio(
        "Select Refresh Type",
        ["Full Refresh (Teams & Players)", "Update Player Stats Only"]
    )
    
    if st.button("Refresh Data"):
        with st.spinner("Fetching data... This might take a few minutes."):
            try:
                # Determine what to refresh
                refresh_teams = refresh_type == "Full Refresh (Teams & Players)"
                
                if refresh_teams:
                    # Get teams data first
                    st.info("Starting to scrape teams data...")
                    try:
                        st.session_state.teams_data = scrape_ipl_teams()
                        st.info(f"Teams data scraped: {len(st.session_state.teams_data.get('teams', {}))} teams found")
                        if not st.session_state.teams_data:
                            st.error("Failed to fetch teams data. Please try again.")
                            st.stop()
                    except Exception as e:
                        st.error(f"Error scraping teams: {str(e)}")
                        st.stop()
                
                # If we have teams data, either from this refresh or previous
                if 'teams_data' in st.session_state and st.session_state.teams_data:
                    # Get player stats
                    team_names = list(st.session_state.teams_data.get('teams', {}).keys())
                    progress_bar = st.progress(0)
                    
                    all_players = {}
                    for i, team in enumerate(team_names):
                        st.write(f"Fetching data for: {team}")
                        try:
                            team_players = scrape_player_stats(team)
                            st.info(f"Found {len(team_players)} players for {team}")
                            
                            # Process each player's data
                            for player_id, player_data in team_players.items():
                                try:
                                    processed_data = process_player_data(player_data, team)
                                    all_players[player_id] = processed_data
                                except Exception as e:
                                    st.warning(f"Error processing player {player_id}: {str(e)}")
                        except Exception as e:
                            st.warning(f"Error scraping players for {team}: {str(e)}")
                        
                        # Update progress
                        progress_bar.progress((i + 1) / len(team_names))
                    
                    # Set the data in session state
                    st.session_state.players_data = all_players
                    st.session_state.data_loaded = True
                    
                    # Update last refresh time
                    current_time = time.strftime("%Y-%m-%d %H:%M:%S")
                    st.session_state.last_refresh = current_time
                    st.session_state.teams_data['last_refresh'] = current_time
                    
                    # Save data to file
                    save_data(st.session_state.players_data, st.session_state.teams_data)
                    
                    st.success("Data refresh completed successfully!")
            except Exception as e:
                st.error(f"An error occurred during the data refresh: {str(e)}")
    
    # Show data metrics if data is available
    if st.session_state.data_loaded:
        st.subheader("Current Data Metrics")
        
        col1, col2, col3 = st.columns(3)
        with col1:
            st.metric("Teams", len(st.session_state.teams_data.get('teams', {})))
        with col2:
            st.metric("Players", len(st.session_state.players_data))
        with col3:
            batting_data = [p.get('batting_stats', {}).get('runs', 0) for p in st.session_state.players_data.values() 
                          if isinstance(p.get('batting_stats', {}).get('runs', 0), (int, float))]
            total_runs = sum(batting_data) if batting_data else 0
            st.metric("Total Runs", f"{total_runs:,}")

# Footer
st.markdown("---")
st.markdown("### About")
st.markdown("""
This dashboard scrapes data from reliable cricket statistics sources to provide comprehensive
information about IPL cricket players and teams. The data includes batting statistics (runs, 
boundaries, strike rate), bowling statistics (wickets, economy), and overall performance metrics.

**Note:** This application performs web scraping of publicly available information. All data is 
refreshed on demand and may not reflect real-time statistics.
""")

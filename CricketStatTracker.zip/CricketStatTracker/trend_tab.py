with tabs[3]:
    st.header("Trend Analysis")
    
    # Import the trend analysis module
    from trend_analysis import (
        analyze_team_trends, analyze_player_career_progression, 
        compare_seasons, identify_performance_patterns,
        generate_mock_seasonal_data, generate_mock_player_seasonal_data
    )
    
    # Import database functions for seasonal stats
    from database import get_team_seasonal_stats, get_player_seasonal_stats, get_all_seasons
    
    if st.session_state.data_loaded:
        # Create tabs for different trend analysis views
        trend_analysis_tabs = st.tabs([
            "Player Career Progression", 
            "Team Performance Trends", 
            "Season Comparison", 
            "Performance Patterns"
        ])
        
        # Tab 1: Player Career Progression Analysis
        with trend_analysis_tabs[0]:
            st.subheader("Player Career Progression")
            
            # Explanation about the player trend data
            st.info("""
            Analyze how a player's performance has evolved across IPL seasons.
            Track their batting and bowling statistics, career milestones, and team changes over time.
            """)
            
            # Player selection
            players_list = [(p.get("name", "Unknown"), p.get("id")) 
                            for p in st.session_state.players_data.values() 
                            if p.get("matches_played", 0) >= 10]  # Players with sufficient matches
            
            players_list.sort(key=lambda x: x[0])  # Sort by name
            
            if players_list:
                # Player selection
                selected_player_id = st.selectbox(
                    "Select Player",
                    options=[p[1] for p in players_list],
                    format_func=lambda x: next((p[0] for p in players_list if p[1] == x), x),
                    key="career_player_select"
                )
                
                selected_player = st.session_state.players_data.get(selected_player_id)
                
                if selected_player:
                    # For demonstration, we'll generate mock seasonal data
                    # In a production app, this would come from the database
                    player_name = selected_player.get('name', 'Unknown')
                    player_role = selected_player.get('role', 'Unknown')
                    team_name = selected_player.get('team', 'Unknown')
                    
                    # Check for actual seasonal data in the database
                    db_player_stats = get_player_seasonal_stats(player_id=selected_player_id)
                    
                    # If no data in database, generate mock data for demo
                    if not db_player_stats:
                        st.warning("""
                        Historical seasonal data is not available in the database. 
                        Using simulated data for demonstration purposes.
                        """)
                        
                        # Generate mock data based on existing player stats
                        matches_played = selected_player.get("matches_played", 0)
                        num_seasons = min(8, max(3, matches_played // 7))  # Rough estimation of seasons played
                        start_year = 2023 - num_seasons
                        
                        # Get player teams for mock data
                        teams = [team_name]
                        # Add a team change if it's a veteran player
                        if matches_played > 50 and selected_player_id.endswith('7'):
                            teams = ["Mumbai Indians", team_name] if team_name != "Mumbai Indians" else ["Chennai Super Kings", team_name]
                        
                        player_seasonal_stats = generate_mock_player_seasonal_data(
                            player_name=player_name,
                            player_id=selected_player_id,
                            role=player_role,
                            teams=teams,
                            start_year=start_year,
                            end_year=2023
                        )
                    else:
                        player_seasonal_stats = db_player_stats
                    
                    # Analyze player career progression
                    career_analysis = analyze_player_career_progression(player_seasonal_stats)
                    
                    if career_analysis["status"] == "success":
                        st.subheader(f"{player_name}'s Career Progression ({career_analysis['role']})")
                        
                        # Show seasons analyzed
                        seasons_text = ", ".join(str(season) for season in career_analysis["seasons_analyzed"])
                        st.markdown(f"**Seasons analyzed**: {seasons_text}")
                        
                        # Create tabs for different aspects of career analysis
                        career_tabs = st.tabs(["Batting Stats", "Bowling Stats", "Milestones & Changes"])
                        
                        # Batting stats tab
                        with career_tabs[0]:
                            if career_analysis["batting_progression"]:
                                # Convert data to DataFrames for plotting
                                import pandas as pd
                                import plotly.express as px
                                
                                # Create a DataFrame from batting progression
                                runs_data = []
                                for i, season in enumerate(career_analysis["seasons_analyzed"]):
                                    runs_data.append({
                                        "Season": season,
                                        "Runs": career_analysis["batting_progression"]["runs"][i] if i < len(career_analysis["batting_progression"]["runs"]) else 0,
                                        "Average": career_analysis["batting_progression"]["average"][i] if i < len(career_analysis["batting_progression"]["average"]) else 0,
                                        "Strike Rate": career_analysis["batting_progression"]["strike_rate"][i] if i < len(career_analysis["batting_progression"]["strike_rate"]) else 0
                                    })
                                
                                batting_df = pd.DataFrame(runs_data)
                                
                                # Runs by season
                                st.subheader("Runs by Season")
                                runs_fig = px.bar(
                                    batting_df,
                                    x="Season",
                                    y="Runs",
                                    title=f"{player_name}'s Run Scoring by Season",
                                    text="Runs",
                                    color="Average",
                                    color_continuous_scale="RdYlGn",
                                    height=400
                                )
                                
                                # Add strike rate line
                                runs_fig.add_scatter(
                                    x=batting_df["Season"],
                                    y=batting_df["Strike Rate"],
                                    mode="lines+markers",
                                    name="Strike Rate",
                                    line=dict(color="red", width=2),
                                    yaxis="y2"
                                )
                                
                                runs_fig.update_layout(
                                    yaxis2=dict(
                                        title="Strike Rate",
                                        overlaying="y",
                                        side="right",
                                        range=[0, max(batting_df["Strike Rate"]) * 1.2 if len(batting_df) > 0 and max(batting_df["Strike Rate"]) > 0 else 200]
                                    )
                                )
                                
                                st.plotly_chart(runs_fig, use_container_width=True)
                                
                                # Boundary hitting
                                if "fours" in career_analysis["batting_progression"] and "sixes" in career_analysis["batting_progression"]:
                                    st.subheader("Boundary Hitting")
                                    
                                    # Prepare boundary data
                                    boundary_data = []
                                    for i, season in enumerate(career_analysis["seasons_analyzed"]):
                                        if i < len(career_analysis["batting_progression"]["fours"]):
                                            boundary_data.append({
                                                "Season": season,
                                                "Type": "Fours",
                                                "Count": career_analysis["batting_progression"]["fours"][i]
                                            })
                                        if i < len(career_analysis["batting_progression"]["sixes"]):
                                            boundary_data.append({
                                                "Season": season,
                                                "Type": "Sixes",
                                                "Count": career_analysis["batting_progression"]["sixes"][i]
                                            })
                                    
                                    boundary_df = pd.DataFrame(boundary_data)
                                    
                                    if not boundary_df.empty:
                                        boundary_fig = px.bar(
                                            boundary_df,
                                            x="Season",
                                            y="Count",
                                            color="Type",
                                            barmode="group",
                                            title=f"{player_name}'s Boundary Hitting",
                                            color_discrete_map={"Fours": "#3366cc", "Sixes": "#dc3912"}
                                        )
                                        
                                        st.plotly_chart(boundary_fig, use_container_width=True)
                                
                                # Batting average progression
                                st.subheader("Batting Average Progression")
                                avg_fig = px.line(
                                    batting_df,
                                    x="Season",
                                    y="Average",
                                    title=f"{player_name}'s Batting Average Progression",
                                    markers=True,
                                    height=400
                                )
                                
                                # Add a trendline
                                avg_fig.add_traces(
                                    px.scatter(batting_df, x="Season", y="Average", trendline="ols").data[1]
                                )
                                
                                st.plotly_chart(avg_fig, use_container_width=True)
                            else:
                                st.info(f"{player_name} does not have significant batting statistics.")
                        
                        # Bowling stats tab
                        with career_tabs[1]:
                            if career_analysis["bowling_progression"]:
                                # Convert data to DataFrames for plotting
                                import pandas as pd
                                import plotly.express as px
                                
                                # Create a DataFrame from bowling progression
                                wickets_data = []
                                for i, season in enumerate(career_analysis["seasons_analyzed"]):
                                    if i < len(career_analysis["bowling_progression"]["wickets"]):
                                        wickets_data.append({
                                            "Season": season,
                                            "Wickets": career_analysis["bowling_progression"]["wickets"][i],
                                            "Economy": career_analysis["bowling_progression"]["economy"][i] if "economy" in career_analysis["bowling_progression"] else 0,
                                            "Average": career_analysis["bowling_progression"]["average"][i] if "average" in career_analysis["bowling_progression"] else 0
                                        })
                                
                                bowling_df = pd.DataFrame(wickets_data)
                                
                                if not bowling_df.empty:
                                    # Wickets by season
                                    st.subheader("Wickets by Season")
                                    wickets_fig = px.bar(
                                        bowling_df,
                                        x="Season",
                                        y="Wickets",
                                        title=f"{player_name}'s Wicket Taking by Season",
                                        text="Wickets",
                                        color="Economy",
                                        color_continuous_scale="RdYlGn_r", # Reversed so green is low economy
                                        height=400
                                    )
                                    
                                    # Add economy line
                                    wickets_fig.add_scatter(
                                        x=bowling_df["Season"],
                                        y=bowling_df["Economy"],
                                        mode="lines+markers",
                                        name="Economy",
                                        line=dict(color="red", width=2),
                                        yaxis="y2"
                                    )
                                    
                                    wickets_fig.update_layout(
                                        yaxis2=dict(
                                            title="Economy Rate",
                                            overlaying="y",
                                            side="right",
                                            range=[0, max(bowling_df["Economy"]) * 1.2 if max(bowling_df["Economy"]) > 0 else 12]
                                        )
                                    )
                                    
                                    st.plotly_chart(wickets_fig, use_container_width=True)
                                    
                                    # Bowling average progression
                                    if "average" in career_analysis["bowling_progression"]:
                                        st.subheader("Bowling Average Progression")
                                        avg_fig = px.line(
                                            bowling_df,
                                            x="Season",
                                            y="Average",
                                            title=f"{player_name}'s Bowling Average Progression",
                                            markers=True,
                                            height=400
                                        )
                                        
                                        # Add a trendline
                                        avg_fig.add_traces(
                                            px.scatter(bowling_df, x="Season", y="Average", trendline="ols").data[1]
                                        )
                                        
                                        st.plotly_chart(avg_fig, use_container_width=True)
                            else:
                                st.info(f"{player_name} does not have significant bowling statistics.")
                        
                        # Milestones tab
                        with career_tabs[2]:
                            # Display milestones
                            if career_analysis["performance_milestones"]:
                                st.subheader("Career Milestones")
                                
                                milestones_df = pd.DataFrame(career_analysis["performance_milestones"])
                                
                                if not milestones_df.empty:
                                    # Sort by season
                                    milestones_df = milestones_df.sort_values("season")
                                    
                                    # Create a formatted display
                                    for _, milestone in milestones_df.iterrows():
                                        milestone_color = "🔴" if milestone["type"] == "batting" else "🔵" if milestone["type"] == "bowling" else "🏆"
                                        st.markdown(f"**{milestone['season']}**: {milestone_color} {milestone['description']}")
                            else:
                                st.info("No significant milestones found in the analyzed seasons.")
                            
                            # Display team changes
                            if career_analysis["team_changes"]:
                                st.subheader("Team Changes")
                                
                                for change in career_analysis["team_changes"]:
                                    st.markdown(f"**{change['season']}**: Moved from {change['from_team']} to {change['to_team']}")
                            else:
                                st.info(f"{player_name} has remained with {team_name} throughout the analyzed seasons.")
                    else:
                        st.error(career_analysis["message"])
                else:
                    st.error("Error retrieving player data.")
            else:
                st.info("No players with sufficient matches found for trend analysis.")
        
        # Tab 2: Team Performance Trends
        with trend_analysis_tabs[1]:
            st.subheader("Team Performance Trends")
            
            st.info("""
            Analyze how teams have performed across different IPL seasons.
            Track win rates, points, batting and bowling metrics, and identify correlations between performance indicators.
            """)
            
            # Team selection
            teams_list = list(st.session_state.teams_data.get('teams', {}).keys())
            teams_list.sort()
            
            if teams_list:
                # Add option for all teams
                team_options = ["All Teams"] + teams_list
                
                selected_team = st.selectbox(
                    "Select Team",
                    options=team_options,
                    key="trend_team_select"
                )
                
                # Filter team if specified
                team_filter = None if selected_team == "All Teams" else selected_team
                
                # Fetch team seasonal stats from database
                db_team_stats = get_team_seasonal_stats(team_name=team_filter)
                
                # If no data in database, generate mock data for demo
                if not db_team_stats:
                    st.warning("""
                    Historical seasonal data is not available in the database. 
                    Using simulated data for demonstration purposes.
                    """)
                    
                    # Generate mock seasonal data for demonstration
                    db_team_stats = generate_mock_seasonal_data(
                        teams=teams_list,
                        start_year=2016,
                        end_year=2023
                    )
                    
                    # Filter if team was selected
                    if team_filter:
                        db_team_stats = [s for s in db_team_stats if s.get('team_name') == team_filter]
                
                # Analyze team trends
                trend_analysis = analyze_team_trends(db_team_stats, team_name=team_filter)
                
                if trend_analysis["status"] == "success":
                    st.subheader(f"{trend_analysis['team_name']} Performance Analysis")
                    
                    # Show seasons analyzed
                    seasons_text = ", ".join(str(season) for season in trend_analysis["seasons_analyzed"])
                    st.markdown(f"**Seasons analyzed**: {seasons_text}")
                    
                    # Create tabs for different aspects of trend analysis
                    team_trend_tabs = st.tabs([
                        "Performance Metrics", 
                        "Statistical Analysis", 
                        "Correlation Analysis"
                    ])
                    
                    # Performance Metrics Tab
                    with team_trend_tabs[0]:
                        if trend_analysis["performance_trends"]:
                            import pandas as pd
                            import plotly.express as px
                            import plotly.graph_objects as go
                            
                            # Create dataframe for performance trends
                            perf_data = []
                            for i, season in enumerate(trend_analysis["seasons_analyzed"]):
                                perf_data.append({
                                    "Season": season,
                                    "Win Rate (%)": trend_analysis["performance_trends"]["win_rate"][i] if i < len(trend_analysis["performance_trends"]["win_rate"]) else 0,
                                    "Win-Loss Ratio": trend_analysis["performance_trends"]["win_loss_ratio"][i] if i < len(trend_analysis["performance_trends"]["win_loss_ratio"]) else 0,
                                    "Points": trend_analysis["performance_trends"]["points"][i] if i < len(trend_analysis["performance_trends"]["points"]) else 0,
                                    "Batting Avg": trend_analysis["performance_trends"]["batting_avg"][i] if i < len(trend_analysis["performance_trends"]["batting_avg"]) else 0,
                                    "Batting SR": trend_analysis["performance_trends"]["batting_strike_rate"][i] if i < len(trend_analysis["performance_trends"]["batting_strike_rate"]) else 0,
                                    "Bowling Avg": trend_analysis["performance_trends"]["bowling_avg"][i] if i < len(trend_analysis["performance_trends"]["bowling_avg"]) else 0,
                                    "Bowling Economy": trend_analysis["performance_trends"]["bowling_economy"][i] if i < len(trend_analysis["performance_trends"]["bowling_economy"]) else 0,
                                    "Net Run Rate": trend_analysis["performance_trends"]["net_run_rate"][i] if i < len(trend_analysis["performance_trends"]["net_run_rate"]) else 0
                                })
                            
                            perf_df = pd.DataFrame(perf_data)
                            
                            # Win Rate Chart
                            st.subheader("Win Rate Trend")
                            win_fig = px.line(
                                perf_df,
                                x="Season",
                                y="Win Rate (%)",
                                title=f"{trend_analysis['team_name']} Win Rate Across Seasons",
                                markers=True,
                                height=400
                            )
                            
                            # Add points as bar
                            win_fig.add_bar(
                                x=perf_df["Season"],
                                y=perf_df["Points"],
                                name="Points",
                                yaxis="y2"
                            )
                            
                            win_fig.update_layout(
                                yaxis=dict(title="Win Rate (%)"),
                                yaxis2=dict(
                                    title="Points",
                                    overlaying="y",
                                    side="right",
                                    range=[0, max(perf_df["Points"]) * 1.2 if not perf_df.empty and max(perf_df["Points"]) > 0 else 30]
                                ),
                                legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1)
                            )
                            
                            st.plotly_chart(win_fig, use_container_width=True)
                            
                            # Batting Performance Chart
                            st.subheader("Batting Performance Trend")
                            bat_fig = px.line(
                                perf_df,
                                x="Season",
                                y=["Batting Avg", "Batting SR"],
                                title=f"{trend_analysis['team_name']} Batting Performance",
                                markers=True,
                                height=400
                            )
                            
                            st.plotly_chart(bat_fig, use_container_width=True)
                            
                            # Bowling Performance Chart
                            st.subheader("Bowling Performance Trend")
                            bowl_fig = px.line(
                                perf_df,
                                x="Season",
                                y=["Bowling Avg", "Bowling Economy"],
                                title=f"{trend_analysis['team_name']} Bowling Performance",
                                markers=True,
                                height=400
                            )
                            
                            st.plotly_chart(bowl_fig, use_container_width=True)
                            
                            # Net Run Rate Chart
                            st.subheader("Net Run Rate Trend")
                            nrr_fig = px.line(
                                perf_df,
                                x="Season",
                                y="Net Run Rate",
                                title=f"{trend_analysis['team_name']} Net Run Rate",
                                markers=True,
                                height=400
                            )
                            
                            # Add a zero line for reference
                            nrr_fig.add_hline(
                                y=0,
                                line_dash="dash",
                                line_color="gray",
                                annotation_text="Zero Line",
                                annotation_position="bottom right"
                            )
                            
                            st.plotly_chart(nrr_fig, use_container_width=True)
                        else:
                            st.error("No performance trends data available.")
                    
                    # Statistical Analysis Tab
                    with team_trend_tabs[1]:
                        if trend_analysis["statistical_analysis"]:
                            import pandas as pd
                            
                            # Create table of statistical measures
                            stat_data = []
                            for metric, stats in trend_analysis["statistical_analysis"].items():
                                stat_data.append({
                                    "Metric": metric.replace('_', ' ').title(),
                                    "Mean": round(stats["mean"], 2),
                                    "Median": round(stats["median"], 2),
                                    "Std Dev": round(stats["std_dev"], 2),
                                    "Min": round(stats["min"], 2),
                                    "Max": round(stats["max"], 2),
                                    "Trend": stats["trend_direction"]
                                })
                            
                            stat_df = pd.DataFrame(stat_data)
                            
                            st.subheader("Statistical Summary")
                            st.dataframe(stat_df, hide_index=True, use_container_width=True)
                            
                            # Create visual representation of trends
                            st.subheader("Key Metrics Distribution")
                            
                            import plotly.graph_objects as go
                            
                            # Create box plots for key metrics
                            metrics_to_plot = ["Wins", "Points", "Batting Avg", "Bowling Avg", "Net Run Rate"]
                            
                            # Extract data for box plots
                            box_data = []
                            for metric in metrics_to_plot:
                                metric_lower = metric.lower().replace(' ', '_')
                                if metric_lower in trend_analysis["performance_trends"]:
                                    for value in trend_analysis["performance_trends"][metric_lower]:
                                        box_data.append({
                                            "Metric": metric,
                                            "Value": value
                                        })
                            
                            box_df = pd.DataFrame(box_data)
                            
                            if not box_df.empty:
                                box_fig = px.box(
                                    box_df,
                                    x="Metric",
                                    y="Value",
                                    title=f"{trend_analysis['team_name']} Metrics Distribution",
                                    color="Metric",
                                    height=500
                                )
                                
                                st.plotly_chart(box_fig, use_container_width=True)
                        else:
                            st.error("No statistical analysis data available.")
                    
                    # Correlation Analysis Tab
                    with team_trend_tabs[2]:
                        if trend_analysis["correlation_analysis"]:
                            correlations = trend_analysis["correlation_analysis"].get("correlations", [])
                            
                            if correlations:
                                import pandas as pd
                                
                                # Create table of correlations
                                corr_data = []
                                for corr in correlations:
                                    corr_data.append({
                                        "Metric 1": corr["metric1"].replace('_', ' ').title(),
                                        "Metric 2": corr["metric2"].replace('_', ' ').title(),
                                        "Correlation": round(corr["correlation"], 2),
                                        "Strength": corr["strength"].title()
                                    })
                                
                                corr_df = pd.DataFrame(corr_data)
                                
                                st.subheader("Correlations Between Metrics")
                                st.dataframe(corr_df, hide_index=True, use_container_width=True)
                                
                                # Display key insights
                                insights = trend_analysis["correlation_analysis"].get("insights", [])
                                if insights:
                                    st.subheader("Key Insights")
                                    for insight in insights:
                                        st.markdown(f"- {insight}")
                                
                                # Create correlation matrix visualization
                                st.subheader("Correlation Matrix")
                                
                                # Create a correlation matrix
                                metrics = list(set([row["Metric 1"] for row in corr_data] + [row["Metric 2"] for row in corr_data]))
                                
                                # Initialize matrix with zeros
                                corr_matrix = pd.DataFrame(0, index=metrics, columns=metrics)
                                
                                # Fill in correlations
                                for _, row in corr_df.iterrows():
                                    corr_matrix.loc[row["Metric 1"], row["Metric 2"]] = row["Correlation"]
                                    corr_matrix.loc[row["Metric 2"], row["Metric 1"]] = row["Correlation"]
                                
                                # Set diagonal to 1
                                for metric in metrics:
                                    corr_matrix.loc[metric, metric] = 1.0
                                
                                import plotly.graph_objects as go
                                
                                fig = go.Figure(data=go.Heatmap(
                                    z=corr_matrix.values,
                                    x=corr_matrix.columns,
                                    y=corr_matrix.index,
                                    colorscale='RdBu_r',
                                    zmin=-1,
                                    zmax=1,
                                    text=corr_matrix.round(2).values,
                                    texttemplate="%{text}",
                                    textfont={"size":10}
                                ))
                                
                                fig.update_layout(
                                    title=f"Correlation Matrix for {trend_analysis['team_name']}",
                                    height=600,
                                    xaxis=dict(tickangle=-45)
                                )
                                
                                st.plotly_chart(fig, use_container_width=True)
                            else:
                                st.info("No significant correlations found in the data.")
                        else:
                            st.error("No correlation analysis data available.")
                else:
                    st.error(trend_analysis["message"])
            else:
                st.info("No team data available for trend analysis.")
        
        # Tab 3: Season Comparison
        with trend_analysis_tabs[2]:
            st.subheader("Season Comparison")
            
            st.info("""
            Compare performance metrics between two IPL seasons.
            Analyze team performance changes, overall tournament statistics, and identify performance improvements or declines.
            """)
            
            # Get seasons from database or generate demo seasons
            db_seasons = get_all_seasons()
            
            if not db_seasons:
                # Generate demo seasons
                db_seasons = list(range(2016, 2024))
                
                st.warning("""
                Historical seasonal data is not available in the database. 
                Using simulated data for demonstration purposes.
                """)
            
            # Sort in descending order for easier selection
            seasons = sorted(db_seasons, reverse=True)
            
            if len(seasons) >= 2:
                # Season selection
                col1, col2 = st.columns(2)
                
                with col1:
                    season1 = st.selectbox(
                        "Select First Season",
                        options=seasons,
                        index=min(1, len(seasons)-1),
                        key="compare_season1"
                    )
                
                with col2:
                    # Filter out first season to prevent same selection
                    season2_options = [s for s in seasons if s != season1]
                    season2 = st.selectbox(
                        "Select Second Season",
                        options=season2_options,
                        index=0,
                        key="compare_season2"
                    )
                
                # Add button to trigger comparison
                if st.button("Compare Seasons", key="compare_seasons_btn"):
                    # Get seasonal stats
                    all_seasonal_stats = get_team_seasonal_stats()
                    
                    # If no data in database, generate mock data
                    if not all_seasonal_stats:
                        # Generate mock seasonal data for demonstration
                        teams_list = list(st.session_state.teams_data.get('teams', {}).keys())
                        all_seasonal_stats = generate_mock_seasonal_data(
                            teams=teams_list,
                            start_year=min(seasons),
                            end_year=max(seasons)
                        )
                    
                    # Compare seasons
                    comparison = compare_seasons(all_seasonal_stats, season1, season2)
                    
                    if comparison["status"] == "success":
                        st.subheader(f"Comparison: {season1} vs {season2}")
                        
                        # Create tabs for comparison views
                        comparison_tabs = st.tabs(["Team Comparisons", "Overall Tournament Comparison"])
                        
                        # Team Comparisons Tab
                        with comparison_tabs[0]:
                            if comparison["team_comparisons"]:
                                import pandas as pd
                                import plotly.express as px
                                
                                # Create a table of team comparisons
                                teams_compared = []
                                for team_comp in comparison["team_comparisons"]:
                                    team_data = {
                                        "Team": team_comp["team"]
                                    }
                                    
                                    for metric, values in team_comp["metrics"].items():
                                        team_data[f"{metric} ({season1})"] = round(values["season1"], 2)
                                        team_data[f"{metric} ({season2})"] = round(values["season2"], 2)
                                        team_data[f"{metric} Change"] = round(values["change"], 2)
                                        
                                        # Format percent change to handle infinity
                                        if values["percent_change"] == float('inf'):
                                            team_data[f"{metric} % Change"] = "N/A"
                                        else:
                                            team_data[f"{metric} % Change"] = f"{round(values['percent_change'], 1)}%"
                                    
                                    teams_compared.append(team_data)
                                
                                comp_df = pd.DataFrame(teams_compared)
                                
                                # Display table with selected metrics
                                display_metrics = ["wins", "points", "position"]
                                display_cols = ["Team"]
                                
                                for metric in display_metrics:
                                    display_cols.extend([
                                        f"{metric} ({season1})", 
                                        f"{metric} ({season2})", 
                                        f"{metric} Change"
                                    ])
                                
                                st.subheader("Team Performance Changes")
                                
                                # Filter columns that exist in the dataframe
                                valid_cols = [col for col in display_cols if col in comp_df.columns]
                                if valid_cols:
                                    st.dataframe(comp_df[valid_cols], hide_index=True, use_container_width=True)
                                
                                # Visualize wins comparison
                                st.subheader("Wins Comparison by Team")
                                
                                # Create comparison data
                                win_data = []
                                for team in teams_compared:
                                    if "wins ("+str(season1)+")" in team and "wins ("+str(season2)+")" in team:
                                        win_data.append({
                                            "Team": team["Team"],
                                            "Season": str(season1),
                                            "Wins": team[f"wins ({season1})"]
                                        })
                                        win_data.append({
                                            "Team": team["Team"],
                                            "Season": str(season2),
                                            "Wins": team[f"wins ({season2})"]
                                        })
                                
                                win_df = pd.DataFrame(win_data)
                                
                                if not win_df.empty:
                                    win_fig = px.bar(
                                        win_df,
                                        x="Team",
                                        y="Wins",
                                        color="Season",
                                        barmode="group",
                                        title="Team Wins Comparison",
                                        height=500,
                                        color_discrete_sequence=["#3366cc", "#dc3912"]
                                    )
                                    
                                    win_fig.update_layout(xaxis_tickangle=-45)
                                    
                                    st.plotly_chart(win_fig, use_container_width=True)
                                
                                # Visualize points comparison
                                st.subheader("Points Comparison by Team")
                                
                                # Create comparison data
                                point_data = []
                                for team in teams_compared:
                                    if "points ("+str(season1)+")" in team and "points ("+str(season2)+")" in team:
                                        point_data.append({
                                            "Team": team["Team"],
                                            "Season": str(season1),
                                            "Points": team[f"points ({season1})"]
                                        })
                                        point_data.append({
                                            "Team": team["Team"],
                                            "Season": str(season2),
                                            "Points": team[f"points ({season2})"]
                                        })
                                
                                point_df = pd.DataFrame(point_data)
                                
                                if not point_df.empty:
                                    point_fig = px.bar(
                                        point_df,
                                        x="Team",
                                        y="Points",
                                        color="Season",
                                        barmode="group",
                                        title="Team Points Comparison",
                                        height=500,
                                        color_discrete_sequence=["#3366cc", "#dc3912"]
                                    )
                                    
                                    point_fig.update_layout(xaxis_tickangle=-45)
                                    
                                    st.plotly_chart(point_fig, use_container_width=True)
                                
                                # Show position changes (positive is worse, negative is better)
                                st.subheader("Team Position Changes")
                                
                                # Create position change data
                                pos_data = []
                                for team in teams_compared:
                                    if "position Change" in team:
                                        pos_change = team["position Change"]
                                        pos_data.append({
                                            "Team": team["Team"],
                                            "Position Change": -pos_change,  # Invert so positive is better (higher position)
                                            "Color": "Improved" if pos_change < 0 else "Declined" if pos_change > 0 else "Same"
                                        })
                                
                                pos_df = pd.DataFrame(pos_data)
                                
                                if not pos_df.empty:
                                    pos_fig = px.bar(
                                        pos_df,
                                        x="Team",
                                        y="Position Change",
                                        color="Color",
                                        title=f"Position Changes from {season1} to {season2}",
                                        height=500,
                                        color_discrete_map={
                                            "Improved": "#00cc96",
                                            "Declined": "#ef553b",
                                            "Same": "#636efa"
                                        }
                                    )
                                    
                                    # Add a zero line
                                    pos_fig.add_hline(
                                        y=0,
                                        line_dash="dash",
                                        line_color="gray"
                                    )
                                    
                                    pos_fig.update_layout(
                                        xaxis_tickangle=-45,
                                        yaxis_title="Position Change (Positive = Better)"
                                    )
                                    
                                    st.plotly_chart(pos_fig, use_container_width=True)
                            else:
                                st.info("No team comparison data available.")
                        
                        # Overall Tournament Comparison
                        with comparison_tabs[1]:
                            if comparison["overall_comparison"]:
                                import pandas as pd
                                import plotly.express as px
                                
                                # Create a table of overall comparisons
                                overall_data = []
                                
                                for metric, values in comparison["overall_comparison"].items():
                                    overall_data.append({
                                        "Metric": metric.replace('_', ' ').title(),
                                        str(season1): round(values["season1"], 2),
                                        str(season2): round(values["season2"], 2),
                                        "Change": round(values["change"], 2),
                                        "% Change": f"{round((values['change'] / values['season1']) * 100, 1)}%" if values["season1"] != 0 else "N/A"
                                    })
                                
                                overall_df = pd.DataFrame(overall_data)
                                
                                st.subheader("Overall Tournament Metrics")
                                st.dataframe(overall_df, hide_index=True, use_container_width=True)
                                
                                # Visualize overall comparisons
                                st.subheader("Tournament Metrics Comparison")
                                
                                # Reshape data for visualization
                                viz_data = []
                                for metric in overall_data:
                                    viz_data.append({
                                        "Metric": metric["Metric"],
                                        "Season": str(season1),
                                        "Value": metric[str(season1)]
                                    })
                                    viz_data.append({
                                        "Metric": metric["Metric"],
                                        "Season": str(season2),
                                        "Value": metric[str(season2)]
                                    })
                                
                                viz_df = pd.DataFrame(viz_data)
                                
                                # Create comparison chart
                                fig = px.bar(
                                    viz_df,
                                    x="Metric",
                                    y="Value",
                                    color="Season",
                                    barmode="group",
                                    title=f"Tournament Metrics: {season1} vs {season2}",
                                    height=500,
                                    color_discrete_sequence=["#3366cc", "#dc3912"]
                                )
                                
                                # Update layout
                                fig.update_layout(xaxis_tickangle=-45)
                                
                                st.plotly_chart(fig, use_container_width=True)
                                
                                # Create percent change visualization
                                pct_data = []
                                for metric in overall_data:
                                    if metric["% Change"] != "N/A":
                                        change_pct = float(metric["% Change"].strip('%'))
                                        pct_data.append({
                                            "Metric": metric["Metric"],
                                            "Percent Change": change_pct,
                                            "Direction": "Increase" if change_pct > 0 else "Decrease"
                                        })
                                
                                pct_df = pd.DataFrame(pct_data)
                                
                                if not pct_df.empty:
                                    pct_fig = px.bar(
                                        pct_df,
                                        x="Metric",
                                        y="Percent Change",
                                        color="Direction",
                                        title=f"Percent Change from {season1} to {season2}",
                                        height=500,
                                        color_discrete_map={
                                            "Increase": "#00cc96",
                                            "Decrease": "#ef553b"
                                        }
                                    )
                                    
                                    # Add a zero line
                                    pct_fig.add_hline(
                                        y=0,
                                        line_dash="dash",
                                        line_color="gray"
                                    )
                                    
                                    pct_fig.update_layout(
                                        xaxis_tickangle=-45,
                                        yaxis_title="Percent Change (%)"
                                    )
                                    
                                    st.plotly_chart(pct_fig, use_container_width=True)
                            else:
                                st.info("No overall comparison data available.")
                    else:
                        st.error(comparison["message"])
            else:
                st.warning("Need at least two seasons of data for comparison. Please refresh data.")
        
        # Tab 4: Performance Patterns
        with trend_analysis_tabs[3]:
            st.subheader("Performance Patterns")
            
            st.info("""
            Identify recurring patterns and trends in team performances across seasons.
            Discover which teams are consistently successful, which teams show alternating patterns,
            and what statistical patterns emerge from the historical data.
            """)
            
            # Get all seasonal stats from database
            all_seasonal_stats = get_team_seasonal_stats()
            
            # If no data in database, generate mock data
            if not all_seasonal_stats:
                st.warning("""
                Historical seasonal data is not available in the database. 
                Using simulated data for demonstration purposes.
                """)
                
                # Generate mock seasonal data for demonstration
                teams_list = list(st.session_state.teams_data.get('teams', {}).keys())
                all_seasonal_stats = generate_mock_seasonal_data(
                    teams=teams_list,
                    start_year=2016,
                    end_year=2023
                )
            
            # Set minimum seasons for analysis
            min_seasons = st.slider(
                "Minimum Seasons Required for Pattern Analysis", 
                min_value=3, 
                max_value=8, 
                value=3,
                key="pattern_min_seasons"
            )
            
            # Identify patterns
            if st.button("Analyze Performance Patterns", key="analyze_patterns_btn"):
                patterns = identify_performance_patterns(all_seasonal_stats, min_seasons=min_seasons)
                
                if patterns["status"] == "success":
                    # Create tabs for different patterns
                    pattern_tabs = st.tabs(["Team Patterns", "General Tournament Patterns"])
                    
                    # Team Patterns Tab
                    with pattern_tabs[0]:
                        if patterns["team_patterns"]:
                            # Create an expander for each team
                            for team_pattern in patterns["team_patterns"]:
                                team_name = team_pattern["team"]
                                team_patterns = team_pattern["patterns"]
                                
                                if team_patterns:
                                    with st.expander(f"{team_name} Patterns"):
                                        for pattern in team_patterns:
                                            if pattern["type"] == "consistency":
                                                st.markdown(f"🔁 **Consistency Pattern**: {pattern['description']}")
                                            elif pattern["type"] == "venue_preference":
                                                st.markdown(f"🏟️ **Venue Effect**: {pattern['description']}")
                                            elif pattern["type"] == "strength_balance":
                                                st.markdown(f"⚖️ **Team Balance**: {pattern['description']}")
                                            elif pattern["type"] == "strength_imbalance":
                                                st.markdown(f"⚠️ **Team Imbalance**: {pattern['description']}")
                                            elif pattern["type"] == "performance_cycle":
                                                st.markdown(f"🔄 **Performance Cycle**: {pattern['description']}")
                                            else:
                                                st.markdown(f"📊 **Other Pattern**: {pattern['description']}")
                        else:
                            st.info("No team-specific patterns identified with the current data and criteria.")
                    
                    # General Patterns Tab
                    with pattern_tabs[1]:
                        if patterns["general_patterns"]:
                            st.subheader("Tournament-wide Patterns")
                            
                            for pattern in patterns["general_patterns"]:
                                if pattern["type"] == "venue_impact":
                                    st.markdown(f"🏟️ **Venue Impact**: {pattern['description']} (Strength: {pattern.get('strength', 'N/A')})")
                                elif pattern["type"] == "toss_impact":
                                    st.markdown(f"🎲 **Toss Impact**: {pattern['description']} (Strength: {pattern.get('strength', 'N/A')})")
                                elif pattern["type"] == "run_impact":
                                    st.markdown(f"🏏 **Run Scoring Impact**: {pattern['description']} (Strength: {pattern.get('strength', 'N/A')})")
                                elif pattern["type"] == "consistent_performers":
                                    teams_list = ", ".join(pattern.get("teams", []))
                                    st.markdown(f"🏆 **Consistent Performers**: {pattern['description']}: {teams_list}")
                                else:
                                    st.markdown(f"📊 **Other Pattern**: {pattern['description']}")
                        else:
                            st.info("No general tournament patterns identified with the current data and criteria.")
                else:
                    st.error(patterns["message"])
    else:
        st.info("No data loaded. Please use the 'Data Refresh' tab to fetch the latest IPL player stats.")
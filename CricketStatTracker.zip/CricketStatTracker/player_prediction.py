"""
Player Performance Prediction Module for IPL Cricket Stats Dashboard

This module provides tools to predict player performance metrics for upcoming matches
based on historical data, current form, and matchup analysis.
"""

import numpy as np
import pandas as pd
from typing import Dict, List, Any, Optional, Tuple

def predict_batting_performance(player_data: Dict[str, Any], 
                               opponent_team: str = None, 
                               venue: str = None) -> Dict[str, Any]:
    """
    Predict a player's batting performance for an upcoming match
    
    Args:
        player_data: Player's historical data and statistics
        opponent_team: Optional name of the opposing team
        venue: Optional name of the match venue
        
    Returns:
        Dictionary with predicted batting metrics
    """
    # Extract relevant batting statistics
    batting_stats = player_data.get('batting_stats', {})
    matches_played = player_data.get('matches_played', 0)
    
    if matches_played < 5 or not batting_stats:
        # Not enough data for reliable prediction
        return {
            'predicted_runs': None,
            'predicted_strike_rate': None,
            'run_range_low': None,
            'run_range_high': None,
            'confidence': 'Low',
            'boundary_count': None
        }
    
    # Base prediction on career statistics
    avg_runs = batting_stats.get('average', 0) * 0.8  # Adjust average by 80%
    
    # Factor in recent form (last few matches would ideally be factored in)
    recent_form_factor = 1.0  # Neutral factor
    
    # Form adjustments (simplified model for prototype)
    if 'recent_matches' in player_data:
        recent_matches = player_data.get('recent_matches', [])
        if recent_matches:
            recent_runs = [m.get('runs', 0) for m in recent_matches[:5] if 'runs' in m]
            if recent_runs:
                recent_avg = sum(recent_runs) / len(recent_runs)
                if recent_avg > batting_stats.get('average', 0) * 1.2:
                    recent_form_factor = 1.2  # Good form
                elif recent_avg < batting_stats.get('average', 0) * 0.8:
                    recent_form_factor = 0.8  # Poor form
    
    # Adjust for opponent team
    opponent_factor = 1.0
    if opponent_team:
        # This would ideally use historical data against this team
        # For now, use a simple random factor for demonstration
        np.random.seed(hash(opponent_team + player_data.get('name', '')) % 2**32)
        opponent_factor = np.random.uniform(0.8, 1.2)
    
    # Adjust for venue
    venue_factor = 1.0
    if venue:
        # This would ideally use historical data at this venue
        # For now, use a simple random factor for demonstration
        np.random.seed(hash(venue + player_data.get('name', '')) % 2**32)
        venue_factor = np.random.uniform(0.9, 1.1)
    
    # Calculate final predicted runs
    predicted_runs = avg_runs * recent_form_factor * opponent_factor * venue_factor
    
    # Calculate predicted strike rate
    base_sr = batting_stats.get('strike_rate', 120)
    predicted_sr = base_sr * recent_form_factor
    
    # Estimate boundary count
    boundaries_per_inning = (batting_stats.get('fours', 0) + batting_stats.get('sixes', 0)) / max(1, matches_played)
    predicted_boundaries = boundaries_per_inning * recent_form_factor * venue_factor
    
    # Determine confidence level based on available data
    if matches_played > 30:
        confidence = "High"
    elif matches_played > 15:
        confidence = "Medium"
    else:
        confidence = "Low"
    
    # Create prediction range
    margin = 0.25  # 25% variance
    run_range_low = max(0, round(predicted_runs * (1 - margin)))
    run_range_high = round(predicted_runs * (1 + margin))
    
    return {
        'predicted_runs': round(predicted_runs),
        'predicted_strike_rate': round(predicted_sr, 1),
        'run_range_low': run_range_low,
        'run_range_high': run_range_high,
        'confidence': confidence,
        'boundary_count': round(predicted_boundaries, 1)
    }

def predict_bowling_performance(player_data: Dict[str, Any],
                              opponent_team: str = None,
                              venue: str = None) -> Dict[str, Any]:
    """
    Predict a player's bowling performance for an upcoming match
    
    Args:
        player_data: Player's historical data and statistics
        opponent_team: Optional name of the opposing team
        venue: Optional name of the match venue
        
    Returns:
        Dictionary with predicted bowling metrics
    """
    # Extract relevant bowling statistics
    bowling_stats = player_data.get('bowling_stats', {})
    matches_played = player_data.get('matches_played', 0)
    
    if matches_played < 5 or not bowling_stats:
        # Not enough data for reliable prediction
        return {
            'predicted_wickets': None,
            'predicted_economy': None,
            'wicket_range_low': None,
            'wicket_range_high': None,
            'confidence': 'Low',
            'dot_ball_percentage': None
        }
    
    # Base prediction on career statistics
    avg_wickets = bowling_stats.get('wickets', 0) / max(1, matches_played)
    
    # Factor in recent form (last few matches would ideally be factored in)
    recent_form_factor = 1.0  # Neutral factor
    
    # Form adjustments (simplified model for prototype)
    if 'recent_matches' in player_data:
        recent_matches = player_data.get('recent_matches', [])
        if recent_matches:
            recent_wickets = [m.get('wickets', 0) for m in recent_matches[:5] if 'wickets' in m]
            if recent_wickets:
                recent_avg_wickets = sum(recent_wickets) / len(recent_wickets)
                if recent_avg_wickets > avg_wickets * 1.2:
                    recent_form_factor = 1.2  # Good form
                elif recent_avg_wickets < avg_wickets * 0.8:
                    recent_form_factor = 0.8  # Poor form
    
    # Adjust for opponent team
    opponent_factor = 1.0
    if opponent_team:
        # This would ideally use historical data against this team
        # For now, use a simple random factor for demonstration
        np.random.seed(hash(opponent_team + player_data.get('name', '')) % 2**32)
        opponent_factor = np.random.uniform(0.8, 1.2)
    
    # Adjust for venue
    venue_factor = 1.0
    if venue:
        # This would ideally use historical data at this venue
        # For now, use a simple random factor for demonstration
        np.random.seed(hash(venue + player_data.get('name', '')) % 2**32)
        venue_factor = np.random.uniform(0.9, 1.1)
    
    # Calculate final predicted wickets
    predicted_wickets = avg_wickets * recent_form_factor * opponent_factor * venue_factor
    
    # Calculate predicted economy rate
    base_economy = bowling_stats.get('economy', 8.0)
    # For economy, lower is better so we invert the form factor
    predicted_economy = base_economy * (2.0 - recent_form_factor)
    
    # Estimate dot ball percentage
    base_dot_balls = bowling_stats.get('dot_balls', 0)
    total_balls = bowling_stats.get('overs_bowled', 0) * 6
    if total_balls > 0 and base_dot_balls > 0:
        dot_ball_pct = (base_dot_balls / total_balls) * 100
    else:
        dot_ball_pct = 30  # Default estimate if data not available
    
    predicted_dot_ball_pct = dot_ball_pct * recent_form_factor
    
    # Determine confidence level based on available data
    if matches_played > 30:
        confidence = "High"
    elif matches_played > 15:
        confidence = "Medium"
    else:
        confidence = "Low"
    
    # Create prediction range
    margin = 0.5  # 50% variance for wickets as they are more variable
    wicket_range_low = max(0, round(predicted_wickets * (1 - margin)))
    wicket_range_high = round(predicted_wickets * (1 + margin) + 0.5)
    
    return {
        'predicted_wickets': round(predicted_wickets, 1),
        'predicted_economy': round(predicted_economy, 1),
        'wicket_range_low': wicket_range_low,
        'wicket_range_high': wicket_range_high,
        'confidence': confidence,
        'dot_ball_percentage': round(predicted_dot_ball_pct, 1)
    }

def get_match_prediction(team1_data: Dict[str, Any], 
                        team2_data: Dict[str, Any],
                        venue: str = None) -> Dict[str, Any]:
    """
    Predict the outcome of a match between two teams using advanced statistical methods
    
    Args:
        team1_data: First team's data (name and players)
        team2_data: Second team's data (name and players)
        venue: Optional name of the match venue
        
    Returns:
        Dictionary with match prediction metrics
    """
    team1_name = team1_data.get('name', 'Team 1')
    team2_name = team2_data.get('name', 'Team 2')
    
    # Calculate team strength based on player ratings
    team1_players = team1_data.get('players', [])
    team2_players = team2_data.get('players', [])
    
    team1_batting_strength = sum(p.get('batting_rating', 0) for p in team1_players)
    team1_bowling_strength = sum(p.get('bowling_rating', 0) for p in team1_players)
    
    team2_batting_strength = sum(p.get('batting_rating', 0) for p in team2_players)
    team2_bowling_strength = sum(p.get('bowling_rating', 0) for p in team2_players)
    
    # Calculate player standard deviations to incorporate central limit theorem
    # Higher variance means less predictable performance
    team1_batting_std = np.std([p.get('batting_rating', 0) for p in team1_players if p.get('batting_rating', 0) > 0]) if len(team1_players) > 5 else 15
    team1_bowling_std = np.std([p.get('bowling_rating', 0) for p in team1_players if p.get('bowling_rating', 0) > 0]) if len(team1_players) > 5 else 15
    
    team2_batting_std = np.std([p.get('batting_rating', 0) for p in team2_players if p.get('batting_rating', 0) > 0]) if len(team2_players) > 5 else 15
    team2_bowling_std = np.std([p.get('bowling_rating', 0) for p in team2_players if p.get('bowling_rating', 0) > 0]) if len(team2_players) > 5 else 15
    
    # Apply Law of Large Numbers - more players above a certain threshold increases predictability
    # Teams with more consistent players have more reliable performance
    team1_reliable_batters = sum(1 for p in team1_players if p.get('batting_rating', 0) > 50)
    team1_reliable_bowlers = sum(1 for p in team1_players if p.get('bowling_rating', 0) > 50)
    
    team2_reliable_batters = sum(1 for p in team2_players if p.get('batting_rating', 0) > 50)
    team2_reliable_bowlers = sum(1 for p in team2_players if p.get('bowling_rating', 0) > 50)
    
    # Reliability factors based on Law of Large Numbers
    # More consistent performers reduce uncertainty
    team1_batting_reliability = min(1.0, 0.7 + (team1_reliable_batters / 5) * 0.3) 
    team1_bowling_reliability = min(1.0, 0.7 + (team1_reliable_bowlers / 5) * 0.3)
    
    team2_batting_reliability = min(1.0, 0.7 + (team2_reliable_batters / 5) * 0.3)
    team2_bowling_reliability = min(1.0, 0.7 + (team2_reliable_bowlers / 5) * 0.3)
    
    # Adjust strength based on reliability (Law of Large Numbers)
    team1_batting_strength *= team1_batting_reliability
    team1_bowling_strength *= team1_bowling_reliability
    
    team2_batting_strength *= team2_batting_reliability
    team2_bowling_strength *= team2_bowling_reliability
    
    # Overall team strength (combination of batting and bowling)
    team1_strength = (team1_batting_strength + team1_bowling_strength) / 2
    team2_strength = (team2_batting_strength + team2_bowling_strength) / 2
    
    # Add venue factor (home advantage if applicable)
    venue_factor1 = 1.0
    venue_factor2 = 1.0
    
    if venue:
        if team1_data.get('home_ground') == venue:
            venue_factor1 = 1.1  # 10% home advantage
        elif team2_data.get('home_ground') == venue:
            venue_factor2 = 1.1  # 10% home advantage
    
    # Apply venue factors
    team1_strength *= venue_factor1
    team2_strength *= venue_factor2
    
    # ----------------------
    # Bayesian Approach
    # ----------------------
    # Prior probabilities (initial guess based on team strengths)
    prior_team1_win = team1_strength / (team1_strength + team2_strength)
    prior_team2_win = 1 - prior_team1_win
    
    # Calculate likelihoods using normalized team strengths
    # Likelihood represents: P(Evidence|Team wins)
    batting_advantage_ratio = team1_batting_strength / max(1, team2_bowling_strength)
    bowling_advantage_ratio = team1_bowling_strength / max(1, team2_batting_strength)
    
    # Normalize these ratios to create likelihood factors
    likelihood_batting = batting_advantage_ratio / (batting_advantage_ratio + 1)
    likelihood_bowling = bowling_advantage_ratio / (bowling_advantage_ratio + 1)
    
    # Calculate evidence terms for Bayes theorem
    evidence = (prior_team1_win * likelihood_batting * likelihood_bowling) + \
               (prior_team2_win * (1-likelihood_batting) * (1-likelihood_bowling))
               
    # Apply Bayes theorem for final probabilities
    # P(Team1 wins|Evidence) = P(Evidence|Team1 wins) * P(Team1 wins) / P(Evidence)
    if evidence > 0:
        posterior_team1_win = (likelihood_batting * likelihood_bowling * prior_team1_win) / evidence
        posterior_team2_win = 1 - posterior_team1_win
    else:
        posterior_team1_win = prior_team1_win
        posterior_team2_win = prior_team2_win
    
    # Apply central limit theorem to create confidence intervals
    # Standard error decreases with more consistent team performance
    confidence_factor1 = 1.0 / (1.0 + (team1_batting_std + team1_bowling_std) / 100)
    confidence_factor2 = 1.0 / (1.0 + (team2_batting_std + team2_bowling_std) / 100)
    
    # Final win probabilities - balance Bayesian result with confidence based on central limit theorem
    team1_win_prob = (posterior_team1_win * 100 * confidence_factor1 + prior_team1_win * 100 * (1-confidence_factor1))
    team2_win_prob = (posterior_team2_win * 100 * confidence_factor2 + prior_team2_win * 100 * (1-confidence_factor2))
    
    # Normalize probabilities to ensure they sum to 100%
    total_prob = team1_win_prob + team2_win_prob
    if total_prob > 0:
        team1_win_prob = (team1_win_prob / total_prob) * 100
        team2_win_prob = (team2_win_prob / total_prob) * 100
    else:
        team1_win_prob = team2_win_prob = 50  # Equal probability if no data
    
    # Predict scores using a model refined with central limit theorem
    # Incorporate standard deviations for more accurate range prediction
    team1_predicted_score = 160 + (team1_batting_strength - team2_bowling_strength) / 10
    team2_predicted_score = 160 + (team2_batting_strength - team1_bowling_strength) / 10
    
    # Adjust scores based on team variability (from central limit theorem)
    team1_score_variability = (team1_batting_std + team2_bowling_std) / 2
    team2_score_variability = (team2_batting_std + team1_bowling_std) / 2
    
    # Reasonable ranges based on data
    team1_predicted_score = max(120, min(220, team1_predicted_score))
    team2_predicted_score = max(120, min(220, team2_predicted_score))
    
    # Determine expected winner
    if team1_win_prob > team2_win_prob:
        expected_winner = team1_name
        win_probability = team1_win_prob
    else:
        expected_winner = team2_name
        win_probability = team2_win_prob
    
    # Generate statistical insights
    statistical_insights = []
    
    # Batting insights
    if team1_batting_strength > team2_batting_strength * 1.2:
        statistical_insights.append(f"{team1_name} has {((team1_batting_strength/team2_batting_strength)-1)*100:.1f}% stronger batting lineup")
    elif team2_batting_strength > team1_batting_strength * 1.2:
        statistical_insights.append(f"{team2_name} has {((team2_batting_strength/team1_batting_strength)-1)*100:.1f}% stronger batting lineup")
    
    # Bowling insights
    if team1_bowling_strength > team2_bowling_strength * 1.2:
        statistical_insights.append(f"{team1_name} has {((team1_bowling_strength/team2_bowling_strength)-1)*100:.1f}% stronger bowling attack")
    elif team2_bowling_strength > team1_bowling_strength * 1.2:
        statistical_insights.append(f"{team2_name} has {((team2_bowling_strength/team1_bowling_strength)-1)*100:.1f}% stronger bowling attack")
    
    # Reliability insights
    if team1_batting_reliability > team2_batting_reliability * 1.2:
        statistical_insights.append(f"{team1_name} has more consistent batting performance")
    elif team2_batting_reliability > team1_batting_reliability * 1.2:
        statistical_insights.append(f"{team2_name} has more consistent batting performance")
        
    if team1_bowling_reliability > team2_bowling_reliability * 1.2:
        statistical_insights.append(f"{team1_name} has more consistent bowling performance")
    elif team2_bowling_reliability > team1_bowling_reliability * 1.2:
        statistical_insights.append(f"{team2_name} has more consistent bowling performance")
    
    # Venue advantage
    if venue_factor1 > 1:
        statistical_insights.append(f"Home advantage for {team1_name} at {venue} (10% higher win probability)")
    elif venue_factor2 > 1:
        statistical_insights.append(f"Home advantage for {team2_name} at {venue} (10% higher win probability)")
    
    # Statistical confidence based on data quality
    if confidence_factor1 > 0.8 and confidence_factor2 > 0.8:
        statistical_insights.append("High prediction confidence due to consistent team performances")
    elif confidence_factor1 < 0.6 or confidence_factor2 < 0.6:
        statistical_insights.append("Lower prediction confidence due to variable team performances")
    
    # Model information
    key_factors = [
        f"Prediction uses Bayesian inference combining prior team strengths with performance data",
        f"Central Limit Theorem applied to account for player performance variations",
        f"Law of Large Numbers incorporated to weight teams with consistent performers",
        f"Prediction confidence: {min(confidence_factor1, confidence_factor2)*100:.1f}%"
    ]
    
    return {
        'team1': {
            'name': team1_name,
            'win_probability': round(team1_win_prob, 1),
            'predicted_score': round(team1_predicted_score),
            'batting_strength': round(team1_batting_strength, 1),
            'bowling_strength': round(team1_bowling_strength, 1),
            'reliability': round((team1_batting_reliability + team1_bowling_reliability)/2 * 100, 1),
            'confidence': round(confidence_factor1 * 100, 1)
        },
        'team2': {
            'name': team2_name,
            'win_probability': round(team2_win_prob, 1),
            'predicted_score': round(team2_predicted_score),
            'batting_strength': round(team2_batting_strength, 1),
            'bowling_strength': round(team2_bowling_strength, 1),
            'reliability': round((team2_batting_reliability + team2_bowling_reliability)/2 * 100, 1),
            'confidence': round(confidence_factor2 * 100, 1)
        },
        'expected_winner': expected_winner,
        'win_probability': round(win_probability, 1),
        'key_factors': key_factors,
        'statistical_insights': statistical_insights,
        'bayesian_analysis': {
            'prior_probability': round(prior_team1_win * 100, 1),
            'likelihood_ratio': round(likelihood_batting * likelihood_bowling * 100, 1),
            'posterior_probability': round(posterior_team1_win * 100, 1)
        }
    }

def generate_player_ratings(players_data: Dict[str, Dict]) -> Dict[str, Dict]:
    """
    Generate numerical ratings for players based on their performance metrics
    
    Args:
        players_data: Dictionary containing player data
        
    Returns:
        Dictionary with player IDs as keys and rating data as values
    """
    player_ratings = {}
    
    for player_id, player in players_data.items():
        batting_stats = player.get('batting_stats', {})
        bowling_stats = player.get('bowling_stats', {})
        matches = player.get('matches_played', 0)
        
        if matches < 3:
            # Not enough data for reliable ratings
            player_ratings[player_id] = {
                'batting_rating': 0,
                'bowling_rating': 0,
                'overall_rating': 0
            }
            continue
        
        # Calculate batting rating (0-100 scale)
        batting_rating = 0
        if batting_stats:
            runs = batting_stats.get('runs', 0)
            avg = batting_stats.get('average', 0)
            sr = batting_stats.get('strike_rate', 0)
            
            # Runs contribution (max 40 points)
            if runs > 1000:
                runs_rating = 40
            elif runs > 500:
                runs_rating = 30
            elif runs > 200:
                runs_rating = 20
            elif runs > 100:
                runs_rating = 10
            else:
                runs_rating = runs / 10
            
            # Average contribution (max 30 points)
            if avg > 40:
                avg_rating = 30
            elif avg > 30:
                avg_rating = 25
            elif avg > 20:
                avg_rating = 20
            elif avg > 15:
                avg_rating = 15
            else:
                avg_rating = avg / 2
            
            # Strike rate contribution (max 30 points)
            if sr > 150:
                sr_rating = 30
            elif sr > 130:
                sr_rating = 25
            elif sr > 120:
                sr_rating = 20
            elif sr > 100:
                sr_rating = 15
            else:
                sr_rating = sr / 10
            
            batting_rating = runs_rating + avg_rating + sr_rating
            batting_rating = min(100, batting_rating)  # Cap at 100
        
        # Calculate bowling rating (0-100 scale)
        bowling_rating = 0
        if bowling_stats:
            wickets = bowling_stats.get('wickets', 0)
            economy = bowling_stats.get('economy', 0)
            avg = bowling_stats.get('average', 0)
            
            # Wickets contribution (max 40 points)
            if wickets > 50:
                wickets_rating = 40
            elif wickets > 30:
                wickets_rating = 30
            elif wickets > 15:
                wickets_rating = 20
            elif wickets > 5:
                wickets_rating = 10
            else:
                wickets_rating = wickets * 2
            
            # Economy contribution (max 30 points)
            if economy > 0:  # Ensure we have economy rate data
                if economy < 6.5:
                    economy_rating = 30
                elif economy < 7.5:
                    economy_rating = 25
                elif economy < 8.5:
                    economy_rating = 20
                elif economy < 9.5:
                    economy_rating = 15
                else:
                    economy_rating = max(0, 30 - (economy - 6) * 3)
            else:
                economy_rating = 0
            
            # Average contribution (max 30 points)
            if avg > 0:  # Ensure we have average data
                if avg < 20:
                    avg_rating = 30
                elif avg < 25:
                    avg_rating = 25
                elif avg < 30:
                    avg_rating = 20
                elif avg < 35:
                    avg_rating = 15
                else:
                    avg_rating = max(0, 30 - (avg - 20) / 2)
            else:
                avg_rating = 0
            
            bowling_rating = wickets_rating + economy_rating + avg_rating
            bowling_rating = min(100, bowling_rating)  # Cap at 100
        
        # Calculate overall rating based on role
        role = player.get('role', '')
        
        if role == 'Batsman':
            overall_rating = batting_rating * 0.9 + bowling_rating * 0.1
        elif role == 'Bowler':
            overall_rating = batting_rating * 0.1 + bowling_rating * 0.9
        elif role == 'All-rounder':
            overall_rating = batting_rating * 0.5 + bowling_rating * 0.5
        elif role == 'Wicket-keeper Batsman':
            overall_rating = batting_rating * 0.85 + bowling_rating * 0.05 + 10  # Bonus for keeping
        else:
            overall_rating = batting_rating * 0.5 + bowling_rating * 0.5
        
        player_ratings[player_id] = {
            'batting_rating': round(batting_rating, 1),
            'bowling_rating': round(bowling_rating, 1),
            'overall_rating': round(overall_rating, 1)
        }
    
    return player_ratings

def predict_season_performance(player_data: Dict[str, Any], 
                              num_matches: int = 14) -> Dict[str, Any]:
    """
    Predict a player's performance over a full IPL season
    
    Args:
        player_data: Player's historical data and statistics
        num_matches: Number of matches in the season (default 14)
        
    Returns:
        Dictionary with predicted season statistics
    """
    batting_stats = player_data.get('batting_stats', {})
    bowling_stats = player_data.get('bowling_stats', {})
    matches_played = player_data.get('matches_played', 0)
    
    if matches_played < 5:
        # Not enough data for reliable prediction
        return {
            'season_runs': None,
            'season_average': None,
            'season_wickets': None,
            'season_economy': None,
            'confidence': 'Low'
        }
    
    # Calculate estimated matches the player will play (accounting for injuries, selection, etc.)
    availability_factor = 0.8  # Assume player plays 80% of matches on average
    expected_matches = round(num_matches * availability_factor)
    
    # Batting predictions
    season_runs = None
    season_avg = None
    if batting_stats:
        avg_runs_per_match = batting_stats.get('runs', 0) / max(1, matches_played)
        season_runs = round(avg_runs_per_match * expected_matches)
        
        # Calculate predicted average
        dismissals = matches_played - batting_stats.get('not_outs', 0)
        if dismissals > 0:
            dismissal_rate = dismissals / matches_played
            expected_dismissals = expected_matches * dismissal_rate
            if expected_dismissals > 0:
                season_avg = round(season_runs / expected_dismissals, 2)
    
    # Bowling predictions
    season_wickets = None
    season_economy = None
    if bowling_stats:
        avg_wickets_per_match = bowling_stats.get('wickets', 0) / max(1, matches_played)
        season_wickets = round(avg_wickets_per_match * expected_matches)
        
        # Use existing economy rate as prediction
        season_economy = bowling_stats.get('economy', None)
    
    # Determine confidence level based on available data
    if matches_played > 30:
        confidence = "High"
    elif matches_played > 15:
        confidence = "Medium"
    else:
        confidence = "Low"
    
    return {
        'expected_matches': expected_matches,
        'season_runs': season_runs,
        'season_average': season_avg,
        'season_wickets': season_wickets,
        'season_economy': season_economy,
        'confidence': confidence
    }

def get_player_matchups(player_data: Dict[str, Any], 
                       opponent_team: str, 
                       opponent_players: List[Dict]) -> Dict[str, Any]:
    """
    Analyze favorable and challenging matchups for a player against specific opponents
    
    Args:
        player_data: Player's historical data and statistics
        opponent_team: Name of the opposing team
        opponent_players: List of player data dictionaries for the opponent team
        
    Returns:
        Dictionary with matchup analysis
    """
    player_role = player_data.get('role', '')
    favorable_matchups = []
    challenging_matchups = []
    
    # This would ideally use historical head-to-head data
    # For now, we use a simplified model based on player roles and strengths
    
    if "Batsman" in player_role:
        # Find favorable and challenging bowling matchups
        for opponent in opponent_players:
            if opponent.get('role') == 'Bowler' or opponent.get('role') == 'All-rounder':
                bowling_stats = opponent.get('bowling_stats', {})
                
                # Create a simple matchup score
                matchup_score = 0
                
                # Analyze bowling style matchup (would use actual data in real implementation)
                if bowling_stats:
                    economy = bowling_stats.get('economy', 8.0)
                    avg = bowling_stats.get('average', 30.0)
                    
                    # Economy impact
                    if economy > 9.0:  # High economy is good for batsmen
                        matchup_score += 1
                    elif economy < 7.0:  # Low economy is challenging for batsmen
                        matchup_score -= 1
                    
                    # Average impact
                    if avg > 35.0:  # High average is good for batsmen
                        matchup_score += 1
                    elif avg < 25.0:  # Low average is challenging for batsmen
                        matchup_score -= 1
                
                # Add random factor for illustration (would be based on actual data)
                np.random.seed(hash(player_data.get('name', '') + opponent.get('name', '')) % 2**32)
                matchup_score += np.random.uniform(-0.5, 0.5)
                
                if matchup_score > 0.5:
                    favorable_matchups.append({
                        'player': opponent.get('name', ''),
                        'role': opponent.get('role', ''),
                        'reason': "Historically struggles against similar batting styles"
                    })
                elif matchup_score < -0.5:
                    challenging_matchups.append({
                        'player': opponent.get('name', ''),
                        'role': opponent.get('role', ''),
                        'reason': "Has good record against similar batting styles"
                    })
    
    elif player_role == 'Bowler' or player_role == 'All-rounder':
        # Find favorable and challenging batting matchups
        for opponent in opponent_players:
            if "Batsman" in opponent.get('role', ''):
                batting_stats = opponent.get('batting_stats', {})
                
                # Create a simple matchup score
                matchup_score = 0
                
                # Analyze batting style matchup (would use actual data in real implementation)
                if batting_stats:
                    sr = batting_stats.get('strike_rate', 120)
                    avg = batting_stats.get('average', 25)
                    
                    # Strike rate impact
                    if sr > 140:  # High SR might be vulnerable to certain bowlers
                        matchup_score += 0.5
                    elif sr < 120:  # Low SR might be resilient against certain types
                        matchup_score -= 0.5
                    
                    # Average impact
                    if avg > 35:  # High avg batsmen might be challenging
                        matchup_score -= 1
                    elif avg < 25:  # Low avg batsmen might be favorable
                        matchup_score += 1
                
                # Add random factor for illustration (would be based on actual data)
                np.random.seed(hash(player_data.get('name', '') + opponent.get('name', '')) % 2**32)
                matchup_score += np.random.uniform(-0.5, 0.5)
                
                if matchup_score > 0.5:
                    favorable_matchups.append({
                        'player': opponent.get('name', ''),
                        'role': opponent.get('role', ''),
                        'reason': "Bowling style matches up well against their batting technique"
                    })
                elif matchup_score < -0.5:
                    challenging_matchups.append({
                        'player': opponent.get('name', ''),
                        'role': opponent.get('role', ''),
                        'reason': "Batting technique counters this bowling style effectively"
                    })
    
    # Limit the number of matchups
    favorable_matchups = favorable_matchups[:3]
    challenging_matchups = challenging_matchups[:3]
    
    return {
        'favorable_matchups': favorable_matchups,
        'challenging_matchups': challenging_matchups
    }
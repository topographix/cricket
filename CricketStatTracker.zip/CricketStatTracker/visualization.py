import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots
from typing import Dict, List, Any, Tuple

def create_player_comparison_chart(player1: Dict, player2: Dict, chart_type: str = "Batting") -> go.Figure:
    """
    Create a comparison chart for two players
    
    Args:
        player1: First player's data
        player2: Second player's data
        chart_type: Type of comparison (Batting, Bowling, Overall)
        
    Returns:
        Plotly figure object
    """
    if chart_type == "Batting":
        # Batting comparison
        metrics = [
            {"name": "Runs", "key": "batting_stats.runs"},
            {"name": "Average", "key": "batting_stats.average"},
            {"name": "Strike Rate", "key": "batting_stats.strike_rate"},
            {"name": "50s", "key": "batting_stats.fifties"},
            {"name": "100s", "key": "batting_stats.hundreds"},
            {"name": "Fours", "key": "batting_stats.fours"},
            {"name": "Sixes", "key": "batting_stats.sixes"}
        ]
    elif chart_type == "Bowling":
        # Bowling comparison
        metrics = [
            {"name": "Wickets", "key": "bowling_stats.wickets"},
            {"name": "Economy", "key": "bowling_stats.economy"},
            {"name": "Average", "key": "bowling_stats.average"},
            {"name": "3+ Wicket Hauls", "key": "bowling_stats.three_plus"}
        ]
    else:  # Overall
        # Combined comparison
        metrics = [
            {"name": "Runs", "key": "batting_stats.runs"},
            {"name": "Wickets", "key": "bowling_stats.wickets"},
            {"name": "Matches", "key": "matches_played"},
            {"name": "Batting Avg", "key": "batting_stats.average"},
            {"name": "Bowling Eco", "key": "bowling_stats.economy"}
        ]
    
    # Function to get nested value safely
    def get_nested_value(player, key_path):
        """Get value from nested dictionary using dot notation path"""
        keys = key_path.split('.')
        value = player
        for key in keys:
            if isinstance(value, dict) and key in value:
                value = value[key]
            else:
                return 0
        
        # Handle None values
        if value is None:
            return 0
        return value
    
    # Prepare data for the chart
    comparison_data = []
    for metric in metrics:
        p1_value = get_nested_value(player1, metric["key"])
        p2_value = get_nested_value(player2, metric["key"])
        
        # Skip metrics where both players have zero values
        if p1_value == 0 and p2_value == 0:
            continue
            
        comparison_data.append({
            "Metric": metric["name"],
            player1["name"]: p1_value,
            player2["name"]: p2_value
        })
    
    # Create DataFrame
    df = pd.DataFrame(comparison_data)
    
    # If no valid metrics, return empty figure with message
    if len(df) == 0:
        fig = go.Figure()
        fig.add_annotation(
            text="No data available for comparison",
            xref="paper", yref="paper",
            x=0.5, y=0.5, showarrow=False,
            font=dict(size=16)
        )
        return fig
    
    # Melt the DataFrame for Plotly
    df_melted = pd.melt(
        df, 
        id_vars=["Metric"], 
        value_vars=[player1["name"], player2["name"]],
        var_name="Player", 
        value_name="Value"
    )
    
    # Create the bar chart
    fig = px.bar(
        df_melted, 
        x="Metric", 
        y="Value", 
        color="Player",
        barmode="group",
        title=f"{chart_type} Comparison: {player1['name']} vs {player2['name']}",
        color_discrete_sequence=["#1f77b4", "#ff7f0e"]
    )
    
    # Customize the layout
    fig.update_layout(
        xaxis_title="",
        yaxis_title="Value",
        legend_title="Player",
        font=dict(size=12),
        height=500
    )
    
    return fig

def create_team_stats_chart(team_info: Dict) -> go.Figure:
    """
    Create a chart showing team performance statistics
    
    Args:
        team_info: Team information dictionary
        
    Returns:
        Plotly figure object
    """
    if 'performance' not in team_info:
        fig = go.Figure()
        fig.add_annotation(
            text="No performance data available for this team",
            xref="paper", yref="paper",
            x=0.5, y=0.5, showarrow=False,
            font=dict(size=16)
        )
        return fig
    
    perf = team_info['performance']
    
    # Create a pie chart for win/loss ratio
    wins = perf.get('wins', 0)
    losses = perf.get('losses', 0)
    
    # Handle case with no matches
    if wins + losses == 0:
        fig = go.Figure()
        fig.add_annotation(
            text="No match data available for this team",
            xref="paper", yref="paper",
            x=0.5, y=0.5, showarrow=False,
            font=dict(size=16)
        )
        return fig
    
    # Create data for the pie chart
    labels = ['Wins', 'Losses']
    values = [wins, losses]
    
    # Create the pie chart
    fig = px.pie(
        values=values,
        names=labels,
        title=f"Win/Loss Ratio",
        color_discrete_sequence=["#2ecc71", "#e74c3c"]
    )
    
    # Customize the layout
    fig.update_layout(
        legend_title="Result",
        font=dict(size=12)
    )
    
    # Add win percentage annotation in the center
    win_percentage = (wins / (wins + losses)) * 100 if (wins + losses) > 0 else 0
    fig.add_annotation(
        text=f"{win_percentage:.1f}%",
        x=0.5, y=0.5,
        font=dict(size=20, color="black"),
        showarrow=False
    )
    
    return fig

def create_player_detail_charts(player: Dict) -> go.Figure:
    """
    Create detailed charts for an individual player
    
    Args:
        player: Player data dictionary
        
    Returns:
        Plotly figure object
    """
    # Create a figure with 2 subplots
    fig = make_subplots(
        rows=1, cols=2,
        subplot_titles=(
            f"Batting Performance: {player.get('name', 'Player')}",
            f"Bowling Performance: {player.get('name', 'Player')}"
        ),
        specs=[[{"type": "bar"}, {"type": "bar"}]]
    )
    
    # Batting metrics
    batting = player.get('batting_stats', {})
    batting_metrics = [
        {"name": "Runs", "value": batting.get('runs', 0)},
        {"name": "Average", "value": batting.get('average', 0)},
        {"name": "Strike Rate", "value": batting.get('strike_rate', 0)},
        {"name": "Fours", "value": batting.get('fours', 0)},
        {"name": "Sixes", "value": batting.get('sixes', 0)},
        {"name": "Fifties", "value": batting.get('fifties', 0)},
        {"name": "Hundreds", "value": batting.get('hundreds', 0)}
    ]
    
    # Bowling metrics
    bowling = player.get('bowling_stats', {})
    bowling_metrics = [
        {"name": "Wickets", "value": bowling.get('wickets', 0)},
        {"name": "Economy", "value": bowling.get('economy', 0)},
        {"name": "Average", "value": bowling.get('average', 0)},
        {"name": "3+ Wicket Hauls", "value": bowling.get('three_plus', 0)}
    ]
    
    # Add batting trace
    fig.add_trace(
        go.Bar(
            x=[m["name"] for m in batting_metrics],
            y=[m["value"] for m in batting_metrics],
            name="Batting",
            marker_color="#1f77b4"
        ),
        row=1, col=1
    )
    
    # Add bowling trace
    fig.add_trace(
        go.Bar(
            x=[m["name"] for m in bowling_metrics],
            y=[m["value"] for m in bowling_metrics],
            name="Bowling",
            marker_color="#2ca02c"
        ),
        row=1, col=2
    )
    
    # Update layout
    fig.update_layout(
        height=500,
        showlegend=False,
        title_text=f"Detailed Performance for {player.get('name', 'Player')}",
        font=dict(size=12)
    )
    
    return fig

def create_team_comparison_chart(teams_data: Dict, metric: str) -> go.Figure:
    """
    Create a chart comparing teams based on a specific metric
    
    Args:
        teams_data: Dictionary of team data
        metric: Metric to compare (e.g., 'total_runs', 'win_percentage')
        
    Returns:
        Plotly figure object
    """
    # Extract team names and metric values
    team_names = []
    metric_values = []
    
    for team_name, team_info in teams_data.get('teams', {}).items():
        team_names.append(team_name)
        
        if metric == 'win_percentage':
            # Calculate win percentage
            perf = team_info.get('performance', {})
            wins = perf.get('wins', 0)
            losses = perf.get('losses', 0)
            total_matches = wins + losses
            
            win_pct = (wins / total_matches * 100) if total_matches > 0 else 0
            metric_values.append(win_pct)
        else:
            # Direct metric lookup
            metric_path = metric.split('.')
            value = team_info
            for key in metric_path:
                if isinstance(value, dict) and key in value:
                    value = value[key]
                else:
                    value = 0
                    break
            
            metric_values.append(value)
    
    # Create the bar chart
    fig = px.bar(
        x=team_names,
        y=metric_values,
        title=f"Team Comparison by {metric.replace('_', ' ').title()}",
        color=team_names,
        labels={'x': 'Team', 'y': metric.replace('_', ' ').title()}
    )
    
    # Customize layout
    fig.update_layout(
        xaxis_title="Team",
        yaxis_title=metric.replace('_', ' ').title(),
        legend_title="Team",
        font=dict(size=12),
        height=500
    )
    
    return fig

def create_player_contribution_chart(player: Dict, team_metrics: Dict) -> go.Figure:
    """
    Create a chart showing a player's contribution to team performance
    
    Args:
        player: Player data dictionary
        team_metrics: Team aggregate metrics
        
    Returns:
        Plotly figure object
    """
    # Calculate contribution percentages
    runs_pct = 0
    if team_metrics.get("total_runs", 0) > 0:
        player_runs = player.get('batting_stats', {}).get('runs', 0)
        runs_pct = (player_runs / team_metrics["total_runs"]) * 100
    
    wickets_pct = 0
    if team_metrics.get("total_wickets", 0) > 0:
        player_wickets = player.get('bowling_stats', {}).get('wickets', 0)
        wickets_pct = (player_wickets / team_metrics["total_wickets"]) * 100
    
    boundaries_pct = 0
    total_boundaries = team_metrics.get("total_fours", 0) + team_metrics.get("total_sixes", 0)
    if total_boundaries > 0:
        player_fours = player.get('batting_stats', {}).get('fours', 0)
        player_sixes = player.get('batting_stats', {}).get('sixes', 0)
        player_boundaries = player_fours + player_sixes
        boundaries_pct = (player_boundaries / total_boundaries) * 100
    
    # Create data for the chart
    categories = ['Runs', 'Wickets', 'Boundaries']
    values = [runs_pct, wickets_pct, boundaries_pct]
    
    # Create the bar chart
    fig = px.bar(
        x=categories,
        y=values,
        title=f"Contribution of {player.get('name', 'Player')} to Team Performance",
        color=categories,
        labels={'x': 'Category', 'y': 'Contribution (%)'}
    )
    
    # Add percentage labels on bars
    fig.update_traces(texttemplate='%{y:.1f}%', textposition='outside')
    
    # Customize layout
    fig.update_layout(
        xaxis_title="Category",
        yaxis_title="Contribution (%)",
        font=dict(size=12),
        height=400,
        yaxis_range=[0, 100]
    )
    
    return fig

def create_ipl_timeline_chart(players_data: Dict, stat: str = "runs") -> go.Figure:
    """
    Create an IPL timeline chart showing player performance over seasons
    
    Args:
        players_data: Dictionary of player data
        stat: Statistic to display ('runs', 'wickets', etc.)
        
    Returns:
        Plotly figure object
    """
    # This is a placeholder function since we don't have season-by-season data
    # In a real implementation, you would parse the season data from the scraped information
    
    fig = go.Figure()
    fig.add_annotation(
        text=f"IPL Timeline data for {stat} is not available in the current dataset",
        xref="paper", yref="paper",
        x=0.5, y=0.5, showarrow=False,
        font=dict(size=16)
    )
    
    return fig

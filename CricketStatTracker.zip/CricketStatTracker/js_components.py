import streamlit as st

def load_audio_visual_feedback():
    """
    Load JavaScript for audio-visual feedback on user interactions.
    This adds hover effects and clickable sounds to certain elements.
    """
    # Define our JavaScript for audio and visual effects
    js_code = """
    <script>
    // Audio files in base64 format (short click sound)
    const clickSound = new Audio("data:audio/mp3;base64,SUQzBAAAAAABEVRYWFgAAAAtAAADY29tbWVudABCaWdTb3VuZEJhbmsuY29tIC8gQ29udmVydGVyOiBMYXZmNTguMTYuMTAwAABUSVQyAAAAHgAAQ2xpY2sgU291bmQgRWZmZWN0IFNGRSBDT01QVVRFUgBUWUVSAAAADQAAAHd3dy5mcmVlc2ZmeAAA//uQZAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAWGluZwAAAA8AAAACAAACiADT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09P///////////////////////////////////////////8AAAAKTEFNRTMuMTAwBFsAAAAALCAAABRIJAT5jgAAAgAAAoiGXu8xAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA//uQZAAP8AAAf4AAAAgAAA/wAAABAAAB/gAAACAAAD/AAAAETEFNRTMuMTAwVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVQ==");
    
    // Short hover sound
    const hoverSound = new Audio("data:audio/mp3;base64,SUQzBAAAAAABEVRYWFgAAAAtAAADY29tbWVudABCaWdTb3VuZEJhbmsuY29tIC8gQ29udmVydGVyOiBMYXZmNTguMTYuMTAwAABUSVQyAAAAHgAAQ2xpY2sgU291bmQgRWZmZWN0IFNGRSBDT01QVVRFUgBUWUVSAAAADQAAAHd3dy5mcmVlc2ZmeAAA//uQZAAP8AAAf4AAAAgAAA/wAAABAAAB/gAAACAAAD/AAAAETEFNRTMuMTAwBFsAAAAALSAAABRIJAN0MAAAAQAAAA3QjWsZAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA//uQZAAP8AAAf4AAAAgAAA/wAAABAAAB/gAAACAAAD/AAAAETEFNRTMuMTAwVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVQ==");
    
    // Add our visual effect styles (CSS)
    const styleElement = document.createElement('style');
    styleElement.innerHTML = `
      /* Visual feedback styles */
      .streamlit-expanderHeader:hover, 
      .stButton>button:hover,
      .stSelectbox:hover,
      .stMultiSelect:hover {
        transform: scale(1.02);
        transition: transform 0.2s;
        box-shadow: 0 4px 8px rgba(0,0,0,0.1);
      }
      
      /* Add highlight effect for dataframes */
      .stDataFrame tr:hover {
        background-color: rgba(64, 164, 241, 0.2) !important;
        transition: background-color 0.2s;
      }
      
      /* Button click effect */
      .stButton>button:active {
        transform: scale(0.95);
      }
      
      /* Dynamic hover border for team selection */
      .stSelectbox:hover select {
        border-color: #f63366 !important;
      }
    `;
    document.head.appendChild(styleElement);
    
    // Add event listeners for audio feedback
    function addAudioEffects() {
      // Buttons for click sound
      const buttons = document.querySelectorAll('.stButton>button');
      buttons.forEach(button => {
        button.addEventListener('click', () => {
          clickSound.currentTime = 0;
          clickSound.play();
        });
      });
      
      // Expanders, selectboxes for hover sound
      const interactiveElements = document.querySelectorAll('.streamlit-expanderHeader, .stSelectbox select, .stMultiSelect select');
      interactiveElements.forEach(element => {
        element.addEventListener('mouseenter', () => {
          hoverSound.currentTime = 0;
          hoverSound.volume = 0.3; // Lower volume for hover
          hoverSound.play();
        });
      });
    }
    
    // Run immediately and also watch for DOM changes
    addAudioEffects();
    
    // Use MutationObserver to apply effects to new elements
    const observer = new MutationObserver(mutations => {
      mutations.forEach(mutation => {
        if (mutation.addedNodes.length) {
          addAudioEffects();
        }
      });
    });
    
    observer.observe(document.body, { childList: true, subtree: true });
    </script>
    """
    
    # Inject our JavaScript into the Streamlit app
    st.components.v1.html(js_code, height=0)

def add_element_animations():
    """
    Add CSS animations to make elements fade in when they appear
    """
    # Define our CSS animation
    animation_css = """
    <style>
    /* Fade-in animation for various elements */
    .stDataFrame, .stSelectbox, .stButton, .stHeader, .stMarkdown, .streamlit-expanderHeader {
        animation: fadeIn 0.6s ease-in-out;
    }
    
    @keyframes fadeIn {
        from { opacity: 0; transform: translateY(10px); }
        to { opacity: 1; transform: translateY(0); }
    }
    
    /* Staggered fade-in for player cards */
    .element-container {
        animation-name: fadeIn;
        animation-duration: 0.8s;
        animation-fill-mode: both;
    }
    
    .element-container:nth-child(3n+1) { animation-delay: 0.1s; }
    .element-container:nth-child(3n+2) { animation-delay: 0.2s; }
    .element-container:nth-child(3n+3) { animation-delay: 0.3s; }
    </style>
    """
    
    # Inject the CSS
    st.markdown(animation_css, unsafe_allow_html=True)

def add_visual_enhancements():
    """
    Add visual enhancements for the IPL theme
    """
    # Add cricket-themed styling
    cricket_css = """
    <style>
    /* Cricket theme colors and enhancements */
    .stApp {
        background-image: linear-gradient(to bottom, rgba(255,255,255,0.95), rgba(255,255,255,0.97)), 
                          url("https://img.freepik.com/free-vector/cricket-elements-collection_23-2147686554.jpg?w=900&t=st=1617293935~exp=1617294535~hmac=8f5c7d1d437dbb37c12fab4b41c49fadaf63b7ea11d817855c45ec29a85e1583");
        background-size: 400px;
        background-position: center;
        background-repeat: repeat;
    }
    
    /* Title styling */
    h1 {
        text-shadow: 1px 1px 2px rgba(0,0,0,0.1);
        color: #1E3A8A;
    }
    
    /* Highlight stats in dataframes */
    .stDataFrame td:nth-child(2):not(:empty) {
        font-weight: bold;
        color: #1E3A8A;
    }
    
    /* Team colors for selectbox */
    .stSelectbox select {
        border-left: 4px solid #3366cc;
    }
    
    /* Custom team colors - can be expanded for all teams */
    .team-csk { color: #FFFF00 !important; } /* Chennai Super Kings */
    .team-mi { color: #004BA0 !important; } /* Mumbai Indians */
    .team-rcb { color: #EC1C24 !important; } /* Royal Challengers */
    
    /* Cricket ball animation for loading spinner */
    .stSpinner > div {
        border-radius: 50%;
        background-color: #C8102E !important;
        background-image: radial-gradient(circle, #ffffff 0%, #C8102E 35%);
    }
    </style>
    """
    
    # Inject the CSS
    st.markdown(cricket_css, unsafe_allow_html=True)
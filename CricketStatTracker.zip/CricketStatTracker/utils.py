import logging
from typing import Dict, List, Any, Tuple
import database as db

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

def save_data(players_data: Dict, teams_data: Dict) -> bool:
    """
    Save data to the database
    
    Args:
        players_data: Dictionary of player data
        teams_data: Dictionary of team data
        
    Returns:
        True if successful, False otherwise
    """
    try:
        # Save teams first
        for team_name, team_data in teams_data.get("teams", {}).items():
            db.save_team(team_data)
        
        # Then save players
        for player_id, player_data in players_data.items():
            team_name = player_data.get("team", "Unknown")
            db.save_player(player_data, team_name)
            
        logger.info("Data saved successfully to database")
        return True
    except Exception as e:
        logger.error(f"Error saving data to database: {str(e)}")
        return False

def load_data() -> Tuple[Dict, Dict]:
    """
    Load data from the database
    
    Returns:
        Tuple of (players_data, teams_data)
    """
    try:
        # Get all teams and players from database
        teams_data = db.get_all_teams()
        players_data = db.get_all_players()
        
        logger.info("Data loaded successfully from database")
        return players_data, teams_data
    except Exception as e:
        logger.error(f"Error loading data from database: {str(e)}")
        return {}, {}

def get_player_by_name(players_data: Dict, name: str) -> Dict:
    """
    Find a player by name (case-insensitive partial match)
    
    Args:
        players_data: Dictionary of player data
        name: Player name to search for
        
    Returns:
        Player data dictionary or empty dict if not found
    """
    name_lower = name.lower()
    
    for player_id, player_data in players_data.items():
        player_name = player_data.get('name', '').lower()
        if name_lower in player_name:
            return player_data
    
    return {}

def filter_players(
    players_data: Dict, 
    team: str = None, 
    role: str = None, 
    min_matches: int = 0,
    min_runs: int = 0,
    min_wickets: int = 0
) -> Dict[str, Dict]:
    """
    Filter players based on criteria
    
    Args:
        players_data: Dictionary of player data
        team: Filter by team name
        role: Filter by player role
        min_matches: Minimum matches played
        min_runs: Minimum runs scored
        min_wickets: Minimum wickets taken
        
    Returns:
        Filtered dictionary of player data
    """
    filtered_data = {}
    
    for player_id, player_data in players_data.items():
        # Apply team filter
        if team and player_data.get('team') != team:
            continue
            
        # Apply role filter
        if role and player_data.get('role') != role:
            continue
            
        # Apply matches filter
        if player_data.get('matches_played', 0) < min_matches:
            continue
            
        # Apply runs filter
        if player_data.get('batting_stats', {}).get('runs', 0) < min_runs:
            continue
            
        # Apply wickets filter
        if player_data.get('bowling_stats', {}).get('wickets', 0) < min_wickets:
            continue
            
        # Include player if they passed all filters
        filtered_data[player_id] = player_data
    
    return filtered_data

def format_number(number: Any) -> str:
    """
    Format a number for display
    
    Args:
        number: Number to format
        
    Returns:
        Formatted string
    """
    if number is None:
        return "N/A"
        
    try:
        if isinstance(number, (int, float)):
            if number == int(number):
                return f"{int(number):,}"
            return f"{number:,.2f}"
        return str(number)
    except:
        return str(number)

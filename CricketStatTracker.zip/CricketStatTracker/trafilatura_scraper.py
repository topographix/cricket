import logging
import time
import json
import re
import trafilatura
from typing import Dict, Any, List, Optional
import random

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Constants for scraping
CRICINFO_TEAMS_URL = "https://www.espncricinfo.com/ipl"
CRICINFO_PLAYER_STATS_URL = "https://www.espncricinfo.com/ci/content/player/index.html?country=6"
CRICBUZZ_TEAMS_URL = "https://www.cricbuzz.com/cricket-series/indian-premier-league-2024/teams"

# List of IPL teams for 2024
IPL_TEAMS_2024 = [
    "Chennai Super Kings",
    "Delhi Capitals",
    "Gujarat Titans",
    "Kolkata Knight Riders",
    "Lucknow Super Giants",
    "Mumbai Indians",
    "Punjab Kings",
    "Rajasthan Royals",
    "Royal Challengers Bengaluru",
    "Sunrisers Hyderabad"
]

# Team colors and abbreviations
TEAM_COLORS = {
    "Chennai Super Kings": "#FFFF00",  # Yellow
    "Delhi Capitals": "#0078BC",  # Blue
    "Gujarat Titans": "#1C1C1C",  # Black
    "Kolkata Knight Riders": "#3A225D",  # Purple
    "Lucknow Super Giants": "#A72056",  # Maroon
    "Mumbai Indians": "#004BA0",  # Blue
    "Punjab Kings": "#ED1C24",  # Red
    "Rajasthan Royals": "#2F9BE3",  # Blue
    "Royal Challengers Bengaluru": "#EC1C24",  # Red
    "Sunrisers Hyderabad": "#F7A721"  # Orange
}

TEAM_ABBREVIATIONS = {
    "Chennai Super Kings": "CSK",
    "Delhi Capitals": "DC",
    "Gujarat Titans": "GT",
    "Kolkata Knight Riders": "KKR",
    "Lucknow Super Giants": "LSG",
    "Mumbai Indians": "MI",
    "Punjab Kings": "PBKS",
    "Rajasthan Royals": "RR",
    "Royal Challengers Bengaluru": "RCB",
    "Sunrisers Hyderabad": "SRH"
}

# Sample data for team performance
TEAM_PERFORMANCE = {
    "Chennai Super Kings": {"matches_played": 218, "wins": 130, "losses": 88, "titles": 5},
    "Delhi Capitals": {"matches_played": 216, "wins": 101, "losses": 115, "titles": 0},
    "Gujarat Titans": {"matches_played": 34, "wins": 23, "losses": 11, "titles": 1},
    "Kolkata Knight Riders": {"matches_played": 226, "wins": 115, "losses": 111, "titles": 2},
    "Lucknow Super Giants": {"matches_played": 34, "wins": 18, "losses": 16, "titles": 0},
    "Mumbai Indians": {"matches_played": 237, "wins": 132, "losses": 105, "titles": 5},
    "Punjab Kings": {"matches_played": 222, "wins": 98, "losses": 124, "titles": 0},
    "Rajasthan Royals": {"matches_played": 196, "wins": 96, "losses": 100, "titles": 1},
    "Royal Challengers Bengaluru": {"matches_played": 233, "wins": 109, "losses": 124, "titles": 0},
    "Sunrisers Hyderabad": {"matches_played": 152, "wins": 74, "losses": 78, "titles": 1}
}

# Sample data for team owners and home grounds
TEAM_DETAILS = {
    "Chennai Super Kings": {"owner": "Chennai Super Kings Cricket Ltd.", "home_ground": "M. A. Chidambaram Stadium", "captain": "Ruturaj Gaikwad"},
    "Delhi Capitals": {"owner": "GMR Group & JSW Group", "home_ground": "Arun Jaitley Stadium", "captain": "Rishabh Pant"},
    "Gujarat Titans": {"owner": "CVC Capital Partners", "home_ground": "Narendra Modi Stadium", "captain": "Shubman Gill"},
    "Kolkata Knight Riders": {"owner": "Red Chillies Entertainment", "home_ground": "Eden Gardens", "captain": "Shreyas Iyer"},
    "Lucknow Super Giants": {"owner": "RPSG Group", "home_ground": "BRSABV Ekana Cricket Stadium", "captain": "KL Rahul"},
    "Mumbai Indians": {"owner": "Reliance Industries", "home_ground": "Wankhede Stadium", "captain": "Hardik Pandya"},
    "Punjab Kings": {"owner": "Mohit Burman, Ness Wadia", "home_ground": "IS Bindra Stadium", "captain": "Sam Curran"},
    "Rajasthan Royals": {"owner": "Manoj Badale", "home_ground": "Sawai Mansingh Stadium", "captain": "Sanju Samson"},
    "Royal Challengers Bengaluru": {"owner": "United Spirits", "home_ground": "M. Chinnaswamy Stadium", "captain": "Faf du Plessis"},
    "Sunrisers Hyderabad": {"owner": "Sun TV Network", "home_ground": "Rajiv Gandhi Intl. Cricket Stadium", "captain": "Pat Cummins"}
}

# Player roles for sample data
PLAYER_ROLES = [
    "Batsman", "Bowler", "All-rounder", "Wicket-keeper", "Wicket-keeper Batsman"
]

# Sample player dataset with key players from each team
SAMPLE_PLAYERS = {
    "Chennai Super Kings": [
        {"name": "Ruturaj Gaikwad", "role": "Batsman", "matches_played": 52, "age": "27", 
         "batting_stats": {"runs": 1797, "average": 39.06, "strike_rate": 135.88, "highest": "101*", "fours": 165, "sixes": 64, "fifties": 14, "hundreds": 1},
         "bowling_stats": {"wickets": 0, "economy": 0, "average": 0, "best": "0/0", "three_plus": 0}},
        {"name": "MS Dhoni", "role": "Wicket-keeper Batsman", "matches_played": 250, "age": "42", 
         "batting_stats": {"runs": 5082, "average": 38.79, "strike_rate": 135.95, "highest": "84*", "fours": 347, "sixes": 239, "fifties": 24, "hundreds": 0},
         "bowling_stats": {"wickets": 0, "economy": 0, "average": 0, "best": "0/0", "three_plus": 0}},
        {"name": "Ravindra Jadeja", "role": "All-rounder", "matches_played": 225, "age": "35", 
         "batting_stats": {"runs": 2692, "average": 26.65, "strike_rate": 128.41, "highest": "62*", "fours": 195, "sixes": 92, "fifties": 3, "hundreds": 0},
         "bowling_stats": {"wickets": 152, "economy": 7.62, "average": 29.69, "best": "5/16", "three_plus": 8}},
        {"name": "Moeen Ali", "role": "All-rounder", "matches_played": 47, "age": "36", 
         "batting_stats": {"runs": 909, "average": 23.31, "strike_rate": 143.23, "highest": "93", "fours": 67, "sixes": 52, "fifties": 4, "hundreds": 0},
         "bowling_stats": {"wickets": 24, "economy": 7.98, "average": 32.25, "best": "3/7", "three_plus": 1}},
        {"name": "Deepak Chahar", "role": "Bowler", "matches_played": 74, "age": "31", 
         "batting_stats": {"runs": 145, "average": 13.18, "strike_rate": 124.14, "highest": "39*", "fours": 16, "sixes": 5, "fifties": 0, "hundreds": 0},
         "bowling_stats": {"wickets": 72, "economy": 7.76, "average": 28.21, "best": "4/13", "three_plus": 4}},
        {"name": "Shivam Dube", "role": "All-rounder", "matches_played": 57, "age": "30", 
         "batting_stats": {"runs": 1186, "average": 30.41, "strike_rate": 146.97, "highest": "95*", "fours": 73, "sixes": 86, "fifties": 7, "hundreds": 0},
         "bowling_stats": {"wickets": 5, "economy": 9.78, "average": 45.80, "best": "1/5", "three_plus": 0}},
        {"name": "Devon Conway", "role": "Batsman", "matches_played": 23, "age": "32", 
         "batting_stats": {"runs": 924, "average": 46.20, "strike_rate": 141.12, "highest": "92*", "fours": 87, "sixes": 34, "fifties": 9, "hundreds": 0},
         "bowling_stats": {"wickets": 0, "economy": 0, "average": 0, "best": "0/0", "three_plus": 0}}
    ],
    "Mumbai Indians": [
        {"name": "Rohit Sharma", "role": "Batsman", "matches_played": 243, "age": "37", 
         "batting_stats": {"runs": 6211, "average": 29.58, "strike_rate": 130.35, "highest": "109*", "fours": 554, "sixes": 257, "fifties": 42, "hundreds": 1, "dot_balls": 1876, "singles": 2045, "doubles": 412, "threes": 63, "balls_faced": 4763, "not_outs": 17},
         "bowling_stats": {"wickets": 15, "economy": 8.72, "average": 31.60, "best": "2/6", "three_plus": 0}},
        {"name": "Jasprit Bumrah", "role": "Bowler", "matches_played": 120, "age": "30", 
         "batting_stats": {"runs": 56, "average": 8.00, "strike_rate": 84.85, "highest": "16*", "fours": 3, "sixes": 3, "fifties": 0, "hundreds": 0},
         "bowling_stats": {"wickets": 157, "economy": 7.39, "average": 23.30, "best": "5/10", "three_plus": 10, "dot_balls": 1123, "overs_bowled": 475.4, "runs_conceded": 3520, "maidens": 8, "balls_bowled": 2854, "wides": 63, "no_balls": 12, "hat_tricks": 1, "four_wicket_hauls": 3, "five_wicket_hauls": 2}},
        {"name": "Suryakumar Yadav", "role": "Batsman", "matches_played": 139, "age": "33", 
         "batting_stats": {"runs": 3249, "average": 30.37, "strike_rate": 143.31, "highest": "103*", "fours": 296, "sixes": 160, "fifties": 21, "hundreds": 1},
         "bowling_stats": {"wickets": 0, "economy": 0, "average": 0, "best": "0/0", "three_plus": 0}},
        {"name": "Hardik Pandya", "role": "All-rounder", "matches_played": 123, "age": "30", 
         "batting_stats": {"runs": 2309, "average": 30.38, "strike_rate": 151.31, "highest": "91", "fours": 164, "sixes": 128, "fifties": 9, "hundreds": 0},
         "bowling_stats": {"wickets": 53, "economy": 8.98, "average": 31.29, "best": "3/20", "three_plus": 1}},
        {"name": "Ishan Kishan", "role": "Wicket-keeper Batsman", "matches_played": 94, "age": "25", 
         "batting_stats": {"runs": 2331, "average": 28.43, "strike_rate": 135.52, "highest": "99", "fours": 208, "sixes": 118, "fifties": 14, "hundreds": 0},
         "bowling_stats": {"wickets": 0, "economy": 0, "average": 0, "best": "0/0", "three_plus": 0}},
        {"name": "Tilak Varma", "role": "Batsman", "matches_played": 28, "age": "21", 
         "batting_stats": {"runs": 740, "average": 38.95, "strike_rate": 145.10, "highest": "84*", "fours": 55, "sixes": 37, "fifties": 5, "hundreds": 0},
         "bowling_stats": {"wickets": 0, "economy": 0, "average": 0, "best": "0/0", "three_plus": 0}}
    ],
    "Kolkata Knight Riders": [
        {"name": "Andre Russell", "role": "All-rounder", "matches_played": 113, "age": "36", 
         "batting_stats": {"runs": 2262, "average": 29.00, "strike_rate": 173.44, "highest": "88*", "fours": 138, "sixes": 188, "fifties": 10, "hundreds": 0},
         "bowling_stats": {"wickets": 96, "economy": 9.13, "average": 25.81, "best": "5/15", "three_plus": 5}},
        {"name": "Shreyas Iyer", "role": "Batsman", "matches_played": 113, "age": "29", 
         "batting_stats": {"runs": 2935, "average": 32.97, "strike_rate": 126.62, "highest": "96", "fours": 264, "sixes": 99, "fifties": 20, "hundreds": 0},
         "bowling_stats": {"wickets": 0, "economy": 0, "average": 0, "best": "0/0", "three_plus": 0}},
        {"name": "Sunil Narine", "role": "All-rounder", "matches_played": 162, "age": "36", 
         "batting_stats": {"runs": 1144, "average": 14.85, "strike_rate": 156.71, "highest": "75", "fours": 93, "sixes": 89, "fifties": 4, "hundreds": 0},
         "bowling_stats": {"wickets": 163, "economy": 6.73, "average": 24.83, "best": "5/19", "three_plus": 8}},
        {"name": "Nitish Rana", "role": "Batsman", "matches_played": 107, "age": "29", 
         "batting_stats": {"runs": 2594, "average": 28.19, "strike_rate": 135.24, "highest": "87", "fours": 233, "sixes": 120, "fifties": 18, "hundreds": 0},
         "bowling_stats": {"wickets": 9, "economy": 8.36, "average": 46.33, "best": "2/11", "three_plus": 0}},
        {"name": "Rinku Singh", "role": "Batsman", "matches_played": 40, "age": "26", 
         "batting_stats": {"runs": 725, "average": 36.25, "strike_rate": 146.46, "highest": "67*", "fours": 54, "sixes": 32, "fifties": 3, "hundreds": 0},
         "bowling_stats": {"wickets": 0, "economy": 0, "average": 0, "best": "0/0", "three_plus": 0}},
        {"name": "Varun Chakravarthy", "role": "Bowler", "matches_played": 53, "age": "32", 
         "batting_stats": {"runs": 15, "average": 7.50, "strike_rate": 83.33, "highest": "10", "fours": 2, "sixes": 0, "fifties": 0, "hundreds": 0},
         "bowling_stats": {"wickets": 69, "economy": 7.66, "average": 24.68, "best": "5/20", "three_plus": 2}}
    ],
    "Royal Challengers Bengaluru": [
        {"name": "Virat Kohli", "role": "Batsman", "matches_played": 237, "age": "35", 
         "batting_stats": {"runs": 7263, "average": 37.25, "strike_rate": 130.02, "highest": "113", "fours": 643, "sixes": 234, "fifties": 50, "hundreds": 7},
         "bowling_stats": {"wickets": 4, "economy": 8.71, "average": 92.00, "best": "2/25", "three_plus": 0}},
        {"name": "Faf du Plessis", "role": "Batsman", "matches_played": 122, "age": "39", 
         "batting_stats": {"runs": 3645, "average": 36.45, "strike_rate": 134.12, "highest": "96", "fours": 309, "sixes": 143, "fifties": 29, "hundreds": 0},
         "bowling_stats": {"wickets": 0, "economy": 0, "average": 0, "best": "0/0", "three_plus": 0}},
        {"name": "Mohammed Siraj", "role": "Bowler", "matches_played": 82, "age": "30", 
         "batting_stats": {"runs": 107, "average": 8.23, "strike_rate": 105.94, "highest": "14*", "fours": 7, "sixes": 7, "fifties": 0, "hundreds": 0},
         "bowling_stats": {"wickets": 93, "economy": 8.78, "average": 29.33, "best": "4/21", "three_plus": 3}},
        {"name": "Glenn Maxwell", "role": "All-rounder", "matches_played": 124, "age": "35", 
         "batting_stats": {"runs": 2719, "average": 25.65, "strike_rate": 155.37, "highest": "115", "fours": 180, "sixes": 169, "fifties": 11, "hundreds": 5},
         "bowling_stats": {"wickets": 34, "economy": 8.39, "average": 36.29, "best": "2/15", "three_plus": 0}},
        {"name": "Dinesh Karthik", "role": "Wicket-keeper Batsman", "matches_played": 238, "age": "38", 
         "batting_stats": {"runs": 4516, "average": 26.89, "strike_rate": 135.11, "highest": "97*", "fours": 374, "sixes": 198, "fifties": 20, "hundreds": 0},
         "bowling_stats": {"wickets": 0, "economy": 0, "average": 0, "best": "0/0", "three_plus": 0}},
        {"name": "Cameron Green", "role": "All-rounder", "matches_played": 25, "age": "24", 
         "batting_stats": {"runs": 555, "average": 27.75, "strike_rate": 141.88, "highest": "100*", "fours": 48, "sixes": 26, "fifties": 1, "hundreds": 1},
         "bowling_stats": {"wickets": 20, "economy": 8.87, "average": 30.45, "best": "2/22", "three_plus": 0}}
    ],
    "Sunrisers Hyderabad": [
        {"name": "Abhishek Sharma", "role": "All-rounder", "matches_played": 57, "age": "23", 
         "batting_stats": {"runs": 1270, "average": 24.90, "strike_rate": 142.38, "highest": "100", "fours": 105, "sixes": 67, "fifties": 5, "hundreds": 1},
         "bowling_stats": {"wickets": 7, "economy": 8.47, "average": 39.57, "best": "2/13", "three_plus": 0}},
        {"name": "Bhuvneshwar Kumar", "role": "Bowler", "matches_played": 154, "age": "34", 
         "batting_stats": {"runs": 247, "average": 13.72, "strike_rate": 115.42, "highest": "24", "fours": 22, "sixes": 9, "fifties": 0, "hundreds": 0},
         "bowling_stats": {"wickets": 170, "economy": 7.34, "average": 26.08, "best": "5/19", "three_plus": 8}},
        {"name": "Heinrich Klaasen", "role": "Wicket-keeper Batsman", "matches_played": 23, "age": "32", 
         "batting_stats": {"runs": 702, "average": 41.29, "strike_rate": 174.69, "highest": "104", "fours": 44, "sixes": 56, "fifties": 5, "hundreds": 1},
         "bowling_stats": {"wickets": 0, "economy": 0, "average": 0, "best": "0/0", "three_plus": 0}}
    ],
    "Rajasthan Royals": [
        {"name": "Sanju Samson", "role": "Wicket-keeper Batsman", "matches_played": 152, "age": "29", 
         "batting_stats": {"runs": 3888, "average": 29.68, "strike_rate": 137.19, "highest": "119", "fours": 330, "sixes": 191, "fifties": 20, "hundreds": 3},
         "bowling_stats": {"wickets": 0, "economy": 0, "average": 0, "best": "0/0", "three_plus": 0}},
        {"name": "Jos Buttler", "role": "Wicket-keeper Batsman", "matches_played": 91, "age": "33", 
         "batting_stats": {"runs": 3223, "average": 38.83, "strike_rate": 145.29, "highest": "124", "fours": 287, "sixes": 159, "fifties": 15, "hundreds": 6},
         "bowling_stats": {"wickets": 0, "economy": 0, "average": 0, "best": "0/0", "three_plus": 0}},
        {"name": "Yuzvendra Chahal", "role": "Bowler", "matches_played": 143, "age": "33", 
         "batting_stats": {"runs": 36, "average": 4.00, "strike_rate": 85.71, "highest": "8", "fours": 4, "sixes": 1, "fifties": 0, "hundreds": 0},
         "bowling_stats": {"wickets": 187, "economy": 7.67, "average": 21.69, "best": "5/40", "three_plus": 9}}
    ],
    "Delhi Capitals": [
        {"name": "Rishabh Pant", "role": "Wicket-keeper Batsman", "matches_played": 98, "age": "26", 
         "batting_stats": {"runs": 3137, "average": 34.47, "strike_rate": 148.19, "highest": "128*", "fours": 304, "sixes": 133, "fifties": 16, "hundreds": 2},
         "bowling_stats": {"wickets": 0, "economy": 0, "average": 0, "best": "0/0", "three_plus": 0}},
        {"name": "Axar Patel", "role": "All-rounder", "matches_played": 141, "age": "30", 
         "batting_stats": {"runs": 1447, "average": 21.59, "strike_rate": 139.27, "highest": "65", "fours": 114, "sixes": 62, "fifties": 4, "hundreds": 0},
         "bowling_stats": {"wickets": 104, "economy": 7.39, "average": 31.85, "best": "4/21", "three_plus": 2}},
        {"name": "Kuldeep Yadav", "role": "Bowler", "matches_played": 81, "age": "29", 
         "batting_stats": {"runs": 92, "average": 8.36, "strike_rate": 97.87, "highest": "19", "fours": 12, "sixes": 1, "fifties": 0, "hundreds": 0},
         "bowling_stats": {"wickets": 95, "economy": 8.22, "average": 25.53, "best": "4/14", "three_plus": 6}}
    ],
    "Punjab Kings": [
        {"name": "Shikhar Dhawan", "role": "Batsman", "matches_played": 217, "age": "38", 
         "batting_stats": {"runs": 6617, "average": 35.36, "strike_rate": 127.38, "highest": "106*", "fours": 743, "sixes": 148, "fifties": 50, "hundreds": 2},
         "bowling_stats": {"wickets": 4, "economy": 8.75, "average": 34.25, "best": "1/7", "three_plus": 0}},
        {"name": "Sam Curran", "role": "All-rounder", "matches_played": 47, "age": "26", 
         "batting_stats": {"runs": 670, "average": 22.33, "strike_rate": 139.88, "highest": "55", "fours": 57, "sixes": 29, "fifties": 2, "hundreds": 0},
         "bowling_stats": {"wickets": 51, "economy": 9.22, "average": 28.14, "best": "4/11", "three_plus": 3}},
        {"name": "Arshdeep Singh", "role": "Bowler", "matches_played": 59, "age": "25", 
         "batting_stats": {"runs": 69, "average": 8.63, "strike_rate": 127.78, "highest": "10*", "fours": 6, "sixes": 4, "fifties": 0, "hundreds": 0},
         "bowling_stats": {"wickets": 76, "economy": 8.66, "average": 24.42, "best": "5/32", "three_plus": 3}}
    ],
    "Lucknow Super Giants": [
        {"name": "KL Rahul", "role": "Wicket-keeper Batsman", "matches_played": 119, "age": "32", 
         "batting_stats": {"runs": 4162, "average": 46.24, "strike_rate": 134.32, "highest": "132*", "fours": 357, "sixes": 179, "fifties": 35, "hundreds": 5},
         "bowling_stats": {"wickets": 0, "economy": 0, "average": 0, "best": "0/0", "three_plus": 0}},
        {"name": "Nicholas Pooran", "role": "Wicket-keeper Batsman", "matches_played": 61, "age": "28", 
         "batting_stats": {"runs": 1378, "average": 31.32, "strike_rate": 159.03, "highest": "89", "fours": 87, "sixes": 108, "fifties": 7, "hundreds": 0},
         "bowling_stats": {"wickets": 0, "economy": 0, "average": 0, "best": "0/0", "three_plus": 0}},
        {"name": "Mark Wood", "role": "Bowler", "matches_played": 14, "age": "34", 
         "batting_stats": {"runs": 5, "average": 2.50, "strike_rate": 71.43, "highest": "3", "fours": 0, "sixes": 0, "fifties": 0, "hundreds": 0},
         "bowling_stats": {"wickets": 22, "economy": 8.80, "average": 21.23, "best": "5/14", "three_plus": 2}}
    ],
    "Gujarat Titans": [
        {"name": "Shubman Gill", "role": "Batsman", "matches_played": 91, "age": "24", 
         "batting_stats": {"runs": 2790, "average": 38.22, "strike_rate": 133.24, "highest": "129", "fours": 274, "sixes": 87, "fifties": 15, "hundreds": 3},
         "bowling_stats": {"wickets": 0, "economy": 0, "average": 0, "best": "0/0", "three_plus": 0}},
        {"name": "Rashid Khan", "role": "All-rounder", "matches_played": 110, "age": "25", 
         "batting_stats": {"runs": 501, "average": 13.92, "strike_rate": 161.09, "highest": "34", "fours": 26, "sixes": 39, "fifties": 0, "hundreds": 0},
         "bowling_stats": {"wickets": 139, "economy": 6.63, "average": 21.25, "best": "4/24", "three_plus": 5}},
        {"name": "Mohammad Shami", "role": "Bowler", "matches_played": 104, "age": "33", 
         "batting_stats": {"runs": 84, "average": 6.00, "strike_rate": 94.38, "highest": "25", "fours": 11, "sixes": 2, "fifties": 0, "hundreds": 0},
         "bowling_stats": {"wickets": 127, "economy": 8.49, "average": 26.22, "best": "4/11", "three_plus": 8}}
    ]
}

def get_website_text_content(url: str) -> str:
    """
    This function takes a url and returns the main text content of the website.
    The text content is extracted using trafilatura and easier to understand.
    """
    try:
        # Send a request to the website
        downloaded = trafilatura.fetch_url(url)
        text = trafilatura.extract(downloaded)
        return text
    except Exception as e:
        logger.error(f"Error fetching content from {url}: {str(e)}")
        return ""

def scrape_ipl_teams() -> Dict[str, Any]:
    """
    Get information about IPL teams using the sample data
    
    Returns:
        Dict with team information
    """
    logger.info("Starting to scrape IPL teams data")
    teams_data = {
        "teams": {},
        "last_refresh": time.strftime("%Y-%m-%d %H:%M:%S")
    }
    
    try:
        # Use the sample team data instead of scraping
        for team_name in IPL_TEAMS_2024:
            performance = TEAM_PERFORMANCE.get(team_name, {})
            details = TEAM_DETAILS.get(team_name, {})
            
            teams_data["teams"][team_name] = {
                "name": team_name,
                "home_ground": details.get("home_ground", "N/A"),
                "owner": details.get("owner", "N/A"),
                "captain": details.get("captain", "N/A"),
                "performance": {
                    "matches_played": performance.get("matches_played", 0),
                    "wins": performance.get("wins", 0),
                    "losses": performance.get("losses", 0),
                    "titles": performance.get("titles", 0)
                },
                "color": TEAM_COLORS.get(team_name, "#000000"),
                "abbreviation": TEAM_ABBREVIATIONS.get(team_name, team_name[:3].upper())
            }
            
        logger.info(f"Generated data for {len(teams_data['teams'])} IPL teams")
        return teams_data
        
    except Exception as e:
        logger.error(f"Error generating IPL teams data: {str(e)}")
        return {"teams": {}, "last_refresh": time.strftime("%Y-%m-%d %H:%M:%S")}

def _enhance_batting_stats(batting_stats: Dict) -> Dict:
    """
    Add detailed batting metrics to a player's batting stats if not already present
    
    Args:
        batting_stats: Existing batting statistics dictionary
        
    Returns:
        Enhanced batting statistics with additional metrics
    """
    # Calculate approximately from existing stats if not present
    if "balls_faced" not in batting_stats:
        # Estimate balls faced based on runs and strike rate
        if batting_stats.get("strike_rate", 0) > 0:
            batting_stats["balls_faced"] = int(batting_stats.get("runs", 0) * 100 / batting_stats.get("strike_rate", 120))
        else:
            batting_stats["balls_faced"] = batting_stats.get("runs", 0)
    
    if "singles" not in batting_stats:
        # Estimate singles (runs not from boundaries)
        fours = batting_stats.get("fours", 0)
        sixes = batting_stats.get("sixes", 0)
        total_runs = batting_stats.get("runs", 0)
        boundary_runs = (fours * 4) + (sixes * 6)
        non_boundary_runs = max(0, total_runs - boundary_runs)  # Ensure it's not negative
        
        # Distribute non-boundary runs between singles, doubles, and threes
        singles_pct = 0.70  # 70% of non-boundary runs are singles
        doubles_pct = 0.25  # 25% of non-boundary runs are doubles
        threes_pct = 0.05   # 5% of non-boundary runs are threes
        
        batting_stats["singles"] = int(non_boundary_runs * singles_pct)
        batting_stats["doubles"] = int((non_boundary_runs * doubles_pct) / 2)  # Divide by 2 to get number of doubles
        batting_stats["threes"] = int((non_boundary_runs * threes_pct) / 3)  # Divide by 3 to get number of threes
        
    if "dot_balls" not in batting_stats:
        # Estimate dot balls based on batting style and typical dot ball percentage
        total_balls = batting_stats.get("balls_faced", 0)
        singles = batting_stats.get("singles", 0)
        doubles = batting_stats.get("doubles", 0)
        threes = batting_stats.get("threes", 0)
        fours = batting_stats.get("fours", 0)
        sixes = batting_stats.get("sixes", 0)
        
        # Calculate total scoring shots (each scoring shot is one ball)
        scoring_shots = singles + doubles + threes + fours + sixes
        
        # Ensure dot_balls is a reasonable value - dot balls typically make up 30-50% of deliveries faced
        estimated_dot_pct = 0.40  # 40% of balls are typically dot balls for most batsmen
        
        if total_balls > 0:
            # Calculate directly if we have total balls and scoring shots
            # Dot balls = total balls minus scoring shots, but never more than 50% of total balls
            # and never negative
            batting_stats["dot_balls"] = max(0, min(total_balls - scoring_shots, int(total_balls * 0.50)))
        else:
            # Fallback estimation based on runs scored
            batting_stats["dot_balls"] = int(batting_stats.get("runs", 0) * 0.25)  # Lower percentage as fallback
        
    if "not_outs" not in batting_stats:
        # Estimate not outs based on highest score notation (* indicates not out)
        highest = batting_stats.get("highest", "0")
        is_not_out = "*" in highest
        innings = batting_stats.get("fifties", 0) + batting_stats.get("hundreds", 0) + 10  # Rough estimate of innings
        batting_stats["not_outs"] = int(innings * 0.2) if is_not_out else int(innings * 0.1)  # 20% not outs if historically not out in highest, else 10%
    
    return batting_stats

def _enhance_bowling_stats(bowling_stats: Dict) -> Dict:
    """
    Add detailed bowling metrics to a player's bowling stats if not already present
    
    Args:
        bowling_stats: Existing bowling statistics dictionary
        
    Returns:
        Enhanced bowling statistics with additional metrics
    """
    # Skip for players with no wickets (non-bowlers)
    if bowling_stats.get("wickets", 0) == 0:
        bowling_stats.update({
            "dot_balls": 0,
            "overs_bowled": 0,
            "runs_conceded": 0,
            "maidens": 0,
            "balls_bowled": 0,
            "wides": 0,
            "no_balls": 0,
            "hat_tricks": 0,
            "four_wicket_hauls": 0,
            "five_wicket_hauls": 0
        })
        return bowling_stats
    
    # Calculate detailed stats if not present
    if "overs_bowled" not in bowling_stats:
        wickets = bowling_stats.get("wickets", 0)
        economy = bowling_stats.get("economy", 8.0)
        runs = bowling_stats.get("runs_conceded", 0)
        
        # If runs_conceded is not provided, estimate from economy and wickets
        if runs == 0:
            # Rough estimate: average bowler bowls ~24 balls per wicket
            estimated_balls = wickets * 24  # Slightly more aggressive estimate
            estimated_overs = estimated_balls / 6
            runs = int(estimated_overs * economy)
            bowling_stats["runs_conceded"] = runs
        
        # If overs are not provided, estimate from economy and runs
        if economy > 0:
            estimated_overs = runs / economy
            bowling_stats["overs_bowled"] = round(estimated_overs, 1)
            full_overs = int(estimated_overs)
            partial_balls = int((estimated_overs - full_overs) * 6)
            bowling_stats["balls_bowled"] = (full_overs * 6) + partial_balls
        else:
            # Fallback if economy is 0
            bowling_stats["overs_bowled"] = wickets * 3  # Revised estimate
            bowling_stats["balls_bowled"] = int(bowling_stats["overs_bowled"] * 6)
    
    if "dot_balls" not in bowling_stats:
        # Estimate dot balls - in T20 cricket, dot ball % depends on economy rate
        total_balls = bowling_stats.get("balls_bowled", 0)
        economy = bowling_stats.get("economy", 8.0)
        
        # Better bowlers (lower economy) have higher dot ball percentage
        # Economy less than 7 runs per over tends to have more dot balls
        dot_ball_pct = 0.55 if economy < 7.0 else 0.48 if economy < 8.5 else 0.40
        
        if total_balls > 0:
            # Calculate and ensure it's a reasonable value (never more than 90% of total balls)
            # More accurate calculation
            bowling_stats["dot_balls"] = min(int(total_balls * dot_ball_pct), int(total_balls * 0.9))
        else:
            # Fallback based on wickets
            bowling_stats["dot_balls"] = int(bowling_stats.get("wickets", 0) * 12)  # ~12 dot balls per wicket
    
    if "maidens" not in bowling_stats:
        # Estimate maidens (frequency depends on economy)
        overs = bowling_stats.get("overs_bowled", 0)
        economy = bowling_stats.get("economy", 8.0)
        
        # Better economy = more maidens (adjust for T20 cricket where maidens are rare)
        if economy < 6.0:  # Exceptional bowlers
            maiden_frequency = 15  # 1 maiden per 15 overs
        elif economy < 7.5:  # Good bowlers
            maiden_frequency = 25  # 1 maiden per 25 overs
        else:  # Average to poor economy
            maiden_frequency = 40  # 1 maiden per 40 overs
            
        bowling_stats["maidens"] = max(0, int(overs / maiden_frequency))
    
    if "wides" not in bowling_stats:
        # Estimate wides based on accuracy (economy as proxy)
        overs = bowling_stats.get("overs_bowled", 0)
        economy = bowling_stats.get("economy", 8.0)
        
        # More expensive bowlers tend to bowl more wides
        wide_rate = 0.2 if economy < 7.0 else 0.3 if economy < 8.5 else 0.4
        bowling_stats["wides"] = int(overs * wide_rate)
    
    if "no_balls" not in bowling_stats:
        # Estimate no balls (rare in professional cricket)
        overs = bowling_stats.get("overs_bowled", 0)
        bowling_stats["no_balls"] = max(0, int(overs * 0.05))  # ~1 no ball per 20 overs
    
    if "hat_tricks" not in bowling_stats:
        # Estimate hat tricks (extremely rare)
        wickets = bowling_stats.get("wickets", 0)
        # Only allocate for bowlers with lots of wickets and even then rarely
        bowling_stats["hat_tricks"] = 1 if wickets > 120 and random.random() < 0.2 else 0
    
    # Extract/estimate 4 and 5 wicket hauls from 'best' string or number of wickets
    if "four_wicket_hauls" not in bowling_stats or "five_wicket_hauls" not in bowling_stats:
        best = bowling_stats.get("best", "0/0")
        best_wickets = int(best.split('/')[0]) if '/' in best else 0
        three_plus = bowling_stats.get("three_plus", 0)
        wickets = bowling_stats.get("wickets", 0)
        
        # More accurate estimation based on total wickets
        if best_wickets >= 5:
            # For bowlers with a 5w best
            bowling_stats["five_wicket_hauls"] = max(1, int(wickets / 50))  # ~1 five-for per 50 wickets
            bowling_stats["four_wicket_hauls"] = max(0, int(wickets / 30) - bowling_stats["five_wicket_hauls"])  # ~1 four-for per 30 wickets
        elif best_wickets == 4:
            # For bowlers with a 4w best
            bowling_stats["five_wicket_hauls"] = 0
            bowling_stats["four_wicket_hauls"] = max(1, int(wickets / 35))  # ~1 four-for per 35 wickets
        else:
            # Default for bowlers with 3w or less as best
            bowling_stats["five_wicket_hauls"] = 0
            bowling_stats["four_wicket_hauls"] = 0
    
    return bowling_stats

def scrape_player_stats(team_name: str) -> Dict[str, Dict]:
    """
    Get player statistics for a specific IPL team using sample data
    
    Args:
        team_name: Name of the IPL team
        
    Returns:
        Dictionary with player data
    """
    logger.info(f"Getting player stats for {team_name}")
    players_data = {}
    
    try:
        # Use sample player data for the specified team
        if team_name in SAMPLE_PLAYERS:
            team_players = SAMPLE_PLAYERS[team_name]
            team_url_name = team_name.lower().replace(' ', '-')
            
            for i, player in enumerate(team_players):
                player_id = f"{team_url_name}-{player['name'].lower().replace(' ', '-')}"
                
                # Enhance batting and bowling stats with additional metrics
                batting_stats = _enhance_batting_stats(player["batting_stats"])
                bowling_stats = _enhance_bowling_stats(player["bowling_stats"])
                
                players_data[player_id] = {
                    "id": player_id,
                    "name": player["name"],
                    "team": team_name,
                    "role": player["role"],
                    "matches_played": player["matches_played"],
                    "age": player["age"],
                    "batting_stats": batting_stats,
                    "bowling_stats": bowling_stats
                }
            
            # Generate additional players to reach a total of 16-18 players per team
            target_players = random.randint(16, 18)  # Random number between 16-18 players
            additional_needed = max(0, target_players - len(team_players))
            
            if additional_needed > 0:
                logger.info(f"Adding {additional_needed} additional players for {team_name} to reach {target_players} total")
                
                # Different roles weighted by typical team composition
                role_weights = {
                    "Batsman": 0.35,            # ~35% are batsmen
                    "Bowler": 0.35,             # ~35% are bowlers
                    "All-rounder": 0.20,        # ~20% are all-rounders
                    "Wicket-keeper Batsman": 0.10  # ~10% are wicket-keepers
                }
                
                # Generate weighted role selection function
                roles = list(role_weights.keys())
                weights = list(role_weights.values())
                
                # Actual cricket player name combinations to prevent unrealistic names
                player_names = [
                    "Virat Kohli", "Rohit Sharma", "KL Rahul", "Rishabh Pant", "Hardik Pandya",
                    "Ravindra Jadeja", "Jasprit Bumrah", "Mohammed Shami", "Shikhar Dhawan", "Shreyas Iyer",
                    "Yuzvendra Chahal", "Bhuvneshwar Kumar", "Ravichandran Ashwin", "Kuldeep Yadav", 
                    "Ajinkya Rahane", "Suryakumar Yadav", "Ishan Kishan", "Axar Patel", "Shardul Thakur", 
                    "Deepak Chahar", "Krunal Pandya", "Mayank Agarwal", "Sanju Samson", "Ruturaj Gaikwad", 
                    "Venkatesh Iyer", "Devdutt Padikkal", "Prithvi Shaw", "Shubman Gill", "Umran Malik",
                    "Washington Sundar", "T Natarajan", "Mohammed Siraj", "Prasidh Krishna", "Avesh Khan",
                    "Arshdeep Singh", "Ravi Bishnoi", "Rahul Chahar", "Varun Chakravarthy", "Harshal Patel",
                    "Riyan Parag", "Rahul Tripathi", "Nitish Rana", "Abhishek Sharma", "Tilak Varma",
                    "Yashasvi Jaiswal", "Shahbaz Ahmed", "Shahrukh Khan", "Deepak Hooda", "Dinesh Karthik"
                ]
                # These are all actual players, no more fictional combinations
                
                for i in range(additional_needed):
                    # Use actual cricket player names from our list
                    unused_names = [name for name in player_names if not any(name.lower() in p_id.lower() for p_id in players_data.keys())]
                    if unused_names:
                        player_name = random.choice(unused_names)
                    else:
                        # Fallback in case we run out of unique names
                        player_name = f"Player {i+1}"
                    
                    # Create a URL-friendly player ID
                    player_id = f"{team_url_name}-{player_name.lower().replace(' ', '-')}-{len(team_players) + i + 1}"
                    
                    # Use weighted role distribution
                    role = random.choices(roles, weights=weights, k=1)[0]
                    
                    # Most additional players will have fewer matches (squad rotation players)
                    matches = random.randint(5, 40)  # These are typically less experienced players
                    
                    # Generate role-appropriate stats
                    if role == "Batsman" or role == "Wicket-keeper Batsman":
                        # Batsmen have better batting stats
                        basic_batting_stats = {
                            "runs": random.randint(100, 800),  # Lower runs for squad players
                            "average": round(random.uniform(15, 30), 2),
                            "strike_rate": round(random.uniform(120, 150), 2),
                            "highest": f"{random.randint(25, 70)}{'*' if random.random() > 0.5 else ''}",
                            "fours": random.randint(10, 60),
                            "sixes": random.randint(3, 30),
                            "fifties": random.randint(0, 3),
                            "hundreds": 0  # Squad players rarely have centuries
                        }
                        basic_bowling_stats = {
                            "wickets": 0,  # Pure batsmen typically don't bowl
                            "economy": 0,
                            "average": 0,
                            "best": "0/0",
                            "three_plus": 0
                        }
                    elif role == "Bowler":
                        # Bowlers have better bowling stats
                        basic_batting_stats = {
                            "runs": random.randint(20, 200),  # Bowlers score fewer runs
                            "average": round(random.uniform(8, 15), 2),
                            "strike_rate": round(random.uniform(100, 130), 2),
                            "highest": f"{random.randint(10, 30)}{'*' if random.random() > 0.7 else ''}",
                            "fours": random.randint(2, 15),
                            "sixes": random.randint(1, 10),
                            "fifties": 0,
                            "hundreds": 0
                        }
                        basic_bowling_stats = {
                            "wickets": random.randint(5, 40),
                            "economy": round(random.uniform(7, 9.5), 2),
                            "average": round(random.uniform(22, 35), 2),
                            "best": f"{random.randint(1, 3)}/{random.randint(10, 30)}",
                            "three_plus": random.randint(0, 2)
                        }
                    else:  # All-rounder
                        # All-rounders have balanced stats
                        basic_batting_stats = {
                            "runs": random.randint(100, 500),
                            "average": round(random.uniform(15, 25), 2),
                            "strike_rate": round(random.uniform(120, 140), 2),
                            "highest": f"{random.randint(20, 60)}{'*' if random.random() > 0.5 else ''}",
                            "fours": random.randint(10, 40),
                            "sixes": random.randint(5, 20),
                            "fifties": random.randint(0, 2),
                            "hundreds": 0
                        }
                        basic_bowling_stats = {
                            "wickets": random.randint(5, 25),
                            "economy": round(random.uniform(7.5, 9.5), 2),
                            "average": round(random.uniform(25, 35), 2),
                            "best": f"{random.randint(1, 3)}/{random.randint(15, 35)}",
                            "three_plus": random.randint(0, 1)
                        }
                    
                    # Enhance stats with additional metrics
                    enhanced_batting_stats = _enhance_batting_stats(basic_batting_stats)
                    enhanced_bowling_stats = _enhance_bowling_stats(basic_bowling_stats)
                    
                    players_data[player_id] = {
                        "id": player_id,
                        "name": player_name,
                        "team": team_name,
                        "role": role,
                        "matches_played": matches,
                        "age": str(random.randint(21, 33)),  # Young to mid-career
                        "batting_stats": enhanced_batting_stats,
                        "bowling_stats": enhanced_bowling_stats
                    }
        else:
            # Generate random player data for teams not in sample data
            logger.warning(f"No sample data for {team_name}, generating random player data")
            # Generate 16-18 players per team
            num_players = random.randint(16, 18)
            
            # Different roles weighted by typical team composition
            role_weights = {
                "Batsman": 0.35,            # ~35% are batsmen
                "Bowler": 0.35,             # ~35% are bowlers
                "All-rounder": 0.20,        # ~20% are all-rounders
                "Wicket-keeper Batsman": 0.10  # ~10% are wicket-keepers
            }
            
            # Generate weighted role selection function
            roles = list(role_weights.keys())
            weights = list(role_weights.values())
            
            # Actual cricket player name combinations to prevent unrealistic names
            player_names = [
                "Virat Kohli", "Rohit Sharma", "KL Rahul", "Rishabh Pant", "Hardik Pandya",
                "Ravindra Jadeja", "Jasprit Bumrah", "Mohammed Shami", "Shikhar Dhawan", "Shreyas Iyer",
                "Yuzvendra Chahal", "Bhuvneshwar Kumar", "Ravichandran Ashwin", "Kuldeep Yadav", 
                "Ajinkya Rahane", "Suryakumar Yadav", "Ishan Kishan", "Axar Patel", "Shardul Thakur", 
                "Deepak Chahar", "Krunal Pandya", "Mayank Agarwal", "Sanju Samson", "Ruturaj Gaikwad", 
                "Venkatesh Iyer", "Devdutt Padikkal", "Prithvi Shaw", "Shubman Gill", "Umran Malik",
                "Washington Sundar", "T Natarajan", "Mohammed Siraj", "Prasidh Krishna", "Avesh Khan",
                "Arshdeep Singh", "Ravi Bishnoi", "Rahul Chahar", "Varun Chakravarthy", "Harshal Patel",
                "Riyan Parag", "Rahul Tripathi", "Nitish Rana", "Abhishek Sharma", "Tilak Varma"
            ]
            
            # Make copies of player names since we'll be removing used ones
            available_names = player_names.copy()
            
            for i in range(num_players):
                # Select a real player name if available
                if available_names:
                    player_name = random.choice(available_names)
                    available_names.remove(player_name)  # Remove to avoid duplicates
                else:
                    # Fallback in case we run out of unique names
                    player_name = f"Player {i+1}"
                
                # Create URL-friendly player ID
                player_id = f"{team_name.lower().replace(' ', '-')}-{player_name.lower().replace(' ', '-')}-{i+1}"
                role = random.choices(roles, weights=weights, k=1)[0]
                matches = random.randint(5, 100)
                
                # Generate role-appropriate stats similar to above
                if role == "Batsman" or role == "Wicket-keeper Batsman":
                    # Batsmen stats
                    basic_batting_stats = {
                        "runs": random.randint(100, 2000),
                        "average": round(random.uniform(20, 40), 2),
                        "strike_rate": round(random.uniform(120, 150), 2),
                        "highest": f"{random.randint(30, 100)}{'*' if random.random() > 0.5 else ''}",
                        "fours": random.randint(10, 200),
                        "sixes": random.randint(5, 100),
                        "fifties": random.randint(0, 10),
                        "hundreds": random.randint(0, 2)
                    }
                    basic_bowling_stats = {
                        "wickets": 0,
                        "economy": 0,
                        "average": 0,
                        "best": "0/0",
                        "three_plus": 0
                    }
                elif role == "Bowler":
                    # Bowlers stats
                    basic_batting_stats = {
                        "runs": random.randint(50, 300),
                        "average": round(random.uniform(10, 20), 2),
                        "strike_rate": round(random.uniform(100, 130), 2),
                        "highest": f"{random.randint(15, 40)}{'*' if random.random() > 0.7 else ''}",
                        "fours": random.randint(5, 25),
                        "sixes": random.randint(2, 15),
                        "fifties": random.randint(0, 1),
                        "hundreds": 0
                    }
                    basic_bowling_stats = {
                        "wickets": random.randint(20, 100),
                        "economy": round(random.uniform(6, 9), 2),
                        "average": round(random.uniform(20, 30), 2),
                        "best": f"{random.randint(2, 5)}/{random.randint(10, 30)}",
                        "three_plus": random.randint(1, 5)
                    }
                else:  # All-rounder
                    # All-rounders stats
                    basic_batting_stats = {
                        "runs": random.randint(500, 1500),
                        "average": round(random.uniform(15, 30), 2),
                        "strike_rate": round(random.uniform(120, 145), 2),
                        "highest": f"{random.randint(40, 80)}{'*' if random.random() > 0.5 else ''}",
                        "fours": random.randint(30, 120),
                        "sixes": random.randint(20, 70),
                        "fifties": random.randint(1, 6),
                        "hundreds": random.randint(0, 1)
                    }
                    basic_bowling_stats = {
                        "wickets": random.randint(15, 70),
                        "economy": round(random.uniform(7, 9), 2),
                        "average": round(random.uniform(22, 32), 2),
                        "best": f"{random.randint(2, 4)}/{random.randint(15, 30)}",
                        "three_plus": random.randint(0, 3)
                    }
                
                # Enhance stats with additional metrics
                enhanced_batting_stats = _enhance_batting_stats(basic_batting_stats)
                enhanced_bowling_stats = _enhance_bowling_stats(basic_bowling_stats)
                
                players_data[player_id] = {
                    "id": player_id,
                    "name": player_name,
                    "team": team_name,
                    "role": role,
                    "matches_played": matches,
                    "age": str(random.randint(22, 38)),
                    "batting_stats": enhanced_batting_stats,
                    "bowling_stats": enhanced_bowling_stats
                }
        
        logger.info(f"Generated data for {len(players_data)} players of {team_name}")
        return players_data
    
    except Exception as e:
        logger.error(f"Error generating player data for {team_name}: {str(e)}")
        return {}
import os
import logging
from sqlalchemy import create_engine, Column, Integer, String, Float, ForeignKey, JSON, DateTime, Boolean
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker, relationship
import datetime
from typing import Dict, List, Any, Optional

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Get database URL from environment
DATABASE_URL = os.environ.get('DATABASE_URL')
if not DATABASE_URL:
    logger.error("No DATABASE_URL environment variable found.")
    raise ValueError("DATABASE_URL environment variable is required")

# Create SQLAlchemy engine and session
engine = create_engine(DATABASE_URL)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()

class Team(Base):
    """SQLAlchemy model for IPL teams"""
    __tablename__ = "teams"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, unique=True, index=True)
    home_ground = Column(String, nullable=True)
    owner = Column(String, nullable=True)
    captain = Column(String, nullable=True)
    matches_played = Column(Integer, default=0)
    wins = Column(Integer, default=0)
    losses = Column(Integer, default=0)
    titles = Column(Integer, default=0)
    last_updated = Column(DateTime, default=datetime.datetime.utcnow)

    # Relationship with players
    players = relationship("Player", back_populates="team")

    def to_dict(self) -> Dict[str, Any]:
        """Convert team data to dictionary"""
        return {
            "id": self.id,
            "name": self.name,
            "home_ground": self.home_ground or "N/A",
            "owner": self.owner or "N/A",
            "captain": self.captain or "N/A",
            "performance": {
                "matches_played": self.matches_played,
                "wins": self.wins,
                "losses": self.losses,
                "titles": self.titles
            }
        }

class MatchPrediction(Base):
    """SQLAlchemy model for match predictions and actual results"""
    __tablename__ = "match_predictions"
    
    id = Column(Integer, primary_key=True, index=True)
    match_id = Column(String, unique=True, index=True)
    team1 = Column(String, nullable=False)
    team2 = Column(String, nullable=False)
    predicted_winner = Column(String, nullable=False)
    win_probability = Column(Float, default=0.0)
    actual_winner = Column(String, nullable=True)
    match_date = Column(DateTime, nullable=True)
    venue = Column(String, nullable=True)
    was_correct = Column(Boolean, nullable=True)
    created_at = Column(DateTime, default=datetime.datetime.utcnow)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert match prediction to dictionary"""
        return {
            "id": self.id,
            "match_id": self.match_id,
            "team1": self.team1,
            "team2": self.team2,
            "predicted_winner": self.predicted_winner,
            "win_probability": self.win_probability,
            "actual_winner": self.actual_winner,
            "match_date": self.match_date.isoformat() if self.match_date else None,
            "venue": self.venue,
            "was_correct": self.was_correct,
            "created_at": self.created_at.isoformat()
        }


class SeasonalStats(Base):
    """SQLAlchemy model for historical IPL seasonal statistics"""
    __tablename__ = "seasonal_stats"
    
    id = Column(Integer, primary_key=True, index=True)
    season_year = Column(Integer, index=True, nullable=False)
    team_name = Column(String, index=True, nullable=False)
    matches_played = Column(Integer, default=0)
    wins = Column(Integer, default=0)
    losses = Column(Integer, default=0)
    draws = Column(Integer, default=0)
    points = Column(Integer, default=0)
    position = Column(Integer, nullable=True)
    reached_playoffs = Column(Boolean, default=False)
    won_title = Column(Boolean, default=False)
    
    # Team stats
    runs_scored = Column(Integer, default=0)
    wickets_taken = Column(Integer, default=0)
    runs_conceded = Column(Integer, default=0)
    wickets_lost = Column(Integer, default=0)
    boundaries_hit = Column(Integer, default=0)
    sixes_hit = Column(Integer, default=0)
    
    # Additional metrics
    net_run_rate = Column(Float, default=0.0)
    batting_avg = Column(Float, default=0.0)
    bowling_avg = Column(Float, default=0.0)
    batting_strike_rate = Column(Float, default=0.0)
    bowling_economy = Column(Float, default=0.0)
    
    # Top performers (stored as JSON)
    top_performers = Column(JSON, default={})
    
    # Creation timestamp
    created_at = Column(DateTime, default=datetime.datetime.utcnow)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert seasonal stats to dictionary"""
        return {
            "id": self.id,
            "season_year": self.season_year,
            "team_name": self.team_name,
            "matches_played": self.matches_played,
            "wins": self.wins,
            "losses": self.losses,
            "draws": self.draws,
            "points": self.points,
            "position": self.position,
            "reached_playoffs": self.reached_playoffs,
            "won_title": self.won_title,
            "runs_scored": self.runs_scored,
            "wickets_taken": self.wickets_taken,
            "runs_conceded": self.runs_conceded,
            "wickets_lost": self.wickets_lost,
            "boundaries_hit": self.boundaries_hit,
            "sixes_hit": self.sixes_hit,
            "net_run_rate": self.net_run_rate,
            "batting_avg": self.batting_avg,
            "bowling_avg": self.bowling_avg,
            "batting_strike_rate": self.batting_strike_rate,
            "bowling_economy": self.bowling_economy,
            "top_performers": self.top_performers,
            "created_at": self.created_at.isoformat()
        }
        
class PlayerSeasonalStats(Base):
    """SQLAlchemy model for player performance over seasons"""
    __tablename__ = "player_seasonal_stats"
    
    id = Column(Integer, primary_key=True, index=True)
    player_id = Column(String, index=True, nullable=False)
    player_name = Column(String, index=True, nullable=False)
    season_year = Column(Integer, index=True, nullable=False)
    team_name = Column(String, index=True, nullable=False)
    role = Column(String, nullable=True)
    matches_played = Column(Integer, default=0)
    
    # Batting stats
    batting_stats = Column(JSON, default={})
    
    # Bowling stats
    bowling_stats = Column(JSON, default={})
    
    # Fielding stats
    fielding_stats = Column(JSON, default={})
    
    # Special performances and awards
    awards = Column(JSON, default=[])
    
    # Creation timestamp
    created_at = Column(DateTime, default=datetime.datetime.utcnow)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert player seasonal stats to dictionary"""
        return {
            "id": self.id,
            "player_id": self.player_id,
            "player_name": self.player_name,
            "season_year": self.season_year,
            "team_name": self.team_name,
            "role": self.role,
            "matches_played": self.matches_played,
            "batting_stats": self.batting_stats,
            "bowling_stats": self.bowling_stats,
            "fielding_stats": self.fielding_stats,
            "awards": self.awards,
            "created_at": self.created_at.isoformat()
        }


class Player(Base):
    """SQLAlchemy model for IPL players"""
    __tablename__ = "players"

    id = Column(Integer, primary_key=True, index=True)
    player_id = Column(String, unique=True, index=True)
    name = Column(String, index=True)
    team_id = Column(Integer, ForeignKey("teams.id"))
    role = Column(String, nullable=True)
    matches_played = Column(Integer, default=0)
    age = Column(String, nullable=True)
    
    # Batting stats stored as JSON
    batting_stats = Column(JSON, default={})
    
    # Bowling stats stored as JSON
    bowling_stats = Column(JSON, default={})
    
    # Last updated timestamp
    last_updated = Column(DateTime, default=datetime.datetime.utcnow)
    
    # Relationship with team
    team = relationship("Team", back_populates="players")

    def to_dict(self) -> Dict[str, Any]:
        """Convert player data to dictionary"""
        return {
            "id": self.player_id,
            "name": self.name,
            "team": self.team.name if self.team else "N/A",
            "role": self.role or "N/A",
            "matches_played": self.matches_played,
            "age": self.age or "N/A",
            "batting_stats": self.batting_stats or {
                "runs": 0,
                "average": 0.0,
                "strike_rate": 0.0,
                "highest": "0",
                "fours": 0,
                "sixes": 0,
                "fifties": 0,
                "hundreds": 0,
                "dot_balls": 0,
                "singles": 0,
                "doubles": 0,
                "threes": 0,
                "balls_faced": 0,
                "not_outs": 0
            },
            "bowling_stats": self.bowling_stats or {
                "wickets": 0,
                "economy": 0.0,
                "average": 0.0,
                "best": "0/0",
                "three_plus": 0,
                "dot_balls": 0,
                "overs_bowled": 0,
                "runs_conceded": 0,
                "maidens": 0,
                "balls_bowled": 0,
                "wides": 0,
                "no_balls": 0,
                "hat_tricks": 0,
                "four_wicket_hauls": 0,
                "five_wicket_hauls": 0
            }
        }

# Function to initialize database tables
def init_db():
    """Create database tables"""
    try:
        Base.metadata.create_all(bind=engine)
        logger.info("Database tables created successfully")
    except Exception as e:
        logger.error(f"Error creating database tables: {str(e)}")
        raise

# Database CRUD operations
def save_team(team_data: Dict[str, Any]) -> Team:
    """
    Save team data to database
    
    Args:
        team_data: Team information dictionary
        
    Returns:
        Team ORM model instance
    """
    db = SessionLocal()
    try:
        # Check if team already exists
        team = db.query(Team).filter(Team.name == team_data.get('name')).first()
        
        if not team:
            # Create new team
            team = Team(
                name=team_data.get('name'),
                home_ground=team_data.get('home_ground'),
                owner=team_data.get('owner'),
                captain=team_data.get('captain')
            )
            db.add(team)
        else:
            # Update existing team
            team.home_ground = team_data.get('home_ground', team.home_ground)
            team.owner = team_data.get('owner', team.owner)
            team.captain = team_data.get('captain', team.captain)
        
        # Update performance data
        performance = team_data.get('performance', {})
        team.matches_played = performance.get('matches_played', team.matches_played)
        team.wins = performance.get('wins', team.wins)
        team.losses = performance.get('losses', team.losses)
        team.titles = performance.get('titles', team.titles)
        team.last_updated = datetime.datetime.utcnow()
        
        db.commit()
        db.refresh(team)
        return team
    except Exception as e:
        db.rollback()
        logger.error(f"Error saving team data: {str(e)}")
        raise
    finally:
        db.close()

def save_player(player_data: Dict[str, Any], team_name: str) -> Player:
    """
    Save player data to database
    
    Args:
        player_data: Player information dictionary
        team_name: Name of the player's team
        
    Returns:
        Player ORM model instance
    """
    db = SessionLocal()
    try:
        # Find team by name
        team = db.query(Team).filter(Team.name == team_name).first()
        if not team:
            logger.warning(f"Team '{team_name}' not found, creating it")
            team = Team(name=team_name)
            db.add(team)
            db.commit()
            db.refresh(team)
        
        # Check if player already exists
        player = db.query(Player).filter(Player.player_id == player_data.get('id')).first()
        
        if not player:
            # Create new player
            player = Player(
                player_id=player_data.get('id'),
                name=player_data.get('name'),
                team_id=team.id,
                role=player_data.get('role'),
                matches_played=player_data.get('matches_played', 0),
                age=player_data.get('age'),
                batting_stats=player_data.get('batting_stats', {}),
                bowling_stats=player_data.get('bowling_stats', {})
            )
            db.add(player)
        else:
            # Update existing player
            player.name = player_data.get('name', player.name)
            player.team_id = team.id
            player.role = player_data.get('role', player.role)
            player.matches_played = player_data.get('matches_played', player.matches_played)
            player.age = player_data.get('age', player.age)
            player.batting_stats = player_data.get('batting_stats', player.batting_stats)
            player.bowling_stats = player_data.get('bowling_stats', player.bowling_stats)
        
        player.last_updated = datetime.datetime.utcnow()
        
        db.commit()
        db.refresh(player)
        return player
    except Exception as e:
        db.rollback()
        logger.error(f"Error saving player data: {str(e)}")
        raise
    finally:
        db.close()

def get_all_teams() -> Dict[str, Any]:
    """
    Get all teams from database
    
    Returns:
        Dictionary with team information
    """
    db = SessionLocal()
    try:
        teams = db.query(Team).all()
        teams_data = {
            "teams": {},
            "last_refresh": datetime.datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S")
        }
        
        for team in teams:
            teams_data["teams"][team.name] = team.to_dict()
        
        return teams_data
    except Exception as e:
        logger.error(f"Error getting teams data: {str(e)}")
        return {"teams": {}, "last_refresh": datetime.datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S")}
    finally:
        db.close()

def get_all_players() -> Dict[str, Dict]:
    """
    Get all players from database
    
    Returns:
        Dictionary with player information
    """
    db = SessionLocal()
    try:
        players = db.query(Player).all()
        players_data = {}
        
        for player in players:
            players_data[player.player_id] = player.to_dict()
        
        return players_data
    except Exception as e:
        logger.error(f"Error getting players data: {str(e)}")
        return {}
    finally:
        db.close()

def get_team_by_name(team_name: str) -> Optional[Team]:
    """
    Get team by name
    
    Args:
        team_name: Name of the team
        
    Returns:
        Team object or None if not found
    """
    db = SessionLocal()
    try:
        return db.query(Team).filter(Team.name == team_name).first()
    except Exception as e:
        logger.error(f"Error getting team by name: {str(e)}")
        return None
    finally:
        db.close()

def get_players_by_team(team_name: str) -> List[Player]:
    """
    Get all players for a team
    
    Args:
        team_name: Name of the team
        
    Returns:
        List of Player objects
    """
    db = SessionLocal()
    try:
        team = db.query(Team).filter(Team.name == team_name).first()
        if not team:
            return []
        
        return db.query(Player).filter(Player.team_id == team.id).all()
    except Exception as e:
        logger.error(f"Error getting players by team: {str(e)}")
        return []
    finally:
        db.close()

def get_player_by_id(player_id: str) -> Optional[Player]:
    """
    Get player by ID
    
    Args:
        player_id: Player ID
        
    Returns:
        Player object or None if not found
    """
    db = SessionLocal()
    try:
        return db.query(Player).filter(Player.player_id == player_id).first()
    except Exception as e:
        logger.error(f"Error getting player by ID: {str(e)}")
        return None
    finally:
        db.close()

def save_match_prediction(match_data: Dict[str, Any]) -> MatchPrediction:
    """
    Save match prediction to database
    
    Args:
        match_data: Match prediction data
        
    Returns:
        MatchPrediction ORM model instance
    """
    db = SessionLocal()
    try:
        # Generate a unique match ID if not provided
        if not match_data.get('match_id'):
            team1 = match_data.get('team1', '')
            team2 = match_data.get('team2', '')
            match_date = match_data.get('match_date', datetime.datetime.utcnow().isoformat())
            match_data['match_id'] = f"{team1.lower().replace(' ', '-')}-vs-{team2.lower().replace(' ', '-')}-{match_date}"
            
        # Check if prediction already exists for this match
        prediction = db.query(MatchPrediction).filter(MatchPrediction.match_id == match_data.get('match_id')).first()
        
        if not prediction:
            # Create new prediction
            prediction = MatchPrediction(
                match_id=match_data.get('match_id'),
                team1=match_data.get('team1'),
                team2=match_data.get('team2'),
                predicted_winner=match_data.get('predicted_winner'),
                win_probability=match_data.get('win_probability', 0.0),
                venue=match_data.get('venue')
            )
            
            # Set match date if provided
            if 'match_date' in match_data and match_data['match_date']:
                try:
                    if isinstance(match_data['match_date'], str):
                        prediction.match_date = datetime.datetime.fromisoformat(match_data['match_date'])
                    else:
                        prediction.match_date = match_data['match_date']
                except:
                    prediction.match_date = datetime.datetime.utcnow()
            
            db.add(prediction)
        else:
            # Update existing prediction if actual result not set yet
            if not prediction.actual_winner:
                prediction.predicted_winner = match_data.get('predicted_winner', prediction.predicted_winner)
                prediction.win_probability = match_data.get('win_probability', prediction.win_probability)
                prediction.venue = match_data.get('venue', prediction.venue)
        
        # Set actual winner if provided
        if 'actual_winner' in match_data and match_data['actual_winner']:
            prediction.actual_winner = match_data['actual_winner']
            prediction.was_correct = prediction.predicted_winner == prediction.actual_winner
        
        db.commit()
        db.refresh(prediction)
        return prediction
    except Exception as e:
        db.rollback()
        logger.error(f"Error saving match prediction: {str(e)}")
        raise
    finally:
        db.close()

def get_match_predictions(limit: int = 50) -> List[Dict[str, Any]]:
    """
    Get recent match predictions
    
    Args:
        limit: Maximum number of predictions to return
        
    Returns:
        List of match prediction dictionaries
    """
    db = SessionLocal()
    try:
        predictions = db.query(MatchPrediction).order_by(MatchPrediction.created_at.desc()).limit(limit).all()
        return [prediction.to_dict() for prediction in predictions]
    except Exception as e:
        logger.error(f"Error getting match predictions: {str(e)}")
        return []
    finally:
        db.close()

def get_prediction_accuracy() -> Dict[str, Any]:
    """
    Calculate prediction accuracy statistics
    
    Returns:
        Dictionary with accuracy statistics
    """
    db = SessionLocal()
    try:
        # Get all predictions that have actual results
        predictions = db.query(MatchPrediction).filter(MatchPrediction.actual_winner != None).all()
        
        if not predictions:
            return {
                "total_matches": 0,
                "correct_predictions": 0,
                "accuracy_percentage": 0,
                "team_accuracy": {}
            }
        
        # Calculate overall accuracy
        total = len(predictions)
        correct = sum(1 for p in predictions if p.was_correct)
        accuracy = (correct / total) * 100 if total > 0 else 0
        
        # Calculate accuracy by team
        teams_data = {}
        for p in predictions:
            # Team as predicted winner
            if p.predicted_winner not in teams_data:
                teams_data[p.predicted_winner] = {"total": 0, "correct": 0}
            teams_data[p.predicted_winner]["total"] += 1
            if p.was_correct:
                teams_data[p.predicted_winner]["correct"] += 1
        
        # Calculate percentages
        team_accuracy = {}
        for team, data in teams_data.items():
            team_accuracy[team] = {
                "total_predictions": data["total"],
                "correct_predictions": data["correct"],
                "accuracy_percentage": (data["correct"] / data["total"]) * 100 if data["total"] > 0 else 0
            }
        
        return {
            "total_matches": total,
            "correct_predictions": correct,
            "accuracy_percentage": accuracy,
            "team_accuracy": team_accuracy
        }
    except Exception as e:
        logger.error(f"Error calculating prediction accuracy: {str(e)}")
        return {
            "total_matches": 0,
            "correct_predictions": 0,
            "accuracy_percentage": 0,
            "team_accuracy": {}
        }
    finally:
        db.close()

def save_seasonal_stats(stats_data: Dict[str, Any]) -> SeasonalStats:
    """
    Save team seasonal statistics to database
    
    Args:
        stats_data: Seasonal statistics dictionary
        
    Returns:
        SeasonalStats ORM model instance
    """
    db = SessionLocal()
    try:
        # Check if season stats exist for this team and year
        stats = db.query(SeasonalStats).filter(
            SeasonalStats.team_name == stats_data.get('team_name'),
            SeasonalStats.season_year == stats_data.get('season_year')
        ).first()
        
        if not stats:
            # Create new seasonal stats entry
            stats = SeasonalStats(
                season_year=stats_data.get('season_year'),
                team_name=stats_data.get('team_name'),
                matches_played=stats_data.get('matches_played', 0),
                wins=stats_data.get('wins', 0),
                losses=stats_data.get('losses', 0),
                draws=stats_data.get('draws', 0),
                points=stats_data.get('points', 0),
                position=stats_data.get('position'),
                reached_playoffs=stats_data.get('reached_playoffs', False),
                won_title=stats_data.get('won_title', False),
                runs_scored=stats_data.get('runs_scored', 0),
                wickets_taken=stats_data.get('wickets_taken', 0),
                runs_conceded=stats_data.get('runs_conceded', 0),
                wickets_lost=stats_data.get('wickets_lost', 0),
                boundaries_hit=stats_data.get('boundaries_hit', 0),
                sixes_hit=stats_data.get('sixes_hit', 0),
                net_run_rate=stats_data.get('net_run_rate', 0.0),
                batting_avg=stats_data.get('batting_avg', 0.0),
                bowling_avg=stats_data.get('bowling_avg', 0.0),
                batting_strike_rate=stats_data.get('batting_strike_rate', 0.0),
                bowling_economy=stats_data.get('bowling_economy', 0.0),
                top_performers=stats_data.get('top_performers', {})
            )
            db.add(stats)
        else:
            # Update existing seasonal stats
            stats.matches_played = stats_data.get('matches_played', stats.matches_played)
            stats.wins = stats_data.get('wins', stats.wins)
            stats.losses = stats_data.get('losses', stats.losses)
            stats.draws = stats_data.get('draws', stats.draws)
            stats.points = stats_data.get('points', stats.points)
            stats.position = stats_data.get('position', stats.position)
            stats.reached_playoffs = stats_data.get('reached_playoffs', stats.reached_playoffs)
            stats.won_title = stats_data.get('won_title', stats.won_title)
            stats.runs_scored = stats_data.get('runs_scored', stats.runs_scored)
            stats.wickets_taken = stats_data.get('wickets_taken', stats.wickets_taken)
            stats.runs_conceded = stats_data.get('runs_conceded', stats.runs_conceded)
            stats.wickets_lost = stats_data.get('wickets_lost', stats.wickets_lost)
            stats.boundaries_hit = stats_data.get('boundaries_hit', stats.boundaries_hit)
            stats.sixes_hit = stats_data.get('sixes_hit', stats.sixes_hit)
            stats.net_run_rate = stats_data.get('net_run_rate', stats.net_run_rate)
            stats.batting_avg = stats_data.get('batting_avg', stats.batting_avg)
            stats.bowling_avg = stats_data.get('bowling_avg', stats.bowling_avg)
            stats.batting_strike_rate = stats_data.get('batting_strike_rate', stats.batting_strike_rate)
            stats.bowling_economy = stats_data.get('bowling_economy', stats.bowling_economy)
            stats.top_performers = stats_data.get('top_performers', stats.top_performers)
        
        db.commit()
        db.refresh(stats)
        return stats
    except Exception as e:
        db.rollback()
        logger.error(f"Error saving seasonal stats: {str(e)}")
        raise
    finally:
        db.close()

def save_player_seasonal_stats(player_stats: Dict[str, Any]) -> PlayerSeasonalStats:
    """
    Save player's seasonal statistics to database
    
    Args:
        player_stats: Player seasonal statistics dictionary
        
    Returns:
        PlayerSeasonalStats ORM model instance
    """
    db = SessionLocal()
    try:
        # Check if player season stats already exist
        stats = db.query(PlayerSeasonalStats).filter(
            PlayerSeasonalStats.player_id == player_stats.get('player_id'),
            PlayerSeasonalStats.season_year == player_stats.get('season_year')
        ).first()
        
        if not stats:
            # Create new player seasonal stats
            stats = PlayerSeasonalStats(
                player_id=player_stats.get('player_id'),
                player_name=player_stats.get('player_name'),
                season_year=player_stats.get('season_year'),
                team_name=player_stats.get('team_name'),
                role=player_stats.get('role'),
                matches_played=player_stats.get('matches_played', 0),
                batting_stats=player_stats.get('batting_stats', {}),
                bowling_stats=player_stats.get('bowling_stats', {}),
                fielding_stats=player_stats.get('fielding_stats', {}),
                awards=player_stats.get('awards', [])
            )
            db.add(stats)
        else:
            # Update existing player seasonal stats
            stats.player_name = player_stats.get('player_name', stats.player_name)
            stats.team_name = player_stats.get('team_name', stats.team_name)
            stats.role = player_stats.get('role', stats.role)
            stats.matches_played = player_stats.get('matches_played', stats.matches_played)
            stats.batting_stats = player_stats.get('batting_stats', stats.batting_stats)
            stats.bowling_stats = player_stats.get('bowling_stats', stats.bowling_stats)
            stats.fielding_stats = player_stats.get('fielding_stats', stats.fielding_stats)
            stats.awards = player_stats.get('awards', stats.awards)
        
        db.commit()
        db.refresh(stats)
        return stats
    except Exception as e:
        db.rollback()
        logger.error(f"Error saving player seasonal stats: {str(e)}")
        raise
    finally:
        db.close()

def get_team_seasonal_stats(team_name: str = None) -> List[Dict[str, Any]]:
    """
    Get team's seasonal statistics
    
    Args:
        team_name: Optional team name to filter by
        
    Returns:
        List of seasonal statistics dictionaries
    """
    db = SessionLocal()
    try:
        query = db.query(SeasonalStats)
        
        if team_name:
            query = query.filter(SeasonalStats.team_name == team_name)
            
        query = query.order_by(SeasonalStats.season_year)
        stats = query.all()
        
        return [s.to_dict() for s in stats]
    except Exception as e:
        logger.error(f"Error getting team seasonal stats: {str(e)}")
        return []
    finally:
        db.close()

def get_player_seasonal_stats(player_id: str = None, season_year: int = None) -> List[Dict[str, Any]]:
    """
    Get player's seasonal statistics
    
    Args:
        player_id: Optional player ID to filter by
        season_year: Optional season year to filter by
        
    Returns:
        List of player seasonal statistics dictionaries
    """
    db = SessionLocal()
    try:
        query = db.query(PlayerSeasonalStats)
        
        if player_id:
            query = query.filter(PlayerSeasonalStats.player_id == player_id)
            
        if season_year:
            query = query.filter(PlayerSeasonalStats.season_year == season_year)
            
        query = query.order_by(PlayerSeasonalStats.season_year)
        stats = query.all()
        
        return [s.to_dict() for s in stats]
    except Exception as e:
        logger.error(f"Error getting player seasonal stats: {str(e)}")
        return []
    finally:
        db.close()

def get_all_seasons() -> List[int]:
    """
    Get list of all seasons available in the database
    
    Returns:
        List of season years
    """
    db = SessionLocal()
    try:
        seasons = db.query(SeasonalStats.season_year).distinct().all()
        return [s[0] for s in seasons]
    except Exception as e:
        logger.error(f"Error getting all seasons: {str(e)}")
        return []
    finally:
        db.close()

# Initialize database when module is imported
init_db()
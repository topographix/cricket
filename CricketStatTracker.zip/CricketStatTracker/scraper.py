import requests
from bs4 import BeautifulSoup
import pandas as pd
import time
import random
import logging
import re
from typing import Dict, List, Any, Tuple

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Constants for scraping
IPL_TEAMS_URL = "https://www.iplt20.com/teams"
CRICBUZZ_BASE_URL = "https://www.cricbuzz.com"
STATS_URLS = {
    "players": "https://www.iplt20.com/stats/all-time",
    "teams": "https://www.iplt20.com/teams",
    "cricinfo_players": "https://www.espncricinfo.com/records/tournament/ipl",
    "cricbuzz_teams": "https://www.cricbuzz.com/cricket-series/5945/indian-premier-league-2023/teams"
}

# User agents for rotation
USER_AGENTS = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/14.1.1 Safari/605.1.15",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:89.0) Gecko/20100101 Firefox/89.0",
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/92.0.4515.107 Safari/537.36"
]

def get_random_headers():
    """Generate random headers to prevent being blocked"""
    return {
        "User-Agent": random.choice(USER_AGENTS),
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8",
        "Accept-Language": "en-US,en;q=0.5",
        "Connection": "keep-alive",
        "Upgrade-Insecure-Requests": "1",
        "Cache-Control": "max-age=0"
    }

def safe_request(url: str, max_retries: int = 3, delay: int = 2) -> requests.Response:
    """Make a request with automatic retries and error handling"""
    headers = get_random_headers()
    for attempt in range(max_retries):
        try:
            response = requests.get(url, headers=headers, timeout=10)
            response.raise_for_status()
            return response
        except requests.RequestException as e:
            logger.warning(f"Request failed (attempt {attempt+1}/{max_retries}): {str(e)}")
            if attempt < max_retries - 1:
                sleep_time = delay * (attempt + 1)
                logger.info(f"Retrying in {sleep_time} seconds...")
                time.sleep(sleep_time)
            else:
                logger.error(f"Failed to fetch {url} after {max_retries} attempts")
                raise

def scrape_ipl_teams() -> Dict[str, Any]:
    """
    Scrape IPL teams information from multiple sources and combine data
    
    Returns:
        Dict with team information
    """
    logger.info("Starting to scrape IPL teams data")
    teams_data = {
        "teams": {},
        "last_refresh": time.strftime("%Y-%m-%d %H:%M:%S")
    }
    
    try:
        # First try iplt20.com
        response = safe_request(STATS_URLS["teams"])
        soup = BeautifulSoup(response.text, 'html.parser')
        
        # Find team elements
        team_elements = soup.select('.team-card')
        
        for team in team_elements:
            try:
                team_name_elem = team.select_one('.team-card__title')
                if not team_name_elem:
                    continue
                    
                team_name = team_name_elem.text.strip()
                
                # Create basic team info
                teams_data["teams"][team_name] = {
                    "name": team_name,
                    "home_ground": "N/A",  # Will try to find this from other sources
                    "owner": "N/A",
                    "captain": "N/A",
                    "performance": {
                        "matches_played": 0,
                        "wins": 0,
                        "losses": 0,
                        "titles": 0
                    }
                }
            except Exception as e:
                logger.warning(f"Error processing team: {str(e)}")
        
        # Now try to get more detailed info from cricbuzz
        try:
            response = safe_request(STATS_URLS["cricbuzz_teams"])
            soup = BeautifulSoup(response.text, 'html.parser')
            
            team_links = soup.select('.cb-team-itm a')
            
            for link in team_links:
                team_url = CRICBUZZ_BASE_URL + link['href']
                team_name = link.text.strip()
                
                # Map the team name to existing format
                matched_team = None
                for existing_team in teams_data["teams"]:
                    if team_name.lower() in existing_team.lower() or existing_team.lower() in team_name.lower():
                        matched_team = existing_team
                        break
                
                if not matched_team:
                    continue
                    
                # Get team details
                try:
                    team_response = safe_request(team_url)
                    team_soup = BeautifulSoup(team_response.text, 'html.parser')
                    
                    # Extract information
                    info_items = team_soup.select('.cb-col.cb-col-100.cb-series-brdr')
                    
                    for item in info_items:
                        item_text = item.text.strip()
                        
                        if "Owner" in item_text:
                            teams_data["teams"][matched_team]["owner"] = item_text.replace("Owner:", "").strip()
                        elif "Home Ground" in item_text:
                            teams_data["teams"][matched_team]["home_ground"] = item_text.replace("Home Ground:", "").strip()
                        elif "Captain" in item_text:
                            teams_data["teams"][matched_team]["captain"] = item_text.replace("Captain:", "").strip()
                    
                    # Get performance data
                    stats_items = team_soup.select('.cb-col.cb-col-16.cb-text-center')
                    if len(stats_items) >= 4:
                        teams_data["teams"][matched_team]["performance"]["matches_played"] = int(stats_items[0].text.strip())
                        teams_data["teams"][matched_team]["performance"]["wins"] = int(stats_items[1].text.strip())
                        teams_data["teams"][matched_team]["performance"]["losses"] = int(stats_items[2].text.strip())
                    
                    # Try to get titles
                    titles_elem = team_soup.select_one('.cb-col-33.text-black')
                    if titles_elem:
                        title_text = titles_elem.text.strip()
                        titles_match = re.search(r'(\d+)\s+title', title_text, re.IGNORECASE)
                        if titles_match:
                            teams_data["teams"][matched_team]["performance"]["titles"] = int(titles_match.group(1))
                
                except Exception as e:
                    logger.warning(f"Error getting details for team {team_name}: {str(e)}")
                
                # Sleep to avoid hitting the server too hard
                time.sleep(1)
            
        except Exception as e:
            logger.warning(f"Error getting detailed team info: {str(e)}")
        
        return teams_data
        
    except Exception as e:
        logger.error(f"Error scraping IPL teams: {str(e)}")
        return {"teams": {}, "last_refresh": time.strftime("%Y-%m-%d %H:%M:%S")}

def scrape_player_stats(team_name: str) -> Dict[str, Dict]:
    """
    Scrape statistics for players in a specific IPL team
    
    Args:
        team_name: Name of the IPL team
        
    Returns:
        Dictionary with player data
    """
    logger.info(f"Scraping player stats for {team_name}")
    players_data = {}
    
    # Standardize team name for URL
    team_url_name = team_name.lower().replace(' ', '-')
    
    try:
        # First try to get player list from IPL site
        player_list_url = f"https://www.iplt20.com/teams/{team_url_name}/squad"
        
        try:
            response = safe_request(player_list_url)
            soup = BeautifulSoup(response.text, 'html.parser')
            
            # Find player elements
            player_elements = soup.select('.squad-player')
            
            for player in player_elements:
                try:
                    player_name_elem = player.select_one('.name')
                    player_role_elem = player.select_one('.player-details')
                    player_link_elem = player.select_one('a')
                    
                    if not player_name_elem or not player_link_elem:
                        continue
                        
                    player_name = player_name_elem.text.strip()
                    player_role = player_role_elem.text.strip() if player_role_elem else "N/A"
                    player_url = player_link_elem['href']
                    
                    # Generate a unique ID for the player
                    player_id = f"{team_url_name}-{player_name.lower().replace(' ', '-')}"
                    
                    # Create basic player info
                    players_data[player_id] = {
                        "id": player_id,
                        "name": player_name,
                        "team": team_name,
                        "role": player_role,
                        "matches_played": 0,
                        "age": "N/A",
                        "batting_stats": {
                            "runs": 0,
                            "average": 0.0,
                            "strike_rate": 0.0,
                            "highest": "0",
                            "fours": 0,
                            "sixes": 0,
                            "fifties": 0,
                            "hundreds": 0
                        },
                        "bowling_stats": {
                            "wickets": 0,
                            "economy": 0.0,
                            "average": 0.0,
                            "best": "0/0",
                            "three_plus": 0
                        }
                    }
                    
                    # Try to get detailed player stats
                    if player_url.startswith("http"):
                        detailed_url = player_url
                    else:
                        detailed_url = f"https://www.iplt20.com{player_url}"
                    
                    try:
                        player_response = safe_request(detailed_url)
                        player_soup = BeautifulSoup(player_response.text, 'html.parser')
                        
                        # Try to get age
                        age_elem = player_soup.select_one('.profile-highlight--bio')
                        if age_elem:
                            age_text = age_elem.text.strip()
                            age_match = re.search(r'(\d+)\s+years', age_text)
                            if age_match:
                                players_data[player_id]["age"] = age_match.group(1)
                        
                        # Try to get batting/bowling stats
                        stat_tables = player_soup.select('.table--scroll')
                        
                        for table in stat_tables:
                            caption = table.select_one('caption')
                            if not caption:
                                continue
                                
                            caption_text = caption.text.strip()
                            
                            if "Batting" in caption_text:
                                rows = table.select('tr')
                                for row in rows:
                                    cells = row.select('td')
                                    if len(cells) >= 8:
                                        # Parse batting stats
                                        try:
                                            matches = int(cells[0].text.strip())
                                            runs = int(cells[2].text.strip())
                                            
                                            players_data[player_id]["matches_played"] = matches
                                            players_data[player_id]["batting_stats"]["runs"] = runs
                                            players_data[player_id]["batting_stats"]["highest"] = cells[3].text.strip()
                                            players_data[player_id]["batting_stats"]["average"] = float(cells[4].text.strip())
                                            players_data[player_id]["batting_stats"]["strike_rate"] = float(cells[5].text.strip())
                                            
                                            # Try to parse 50s and 100s
                                            fifties_hundreds = cells[6].text.strip()
                                            parts = fifties_hundreds.split('/')
                                            if len(parts) == 2:
                                                players_data[player_id]["batting_stats"]["fifties"] = int(parts[0])
                                                players_data[player_id]["batting_stats"]["hundreds"] = int(parts[1])
                                        except (ValueError, IndexError):
                                            pass
                            
                            elif "Bowling" in caption_text:
                                rows = table.select('tr')
                                for row in rows:
                                    cells = row.select('td')
                                    if len(cells) >= 6:
                                        # Parse bowling stats
                                        try:
                                            wickets = int(cells[4].text.strip())
                                            
                                            players_data[player_id]["bowling_stats"]["wickets"] = wickets
                                            players_data[player_id]["bowling_stats"]["economy"] = float(cells[2].text.strip())
                                            players_data[player_id]["bowling_stats"]["average"] = float(cells[3].text.strip())
                                            players_data[player_id]["bowling_stats"]["best"] = cells[5].text.strip()
                                        except (ValueError, IndexError):
                                            pass
                    
                    except Exception as e:
                        logger.warning(f"Error getting detailed stats for {player_name}: {str(e)}")
                    
                except Exception as e:
                    logger.warning(f"Error processing player: {str(e)}")
            
        except Exception as e:
            logger.warning(f"Error getting player list for {team_name}: {str(e)}")
        
        # Try to get supplementary data from cricbuzz
        try:
            # Search for team on cricbuzz
            search_url = f"https://www.cricbuzz.com/api/search/results?q={team_name}+ipl"
            search_response = safe_request(search_url)
            search_data = search_response.json()
            
            team_id = None
            for item in search_data.get('teamResults', []):
                if "ipl" in item.get('name', '').lower():
                    team_id = item.get('teamId')
                    break
            
            if team_id:
                # Get squad
                squad_url = f"https://www.cricbuzz.com/api/team/{team_id}/squad"
                squad_response = safe_request(squad_url)
                squad_data = squad_response.json()
                
                # Process each player
                for player in squad_data.get('players', []):
                    player_name = player.get('name')
                    player_id_cb = player.get('id')
                    
                    # Try to match with existing player
                    matched_player_id = None
                    for existing_id, existing_player in players_data.items():
                        if player_name.lower() in existing_player['name'].lower() or existing_player['name'].lower() in player_name.lower():
                            matched_player_id = existing_id
                            break
                    
                    # If no match, create new player
                    if not matched_player_id:
                        player_id = f"{team_url_name}-{player_name.lower().replace(' ', '-')}"
                        players_data[player_id] = {
                            "id": player_id,
                            "name": player_name,
                            "team": team_name,
                            "role": player.get('roleDesc', 'N/A'),
                            "matches_played": 0,
                            "age": "N/A",
                            "batting_stats": {
                                "runs": 0,
                                "average": 0.0,
                                "strike_rate": 0.0,
                                "highest": "0",
                                "fours": 0,
                                "sixes": 0,
                                "fifties": 0,
                                "hundreds": 0
                            },
                            "bowling_stats": {
                                "wickets": 0,
                                "economy": 0.0,
                                "average": 0.0,
                                "best": "0/0",
                                "three_plus": 0
                            }
                        }
                        matched_player_id = player_id
                    
                    # Get detailed player stats from cricbuzz
                    if player_id_cb:
                        try:
                            player_url = f"https://www.cricbuzz.com/profiles/{player_id_cb}"
                            player_response = safe_request(player_url)
                            player_soup = BeautifulSoup(player_response.text, 'html.parser')
                            
                            # Try to get personal info
                            info_items = player_soup.select('.cb-col.cb-col-40.text-bold')
                            for item in info_items:
                                item_text = item.text.strip()
                                if "Born" in item_text:
                                    # Extract age from birth date
                                    dob_text = item.find_next_sibling().text.strip()
                                    age_match = re.search(r'\((\d+)\s+years', dob_text)
                                    if age_match:
                                        players_data[matched_player_id]["age"] = age_match.group(1)
                            
                            # Try to get T20 stats (as proxy for IPL)
                            batting_table = player_soup.select_one('.table-responsive:contains("Batting")')
                            bowling_table = player_soup.select_one('.table-responsive:contains("Bowling")')
                            
                            if batting_table:
                                rows = batting_table.select('tbody tr')
                                for row in rows:
                                    cells = row.select('td')
                                    if len(cells) >= 10 and "T20" in cells[0].text:
                                        try:
                                            # Update batting stats if better than what we have
                                            runs = int(cells[4].text.strip())
                                            if runs > players_data[matched_player_id]["batting_stats"]["runs"]:
                                                players_data[matched_player_id]["batting_stats"]["runs"] = runs
                                                players_data[matched_player_id]["batting_stats"]["average"] = float(cells[6].text.strip())
                                                players_data[matched_player_id]["batting_stats"]["strike_rate"] = float(cells[7].text.strip())
                                                players_data[matched_player_id]["batting_stats"]["highest"] = cells[5].text.strip()
                                                players_data[matched_player_id]["batting_stats"]["fifties"] = int(cells[8].text.strip())
                                                players_data[matched_player_id]["batting_stats"]["hundreds"] = int(cells[9].text.strip())
                                                
                                                # Update matches played if greater
                                                matches = int(cells[2].text.strip())
                                                if matches > players_data[matched_player_id]["matches_played"]:
                                                    players_data[matched_player_id]["matches_played"] = matches
                                        except (ValueError, IndexError):
                                            pass
                            
                            if bowling_table:
                                rows = bowling_table.select('tbody tr')
                                for row in rows:
                                    cells = row.select('td')
                                    if len(cells) >= 10 and "T20" in cells[0].text:
                                        try:
                                            # Update bowling stats if better than what we have
                                            wickets = int(cells[8].text.strip())
                                            if wickets > players_data[matched_player_id]["bowling_stats"]["wickets"]:
                                                players_data[matched_player_id]["bowling_stats"]["wickets"] = wickets
                                                players_data[matched_player_id]["bowling_stats"]["economy"] = float(cells[5].text.strip())
                                                players_data[matched_player_id]["bowling_stats"]["average"] = float(cells[6].text.strip())
                                                players_data[matched_player_id]["bowling_stats"]["best"] = cells[7].text.strip()
                                                
                                                # Try to count 3+ wicket hauls
                                                best_figures = cells[7].text.strip()
                                                wickets_match = re.match(r'(\d+)/\d+', best_figures)
                                                if wickets_match and int(wickets_match.group(1)) >= 3:
                                                    players_data[matched_player_id]["bowling_stats"]["three_plus"] = 1
                                        except (ValueError, IndexError):
                                            pass
                        
                        except Exception as e:
                            logger.warning(f"Error getting detailed cricbuzz stats for {player_name}: {str(e)}")
                        
                        # Don't hit the server too hard
                        time.sleep(1)
            
        except Exception as e:
            logger.warning(f"Error getting cricbuzz data for {team_name}: {str(e)}")
        
        # Final data check and cleanup
        final_players = {}
        for player_id, player_data in players_data.items():
            # Only include players with at least some data
            if (player_data["batting_stats"]["runs"] > 0 or 
                player_data["bowling_stats"]["wickets"] > 0 or 
                player_data["matches_played"] > 0):
                final_players[player_id] = player_data
            
        return final_players
    
    except Exception as e:
        logger.error(f"Error scraping player stats for {team_name}: {str(e)}")
        return {}

def get_additional_player_metrics(player_id: str, player_data: Dict) -> Dict:
    """
    Try to get additional metrics like boundaries for a player
    
    Args:
        player_id: Player ID
        player_data: Current player data
        
    Returns:
        Updated player data
    """
    player_name = player_data.get('name', '')
    
    try:
        # Search player on cricbuzz
        search_url = f"https://www.cricbuzz.com/api/search/results?q={player_name}"
        search_response = safe_request(search_url)
        search_data = search_response.json()
        
        for item in search_data.get('playerResults', []):
            if item.get('name') == player_name:
                player_cb_id = item.get('playerId')
                
                # Get detailed player stats
                player_url = f"https://www.cricbuzz.com/api/player/{player_cb_id}/stats"
                player_response = safe_request(player_url)
                player_stats = player_response.json()
                
                # Extract boundaries
                for format_stats in player_stats.get('values', []):
                    if format_stats.get('values', {}).get('format') == 't20':
                        batting = format_stats.get('values', {}).get('batting', {})
                        if batting:
                            # Extract boundaries
                            player_data['batting_stats']['fours'] = batting.get('fours', 0)
                            player_data['batting_stats']['sixes'] = batting.get('sixes', 0)
                            break
                
                # No need to continue searching
                break
                
    except Exception as e:
        logger.warning(f"Error getting additional metrics for {player_name}: {str(e)}")
    
    return player_data

if __name__ == "__main__":
    # Test function
    print("Scraping teams data...")
    teams = scrape_ipl_teams()
    print(f"Found {len(teams['teams'])} teams")
    
    # Test player scraping for one team
    if teams['teams']:
        team_name = next(iter(teams['teams']))
        print(f"Scraping players for {team_name}...")
        players = scrape_player_stats(team_name)
        print(f"Found {len(players)} players")
        
        if players:
            player_id = next(iter(players))
            print(f"Player details for {players[player_id]['name']}:")
            print(players[player_id])
